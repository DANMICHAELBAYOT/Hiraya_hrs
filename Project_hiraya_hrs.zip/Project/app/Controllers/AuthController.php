<?php

namespace App\Controllers;

use App\Models\UserModel;
use CodeIgniter\API\ResponseTrait;

class AuthController extends BaseController
{
    use ResponseTrait;

    protected $userModel;

    public function __construct()
    {
        $this->userModel = new UserModel();
    }

    public function me()
    {
        $session = session();
        $user = $session->get('user');

        if ($user) {
            return $this->response->setJSON([
                'status' => 'success',
                'authenticated' => true,
                'user' => $user
            ]);
        }

        return $this->response->setJSON([
            'status' => 'success',
            'authenticated' => false,
            'user' => null
        ]);
    }

    protected function getRequestData(): array
    {
        try {
            $json = $this->request->getJSON(true);
            if (is_array($json)) {
                return $json;
            }
        } catch (\Throwable $e) {
            // fallback
        }

        $raw = $this->request->getBody();
        if ($raw) {
            $decoded = json_decode($raw, true);
            if (is_array($decoded)) {
                return $decoded;
            }
        }

        $post = $this->request->getPost();
        return is_array($post) ? $post : [];
    }

    public function login()
    {
        $json = $this->getRequestData();
        $email = trim($json['email'] ?? '');
        $password = $json['password'] ?? '';

        if (!$email || !$password) {
            return $this->response->setStatusCode(400)->setJSON([
                'status' => 'error',
                'message' => 'Please provide both email and password.'
            ]);
        }

        $user = $this->userModel->authenticate($email, $password);
        if (!$user) {
            return $this->response->setStatusCode(401)->setJSON([
                'status' => 'error',
                'message' => 'Invalid email address or password.'
            ]);
        }

        // Store in session
        $session = session();
        $session->set('user', $user);

        return $this->response->setJSON([
            'status' => 'success',
            'message' => "Welcome back, {$user['name']}!",
            'user' => $user
        ]);
    }

    public function register()
    {
        $json = $this->getRequestData();
        $name = trim($json['name'] ?? '');
        $email = strtolower(trim($json['email'] ?? ''));
        $password = $json['password'] ?? '';
        $phone = trim($json['phone'] ?? '');
        // All registrations from the public webpage are strictly User / Guest role
        $role = 'Guest';

        if (!$name || !$email || !$password) {
            return $this->response->setStatusCode(400)->setJSON([
                'status' => 'error',
                'message' => 'Full Name, Email, and Password are required.'
            ]);
        }

        if (strlen($password) < 6) {
            return $this->response->setStatusCode(400)->setJSON([
                'status' => 'error',
                'message' => 'Password must be at least 6 characters long.'
            ]);
        }

        // Check duplicate email
        $existing = $this->userModel->where('email', $email)->first();
        if ($existing) {
            return $this->response->setStatusCode(409)->setJSON([
                'status' => 'error',
                'message' => 'An account with this email address already exists.'
            ]);
        }

        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
        $userId = $this->userModel->insert([
            'name' => $name,
            'email' => $email,
            'password' => $hashedPassword,
            'role' => $role,
            'phone' => $phone
        ]);

        $user = [
            'id' => $userId,
            'name' => $name,
            'email' => $email,
            'role' => $role,
            'phone' => $phone
        ];

        // Store in session
        $session = session();
        $session->set('user', $user);

        return $this->response->setJSON([
            'status' => 'success',
            'message' => 'Registration successful! You are now logged in.',
            'user' => $user
        ]);
    }

    public function logout()
    {
        $session = session();
        $session->destroy();

        return $this->response->setJSON([
            'status' => 'success',
            'message' => 'You have been logged out successfully.'
        ]);
    }
}
