<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hiraya Resort & Residences — Minimalist Coastal Luxury</title>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Playfair+Display:ital,wght@0,500;0,600;0,700;1,400&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        midnightBlue: '#0F1E36',
                        antiqueGold: '#D4AF37',
                        warmIvory: '#F9F6F0',
                        tropicalGreen: '#1B4D3E',
                        slateGray: '#4A5568'
                    },
                    fontFamily: {
                        sans: ['"Plus Jakarta Sans"', 'sans-serif'],
                        serif: ['"Playfair Display"', 'serif'],
                    }
                }
            }
        }
    </script>
    <style>
        .custom-scrollbar::-webkit-scrollbar {
            width: 5px;
            height: 5px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
            background: #f1f1f1;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
            background: #cbd5e1;
            border-radius: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
            background: #94a3b8;
        }
        .hero-gradient {
            background: linear-gradient(180deg, rgba(15, 30, 54, 0.4) 0%, rgba(15, 30, 54, 0.85) 100%);
        }
        @media print {
            body {
                background: white !important;
                color: black !important;
            }
            body > *:not(#receipt-modal) {
                display: none !important;
            }
            #receipt-modal {
                position: static !important;
                display: block !important;
                background: white !important;
                padding: 0 !important;
                box-shadow: none !important;
                inset: auto !important;
                z-index: auto !important;
            }
            #receipt-modal > div {
                max-width: 100% !important;
                max-height: none !important;
                box-shadow: none !important;
                border: none !important;
                border-radius: 0 !important;
            }
            .no-print {
                display: none !important;
            }
            #receipt-printable-content {
                padding: 0 !important;
                overflow: visible !important;
            }
        }
    </style>
</head>
<body class="bg-warmIvory text-slateGray font-sans min-h-screen flex flex-col antialiased">

    <!-- Top Notice / 1-Click Role Switcher Demo Strip -->
    <div class="bg-slate-950 text-slate-300 text-xs px-4 sm:px-6 py-2 border-b border-slate-800 flex flex-wrap items-center justify-between gap-2 z-50">
        <div class="flex items-center flex-wrap gap-1.5 sm:gap-2">
            <span class="text-antiqueGold font-bold flex items-center gap-1">
                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z"></path></svg>
                1-Click Role Login:
            </span>
            <button onclick="quickLogin('fd@hiraya.com')" title="fd@hiraya.com / hiraya123" class="hover:text-white px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 transition text-[11px] font-medium text-emerald-300">Front Desk</button>
            <button onclick="quickLogin('hk@hiraya.com')" title="hk@hiraya.com / hiraya123" class="hover:text-white px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 transition text-[11px] font-medium text-amber-300">Housekeeping</button>
            <button onclick="quickLogin('ac@hiraya.com')" title="AC@hiraya.com / hiraya123" class="hover:text-white px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 transition text-[11px] font-medium text-sky-300">Accounting</button>
            <button onclick="quickLogin('admin@hiraya.com')" title="admin@hiraya.com / hiraya123" class="hover:text-white px-2.5 py-0.5 rounded bg-purple-900/70 hover:bg-purple-800 transition text-[11px] font-bold text-purple-200">Admin (Edit Rooms)</button>
            <span class="text-slate-500 text-[10px] hidden md:inline">&bull; Password: <code class="text-slate-300 font-mono">hiraya123</code></span>
        </div>
        <div id="rbac-status-note" class="italic text-[11px] text-slate-400">
            Browsing as Public Visitor
        </div>
    </div>

    <!-- Main Navigation Header -->
    <header class="bg-midnightBlue text-white shadow-xl sticky top-0 z-40 border-b border-slate-800">
        <div class="max-w-7xl mx-auto flex items-center justify-between px-4 sm:px-6 py-3.5">
            
            <!-- Brand Logo -->
            <div class="flex items-center space-x-3 cursor-pointer select-none" onclick="goToHome()">
                <div class="w-10 h-10 rounded-full bg-gradient-to-tr from-antiqueGold to-amber-200 flex items-center justify-center text-midnightBlue font-black text-xl shadow-md">
                    H
                </div>
                <div>
                    <span class="text-2xl font-extrabold tracking-widest text-antiqueGold uppercase block font-serif">HIRAYA</span>
                    <span class="text-[10px] uppercase tracking-widest text-slate-300 block -mt-1 font-sans">Resort & Residences</span>
                </div>
            </div>

            <!-- Public Navigation Links (Clean hotel navbar: NO internal staff tabs) -->
            <nav id="public-nav-links" class="hidden md:flex items-center space-x-6 text-sm font-medium">
                <button onclick="goToHome()" class="nav-item text-slate-200 hover:text-antiqueGold transition font-semibold">Home</button>
                <button onclick="scrollToBooking()" class="nav-item text-slate-200 hover:text-antiqueGold transition">Villas & Suites</button>
                <button onclick="scrollToSection('experience-section')" class="nav-item text-slate-200 hover:text-antiqueGold transition">Experience</button>
                <button onclick="scrollToSection('amenities-section')" class="nav-item text-slate-200 hover:text-antiqueGold transition">Amenities</button>
                <button onclick="scrollToSection('contact-section')" class="nav-item text-slate-200 hover:text-antiqueGold transition">Contact</button>
                <button onclick="openFindBookingModal()" class="nav-item text-antiqueGold hover:text-amber-300 transition flex items-center gap-1.5 font-semibold">
                    <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                    Lookup Voucher
                </button>
            </nav>

            <!-- Actions Section: Book Now Button + User Session -->
            <div class="flex items-center gap-3">
                
                <!-- Dedicated "Book Now" Navbar CTA Button -->
                <button onclick="scrollToBooking()" class="bg-gradient-to-r from-antiqueGold to-amber-500 hover:from-amber-400 hover:to-amber-500 text-midnightBlue font-extrabold px-4 sm:px-5 py-2 rounded-lg text-xs sm:text-sm uppercase tracking-wider shadow-lg hover:shadow-antiqueGold/20 transition flex items-center gap-1.5">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                    <span>Book Now</span>
                </button>

                <!-- Auth Bar: Logged Out State -->
                <div id="auth-guest-view" class="flex items-center gap-2">
                    <button onclick="openModal('login-modal')" class="text-xs sm:text-sm font-semibold px-3 py-1.5 text-slate-200 hover:text-antiqueGold transition">
                        Sign In
                    </button>
                    <button onclick="openModal('register-modal')" class="hidden sm:inline-block text-xs sm:text-sm font-semibold px-3 py-1.5 bg-slate-800 text-slate-200 rounded-md hover:bg-slate-700 transition">
                        Register
                    </button>
                </div>

                <!-- Auth Bar: Logged In State -->
                <div id="auth-user-view" class="hidden flex items-center gap-2.5 sm:gap-3">
                    <div class="text-right">
                        <div id="user-display-name" class="text-xs sm:text-sm font-bold text-warmIvory leading-tight">Guest</div>
                        <div class="flex items-center justify-end gap-1.5 mt-0.5">
                            <span id="user-display-role" class="text-[10px] uppercase tracking-wider font-extrabold px-2 py-0.5 rounded bg-antiqueGold text-midnightBlue">Role</span>
                        </div>
                    </div>
                    <button onclick="logoutUser()" title="Sign Out" class="p-2 rounded-lg bg-slate-800 hover:bg-rose-900/60 text-slate-300 hover:text-rose-300 transition">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path></svg>
                    </button>
                </div>
            </div>
        </div>

        <!-- Staff / Admin Sub-Navigation Toolbar (Visible ONLY to logged-in Staff or Admin) -->
        <div id="staff-controls-bar" class="hidden bg-slate-900/95 border-t border-slate-800/80 px-4 sm:px-6 py-2">
            <div class="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
                <div class="flex items-center gap-2 text-xs text-slate-400">
                    <span class="font-bold uppercase tracking-wider text-antiqueGold flex items-center gap-1">
                        <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                        Staff Portal:
                    </span>
                    <span id="staff-active-label" class="font-semibold text-white">Management Console</span>
                </div>

                <!-- Role specific action buttons (Dynamically toggled) -->
                <div id="staff-view-switcher" class="flex flex-wrap items-center gap-1.5 text-xs font-medium">
                    <!-- Shown for Admin -->
                    <button onclick="showSection('admin')" id="btn-portal-admin" class="px-3 py-1 rounded bg-purple-700 hover:bg-purple-600 text-white font-semibold transition flex items-center gap-1">
                        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path></svg>
                        Edit Rooms & Rates
                    </button>
                    <!-- Shown for Front Desk & Admin -->
                    <button onclick="showSection('frontdesk')" id="btn-portal-frontdesk" class="px-3 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 transition flex items-center gap-1">
                        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"></path></svg>
                        Front Desk
                    </button>
                    <!-- Shown for Housekeeping & Admin -->
                    <button onclick="showSection('housekeeping')" id="btn-portal-housekeeping" class="px-3 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 transition flex items-center gap-1">
                        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"></path></svg>
                        Housekeeping
                    </button>
                    <!-- Shown for Accounting & Admin -->
                    <button onclick="showSection('accounting')" id="btn-portal-accounting" class="px-3 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 transition flex items-center gap-1">
                        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                        Accounting
                    </button>
                    <!-- Always available: View Public Home -->
                    <button onclick="showSection('home')" id="btn-portal-home" class="px-3 py-1 rounded bg-tropicalGreen/80 hover:bg-tropicalGreen text-white transition flex items-center gap-1">
                        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path></svg>
                        View Home Page
                    </button>
                </div>
            </div>
        </div>
    </header>

    <!-- Notification Toast -->
    <div id="toast" class="fixed bottom-6 right-6 z-50 transform transition-all duration-300 translate-y-20 opacity-0 bg-midnightBlue text-white px-5 py-3.5 rounded-xl shadow-2xl border-l-4 border-antiqueGold flex items-center gap-3 text-sm">
        <svg class="w-5 h-5 text-antiqueGold flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
        <span id="toast-msg">Action completed</span>
    </div>

    <!-- MAIN APP CONTENT -->
    <main class="flex-1 w-full">

        <!-- ============================================================== -->
        <!-- 1. PUBLIC RESORT HOME PAGE (Default Visitor Landing View)      -->
        <!-- ============================================================== -->
        <div id="section-home" class="space-y-16 pb-16">
            
            <!-- Hero Banner Section -->
            <section id="home" class="relative min-h-[580px] sm:min-h-[640px] flex items-center justify-center text-center text-white px-4 sm:px-6 overflow-hidden">
                <!-- Background Image & Gradient Overlays -->
                <img src="https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&w=2000&q=85" alt="Hiraya Resort Tropical Haven" class="absolute inset-0 w-full h-full object-cover object-center scale-105 animate-pulse duration-1000">
                <div class="absolute inset-0 bg-gradient-to-b from-midnightBlue/80 via-midnightBlue/60 to-midnightBlue/90 backdrop-blur-[2px]"></div>

                <!-- Hero Content -->
                <div class="relative max-w-4xl mx-auto py-16 space-y-6">
                    <div class="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-antiqueGold/20 border border-antiqueGold/40 backdrop-blur-md">
                        <span class="w-2 h-2 rounded-full bg-antiqueGold"></span>
                        <span class="text-xs uppercase tracking-widest font-extrabold text-amber-200">Boutique Tranquility &bull; Minimalist Coastal Luxury</span>
                    </div>

                    <h1 class="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-extrabold tracking-tight font-serif text-warmIvory leading-tight">
                        Escape to <span class="text-antiqueGold italic font-serif">Hiraya</span>
                    </h1>

                    <p class="text-slate-200 text-base sm:text-lg md:text-xl max-w-2xl mx-auto font-light leading-relaxed">
                        Where modern architectural grace meets authentic tropical serenity. Immerse yourself in hand-crafted villas, private plunge pools, and mindful hospitality.
                    </p>

                    <!-- Primary Hero CTAs (Prominent "Book Now" Button) -->
                    <div class="pt-4 flex flex-col sm:flex-row items-center justify-center gap-4">
                        <button onclick="scrollToBooking()" class="w-full sm:w-auto px-8 py-4 bg-antiqueGold hover:bg-amber-400 text-midnightBlue font-extrabold text-base rounded-xl shadow-2xl hover:shadow-antiqueGold/30 transition transform hover:-translate-y-0.5 flex items-center justify-center gap-2">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                            <span>Book Now & Check Dates</span>
                        </button>
                        <button onclick="scrollToSection('rooms-showcase')" class="w-full sm:w-auto px-7 py-4 bg-white/10 hover:bg-white/20 text-warmIvory border border-white/25 rounded-xl font-bold text-base backdrop-blur-sm transition flex items-center justify-center gap-2">
                            <span>Explore Villas</span>
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg>
                        </button>
                    </div>

                    <!-- Highlight Badges -->
                    <div class="pt-8 border-t border-white/10 grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs font-medium text-slate-300">
                        <div class="flex items-center justify-center gap-2">
                            <span class="text-antiqueGold text-lg">✦</span> Private Plunge Pools
                        </div>
                        <div class="flex items-center justify-center gap-2">
                            <span class="text-antiqueGold text-lg">✦</span> 100% Oceanfront Views
                        </div>
                        <div class="flex items-center justify-center gap-2">
                            <span class="text-antiqueGold text-lg">✦</span> Farm-to-Table Cuisine
                        </div>
                        <div class="flex items-center justify-center gap-2">
                            <span class="text-antiqueGold text-lg">✦</span> 24/7 Butler Service
                        </div>
                    </div>
                </div>
            </section>

            <!-- Floating Reservation & Date Filter Bar -->
            <section id="booking-section" class="max-w-7xl mx-auto px-4 sm:px-6 -mt-12 relative z-20">
                <div class="bg-white rounded-2xl shadow-2xl p-6 sm:p-8 border border-slate-200/80">
                    <div class="flex flex-col md:flex-row items-start md:items-center justify-between pb-5 mb-5 border-b border-slate-100 gap-2">
                        <div>
                            <span class="text-xs uppercase tracking-widest font-extrabold text-tropicalGreen">Direct Online Reservation</span>
                            <h2 class="text-xl sm:text-2xl font-bold text-midnightBlue">Check Availability & Room Rates</h2>
                        </div>
                        <span class="text-xs text-slate-400 bg-slate-50 px-3 py-1 rounded-full border border-slate-200">
                            Instant confirmation &bull; 30% Deposit locks your room
                        </span>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                        <div class="bg-slate-50 p-3 rounded-xl border border-slate-200 focus-within:border-antiqueGold focus-within:ring-2 focus-within:ring-antiqueGold/20 transition">
                            <label class="block text-[11px] font-bold text-slateGray uppercase tracking-wider mb-1 flex items-center gap-1.5">
                                <svg class="w-3.5 h-3.5 text-antiqueGold" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                                Check-in Date
                            </label>
                            <input type="date" id="search-check-in" onchange="onSearchCheckInChange()" class="w-full bg-transparent font-semibold text-slate-800 text-sm focus:outline-none" />
                        </div>

                        <div class="bg-slate-50 p-3 rounded-xl border border-slate-200 focus-within:border-antiqueGold focus-within:ring-2 focus-within:ring-antiqueGold/20 transition">
                            <label class="block text-[11px] font-bold text-slateGray uppercase tracking-wider mb-1 flex items-center gap-1.5">
                                <svg class="w-3.5 h-3.5 text-antiqueGold" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                                Check-out Date
                            </label>
                            <input type="date" id="search-check-out" onchange="onSearchCheckOutChange()" class="w-full bg-transparent font-semibold text-slate-800 text-sm focus:outline-none" />
                        </div>

                        <div class="bg-slate-50 p-3 rounded-xl border border-slate-200 focus-within:border-antiqueGold focus-within:ring-2 focus-within:ring-antiqueGold/20 transition">
                            <label class="block text-[11px] font-bold text-slateGray uppercase tracking-wider mb-1 flex items-center gap-1.5">
                                <svg class="w-3.5 h-3.5 text-antiqueGold" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path></svg>
                                Number of Guests
                            </label>
                            <select id="search-capacity" class="w-full bg-transparent font-semibold text-slate-800 text-sm focus:outline-none cursor-pointer">
                                <option value="1">1 Guest</option>
                                <option value="2" selected>2 Guests</option>
                                <option value="3">3 Guests</option>
                                <option value="4">4+ Guests</option>
                            </select>
                        </div>

                        <div class="flex items-end">
                            <button id="btn-search-rooms" onclick="handleSearchClick()" class="w-full h-[52px] bg-midnightBlue hover:bg-slate-800 active:scale-[0.98] text-white font-bold rounded-xl shadow-md transition flex items-center justify-center gap-2 text-sm">
                                <svg class="w-4 h-4 text-antiqueGold" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                                <span id="search-btn-label">Find Available Rooms</span>
                            </button>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Accommodations Showcase Grid -->
            <section id="rooms-showcase" class="max-w-7xl mx-auto px-4 sm:px-6">
                <div class="flex flex-col sm:flex-row sm:items-end justify-between mb-8 gap-4">
                    <div>
                        <span class="text-xs uppercase tracking-widest font-extrabold text-antiqueGold block mb-1">Hand-Crafted Sanctuaries</span>
                        <h2 class="text-3xl sm:text-4xl font-extrabold text-midnightBlue font-serif">Villas & Luxury Suites</h2>
                        <p class="text-slateGray text-sm mt-1 max-w-xl">Every room features artisanal stone textures, bespoke woodwork, and panoramic vistas tailored for sublime tranquility.</p>
                    </div>
                    <span id="room-count-badge" class="self-start sm:self-auto text-xs bg-tropicalGreen/10 text-tropicalGreen font-bold px-3 py-1.5 rounded-full border border-tropicalGreen/20">
                        Loading rooms...
                    </span>
                </div>

                <!-- Rooms Grid (Dynamically rendered via JS with photos, rates & details) -->
                <div id="rooms-grid" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    <!-- Populated via JS -->
                </div>
            </section>

            <!-- Resort Experience Section -->
            <section id="experience-section" class="bg-midnightBlue text-white py-20 px-4 sm:px-6 my-12">
                <div class="max-w-7xl mx-auto space-y-12">
                    <div class="text-center max-w-3xl mx-auto space-y-3">
                        <span class="text-xs uppercase tracking-widest font-extrabold text-antiqueGold">Mindful Hospitality</span>
                        <h2 class="text-3xl sm:text-4xl md:text-5xl font-bold font-serif text-warmIvory">The Hiraya Experience</h2>
                        <p class="text-slate-300 text-sm sm:text-base leading-relaxed">
                            Designed to rejuvenate your soul. From early morning ocean yoga to private sunset catamaran charters, our sanctuary elevates each moment into an art form.
                        </p>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                        <div class="bg-slate-900/60 p-6 rounded-2xl border border-slate-800 hover:border-antiqueGold/40 transition">
                            <div class="w-12 h-12 rounded-xl bg-antiqueGold/20 flex items-center justify-center text-antiqueGold mb-4">
                                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"></path></svg>
                            </div>
                            <h3 class="text-lg font-bold text-warmIvory mb-2 font-serif">Oceanfront Plunge Pools</h3>
                            <p class="text-xs text-slate-300 leading-relaxed">Sprawling infinity edges overlooking calm turquoise tides with dedicated sunken daybeds.</p>
                        </div>

                        <div class="bg-slate-900/60 p-6 rounded-2xl border border-slate-800 hover:border-antiqueGold/40 transition">
                            <div class="w-12 h-12 rounded-xl bg-antiqueGold/20 flex items-center justify-center text-antiqueGold mb-4">
                                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path></svg>
                            </div>
                            <h3 class="text-lg font-bold text-warmIvory mb-2 font-serif">Artisanal Gastronomy</h3>
                            <p class="text-xs text-slate-300 leading-relaxed">Michelin-trained chefs curate fresh coastal catch, native botanicals, and bespoke private villa dinners.</p>
                        </div>

                        <div class="bg-slate-900/60 p-6 rounded-2xl border border-slate-800 hover:border-antiqueGold/40 transition">
                            <div class="w-12 h-12 rounded-xl bg-antiqueGold/20 flex items-center justify-center text-antiqueGold mb-4">
                                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"></path></svg>
                            </div>
                            <h3 class="text-lg font-bold text-warmIvory mb-2 font-serif">Holistic Spa & Hilot</h3>
                            <p class="text-xs text-slate-300 leading-relaxed">Ancient Philippine herbal wellness therapies, sound baths, and cliffside open-air pavilions.</p>
                        </div>

                        <div class="bg-slate-900/60 p-6 rounded-2xl border border-slate-800 hover:border-antiqueGold/40 transition">
                            <div class="w-12 h-12 rounded-xl bg-antiqueGold/20 flex items-center justify-center text-antiqueGold mb-4">
                                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                            </div>
                            <h3 class="text-lg font-bold text-warmIvory mb-2 font-serif">Bespoke Butler Service</h3>
                            <p class="text-xs text-slate-300 leading-relaxed">Dedicated personal hosts curate your itineraries, airport transfers, and private island excursions.</p>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Amenities Section -->
            <section id="amenities-section" class="max-w-7xl mx-auto px-4 sm:px-6">
                <div class="text-center max-w-3xl mx-auto mb-12">
                    <span class="text-xs uppercase tracking-widest font-extrabold text-tropicalGreen">Resort Features</span>
                    <h2 class="text-3xl sm:text-4xl font-bold font-serif text-midnightBlue mt-1">Thoughtful Curations</h2>
                    <p class="text-slateGray text-sm mt-2">Every convenience is anticipated so you can unwind effortlessly.</p>
                </div>

                <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 text-center">
                    <div class="bg-white p-5 rounded-xl border border-slate-200/80 shadow-sm flex flex-col items-center">
                        <div class="text-2xl mb-2">⚡</div>
                        <span class="text-xs font-bold text-midnightBlue">Fiber Wi-Fi</span>
                        <span class="text-[10px] text-slate-400 mt-1">High-speed seamless</span>
                    </div>
                    <div class="bg-white p-5 rounded-xl border border-slate-200/80 shadow-sm flex flex-col items-center">
                        <div class="text-2xl mb-2">🏖️</div>
                        <span class="text-xs font-bold text-midnightBlue">Private Shore</span>
                        <span class="text-[10px] text-slate-400 mt-1">Exclusive beach access</span>
                    </div>
                    <div class="bg-white p-5 rounded-xl border border-slate-200/80 shadow-sm flex flex-col items-center">
                        <div class="text-2xl mb-2">🍹</div>
                        <span class="text-xs font-bold text-midnightBlue">Sunset Lounge</span>
                        <span class="text-[10px] text-slate-400 mt-1">Cocktails & tapas</span>
                    </div>
                    <div class="bg-white p-5 rounded-xl border border-slate-200/80 shadow-sm flex flex-col items-center">
                        <div class="text-2xl mb-2">🚘</div>
                        <span class="text-xs font-bold text-midnightBlue">VIP Transfer</span>
                        <span class="text-[10px] text-slate-400 mt-1">Airport chauffeur</span>
                    </div>
                    <div class="bg-white p-5 rounded-xl border border-slate-200/80 shadow-sm flex flex-col items-center">
                        <div class="text-2xl mb-2">☀️</div>
                        <span class="text-xs font-bold text-midnightBlue">Solar Powered</span>
                        <span class="text-[10px] text-slate-400 mt-1">100% Sustainable</span>
                    </div>
                    <div class="bg-white p-5 rounded-xl border border-slate-200/80 shadow-sm flex flex-col items-center">
                        <div class="text-2xl mb-2">🧼</div>
                        <span class="text-xs font-bold text-midnightBlue">Housekeeping</span>
                        <span class="text-[10px] text-slate-400 mt-1">Twice-daily turnover</span>
                    </div>
                </div>
            </section>

            <!-- Testimonials & Accolades -->
            <section class="max-w-7xl mx-auto px-4 sm:px-6">
                <div class="bg-gradient-to-r from-slate-900 to-midnightBlue text-white rounded-3xl p-8 sm:p-12 relative overflow-hidden shadow-2xl">
                    <div class="relative z-10 max-w-3xl">
                        <div class="flex items-center gap-1 text-antiqueGold text-sm mb-4">
                            ★★★★★
                        </div>
                        <blockquote class="text-xl sm:text-2xl font-serif text-warmIvory italic leading-relaxed">
                            “Hiraya is more than a resort; it is a transcendent retreat. The harmony of raw timber, plunge pools, and discreet luxury makes it the premier sanctuary in the islands.”
                        </blockquote>
                        <div class="mt-6 flex items-center gap-3">
                            <div class="w-10 h-10 rounded-full bg-antiqueGold text-midnightBlue font-bold flex items-center justify-center">
                                AV
                            </div>
                            <div>
                                <span class="font-bold text-sm text-warmIvory block">Arch. Vincent Delgado</span>
                                <span class="text-xs text-slate-400">Architectural Digest Contributor</span>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Contact & Concierge Information -->
            <section id="contact-section" class="max-w-7xl mx-auto px-4 sm:px-6">
                <div class="bg-white rounded-2xl p-8 sm:p-10 border border-slate-200 shadow-sm grid grid-cols-1 md:grid-cols-3 gap-8">
                    <div>
                        <span class="text-xs uppercase tracking-widest font-extrabold text-antiqueGold">Direct Reservations</span>
                        <h3 class="text-2xl font-bold font-serif text-midnightBlue mt-1">Contact Hiraya</h3>
                        <p class="text-xs text-slateGray mt-2 leading-relaxed">Our concierge team is available 24/7 to assist with room selections, custom itineraries, and helicopter transfers.</p>
                    </div>
                    <div class="space-y-3 text-sm">
                        <div class="flex items-center gap-3">
                            <span class="w-8 h-8 rounded-lg bg-warmIvory flex items-center justify-center text-midnightBlue font-bold">📍</span>
                            <div>
                                <strong class="text-slate-800 block text-xs">Resort Location</strong>
                                <span class="text-xs text-slate-500">Station 1, White Beach, Boracay Island, Philippines</span>
                            </div>
                        </div>
                        <div class="flex items-center gap-3">
                            <span class="w-8 h-8 rounded-lg bg-warmIvory flex items-center justify-center text-midnightBlue font-bold">✉️</span>
                            <div>
                                <strong class="text-slate-800 block text-xs">Email Concierge</strong>
                                <span class="text-xs text-slate-500">reservations@hirayahotel.ph</span>
                            </div>
                        </div>
                    </div>
                    <div class="space-y-3 text-sm">
                        <div class="flex items-center gap-3">
                            <span class="w-8 h-8 rounded-lg bg-warmIvory flex items-center justify-center text-midnightBlue font-bold">📞</span>
                            <div>
                                <strong class="text-slate-800 block text-xs">Direct Hotline</strong>
                                <span class="text-xs text-slate-500">+63 (2) 8888-4472 / +63 917 100 0000</span>
                            </div>
                        </div>
                        <div class="flex items-center gap-3">
                            <span class="w-8 h-8 rounded-lg bg-warmIvory flex items-center justify-center text-midnightBlue font-bold">⏰</span>
                            <div>
                                <strong class="text-slate-800 block text-xs">Check-in / Check-out</strong>
                                <span class="text-xs text-slate-500">Check-in: 2:00 PM &bull; Check-out: 12:00 PM</span>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>


        <!-- ============================================================== -->
        <!-- 2. ADMIN PORTAL: ROOM INVENTORY & PRICE / IMAGE EDITING       -->
        <!-- ============================================================== -->
        <section id="role-admin" class="hidden max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-8">
            <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-200 pb-5">
                <div>
                    <div class="flex items-center gap-2">
                        <span class="px-2.5 py-0.5 rounded bg-purple-700 text-white text-[10px] font-extrabold uppercase tracking-wider">Admin Console</span>
                        <span class="text-xs text-slate-400 font-medium">Full System Permissions</span>
                    </div>
                    <h2 class="text-2xl sm:text-3xl font-extrabold text-midnightBlue mt-1">Room Management, Pricing & Visuals</h2>
                    <p class="text-sm text-slateGray">Modify room nightly rates, update promotional descriptions, assign amenities, and change suite photographs.</p>
                </div>
                <div class="flex items-center gap-2">
                    <button onclick="loadAdminRooms()" class="bg-midnightBlue text-white px-4 py-2 rounded-lg text-xs font-semibold hover:bg-slate-800 transition flex items-center gap-1.5 shadow-sm">
                        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path></svg>
                        Refresh Inventory
                    </button>
                    <button onclick="showSection('home')" class="bg-tropicalGreen text-white px-4 py-2 rounded-lg text-xs font-semibold hover:bg-opacity-90 transition flex items-center gap-1.5 shadow-sm">
                        Preview Website
                    </button>
                </div>
            </div>

            <!-- Admin Stats KPI Bar -->
            <div class="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
                    <span class="text-xs font-semibold text-slateGray uppercase tracking-wider">Total Rooms</span>
                    <div id="admin-stat-total" class="text-3xl font-extrabold text-midnightBlue mt-1">8</div>
                    <span class="text-[11px] text-slate-400">Inventory units</span>
                </div>
                <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
                    <span class="text-xs font-semibold text-slateGray uppercase tracking-wider">Available For Sale</span>
                    <div id="admin-stat-available" class="text-3xl font-extrabold text-tropicalGreen mt-1">0</div>
                    <span class="text-[11px] text-emerald-600 font-medium">Ready to book</span>
                </div>
                <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
                    <span class="text-xs font-semibold text-slateGray uppercase tracking-wider">Booked / Occupied</span>
                    <div id="admin-stat-occupied" class="text-3xl font-extrabold text-amber-600 mt-1">0</div>
                    <span class="text-[11px] text-slate-400">Active guests</span>
                </div>
                <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
                    <span class="text-xs font-semibold text-slateGray uppercase tracking-wider">Average Villa Price</span>
                    <div id="admin-stat-avg-price" class="text-3xl font-extrabold text-antiqueGold mt-1">₱0</div>
                    <span class="text-[11px] text-slate-400">Nightly rate base</span>
                </div>
            </div>

            <!-- Admin Rooms Management Table -->
            <div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
                <div class="px-6 py-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
                    <div>
                        <h3 class="font-bold text-midnightBlue text-base">Active Room Catalog & Pricing Rules</h3>
                        <p class="text-xs text-slate-400">Click “Edit Room” on any unit to adjust price, description, amenities, or upload a new photo.</p>
                    </div>
                </div>

                <div class="overflow-x-auto">
                    <table class="w-full text-left text-sm text-slate-700">
                        <thead class="bg-slate-100 text-xs uppercase text-slateGray font-semibold tracking-wider">
                            <tr>
                                <th class="px-6 py-3.5">Room & Image</th>
                                <th class="px-6 py-3.5">Suite Type</th>
                                <th class="px-6 py-3.5">Nightly Price (₱)</th>
                                <th class="px-6 py-3.5">Capacity & Floor</th>
                                <th class="px-6 py-3.5">Status</th>
                                <th class="px-6 py-3.5">Cleaning</th>
                                <th class="px-6 py-3.5 text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody id="admin-rooms-table-body" class="divide-y divide-slate-200">
                            <!-- Populated via JS -->
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Admin Staff & User Account Management -->
            <div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
                <div class="px-6 py-4 border-b border-slate-200 bg-slate-50 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                        <div class="flex items-center gap-2">
                            <span class="px-2 py-0.5 rounded bg-purple-100 text-purple-800 text-[10px] font-bold uppercase tracking-wider">Access Control</span>
                            <h3 class="font-bold text-midnightBlue text-base">Staff & User Account Management</h3>
                        </div>
                        <p class="text-xs text-slate-400 mt-0.5">Admin privilege to create, monitor, and configure role accounts for Front Desk, Housekeeping, and Accounting.</p>
                    </div>
                    <div class="flex items-center gap-2">
                        <button onclick="openStaffModal()" class="px-4 py-2 bg-midnightBlue hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow">
                            <svg class="w-3.5 h-3.5 text-antiqueGold" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z"></path></svg>
                            + Create Staff Account
                        </button>
                        <button onclick="loadAdminUsers()" class="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-medium transition">
                            Refresh
                        </button>
                    </div>
                </div>

                <div class="overflow-x-auto">
                    <table class="w-full text-left text-sm text-slate-700">
                        <thead class="bg-slate-100 text-xs uppercase text-slateGray font-semibold tracking-wider">
                            <tr>
                                <th class="px-6 py-3.5">Staff Name</th>
                                <th class="px-6 py-3.5">Email Address</th>
                                <th class="px-6 py-3.5">Role</th>
                                <th class="px-6 py-3.5">Phone Contact</th>
                                <th class="px-6 py-3.5">Created Date</th>
                                <th class="px-6 py-3.5 text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody id="admin-users-table-body" class="divide-y divide-slate-200">
                            <!-- Populated via loadAdminUsers() -->
                        </tbody>
                    </table>
                </div>
            </div>
        </section>


        <!-- ============================================================== -->
        <!-- 3. FRONT DESK CONSOLE                                          -->
        <!-- ============================================================== -->
        <section id="role-frontdesk" class="hidden max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-8">
            <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
                <div>
                    <h2 class="text-2xl sm:text-3xl font-bold text-midnightBlue">Front Desk Console</h2>
                    <p class="text-sm text-slateGray">Manage room status matrix, check-ins, check-outs, and new walk-in arrivals.</p>
                </div>
                <div class="flex items-center gap-2">
                    <button onclick="openWalkInModal()" class="inline-flex items-center gap-2 bg-antiqueGold text-midnightBlue px-4 py-2 rounded-lg font-bold text-sm shadow hover:bg-opacity-90 transition">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>
                        New Walk-In Arrival
                    </button>
                    <button onclick="loadFrontDeskData()" class="bg-midnightBlue text-white px-3.5 py-2 rounded-lg text-xs font-medium hover:bg-opacity-90 transition">
                        Refresh
                    </button>
                </div>
            </div>

            <!-- Guest Receipt & Bill Verification Console -->
            <div class="bg-gradient-to-r from-midnightBlue via-slate-900 to-midnightBlue rounded-2xl p-6 text-white shadow-xl border border-slate-800 space-y-4">
                <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/10 pb-3">
                    <div>
                        <div class="flex items-center gap-2">
                            <span class="px-2.5 py-0.5 rounded bg-antiqueGold text-midnightBlue text-[10px] font-black uppercase tracking-wider">Arrival Protocol</span>
                            <h3 class="text-lg font-bold text-warmIvory">Guest Receipt & Bill Verification</h3>
                        </div>
                        <p class="text-xs text-slate-300 mt-0.5">Verify client booking receipt upon arrival. Check payment status (Fully Paid vs Remaining Balance) and process check-in.</p>
                    </div>
                    <span class="text-xs text-slate-400 italic">Enter booking code from client receipt</span>
                </div>

                <div class="flex flex-col sm:flex-row gap-2.5">
                    <div class="relative flex-1">
                        <input type="text" id="frontdesk-search-input" placeholder="Enter Booking Code (e.g. HRY-B05829) or Guest Name / Phone..." 
                               onkeydown="if(event.key==='Enter') verifyGuestBooking()"
                               class="w-full pl-10 pr-4 py-3 bg-slate-800/90 border border-slate-700 rounded-xl text-sm font-semibold text-white placeholder-slate-400 focus:outline-none focus:border-antiqueGold focus:ring-2 focus:ring-antiqueGold/20" />
                        <svg class="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                    </div>
                    <button onclick="verifyGuestBooking()" class="px-6 py-3 bg-antiqueGold hover:bg-amber-400 active:scale-95 text-midnightBlue font-extrabold text-xs uppercase tracking-wider rounded-xl shadow transition flex items-center justify-center gap-1.5">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                        Verify Booking
                    </button>
                </div>

                <!-- Live Verification Result Panel (shown when verified) -->
                <div id="frontdesk-verification-result" class="hidden bg-slate-800/95 rounded-xl p-5 border border-slate-700 text-xs transition duration-300">
                    <!-- Populated via verifyGuestBooking() -->
                </div>
            </div>

            <!-- Room Status Grid Matrix -->
            <div class="bg-white rounded-xl shadow-sm p-6 border border-slate-200">
                <div class="flex items-center justify-between mb-4">
                    <h3 class="text-sm font-bold text-midnightBlue uppercase tracking-wider">Real-Time Room Management Matrix</h3>
                    <div class="flex items-center gap-3 text-xs font-medium">
                        <span class="flex items-center gap-1.5"><span class="w-3 h-3 rounded-full bg-emerald-500"></span> Available</span>
                        <span class="flex items-center gap-1.5"><span class="w-3 h-3 rounded-full bg-amber-500"></span> Booked</span>
                        <span class="flex items-center gap-1.5"><span class="w-3 h-3 rounded-full bg-rose-500"></span> Occupied</span>
                        <span class="flex items-center gap-1.5"><span class="w-3 h-3 rounded-full bg-slate-400"></span> Maintenance</span>
                    </div>
                </div>
                <div id="frontdesk-rooms-matrix" class="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-3">
                    <!-- Populated via JS -->
                </div>
            </div>

            <!-- Active Bookings Ledger -->
            <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                <div class="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
                    <h3 class="font-bold text-midnightBlue text-sm">Active Bookings & Guest Check-Ins</h3>
                    <span class="text-xs text-slate-400">Showing live arrivals and reservations</span>
                </div>
                <div class="overflow-x-auto">
                    <table class="w-full text-left text-sm text-slate-700">
                        <thead class="bg-slate-100 text-xs uppercase text-slateGray font-semibold tracking-wider">
                            <tr>
                                <th class="px-6 py-3">Booking Code</th>
                                <th class="px-6 py-3">Guest Name</th>
                                <th class="px-6 py-3">Room</th>
                                <th class="px-6 py-3">Dates</th>
                                <th class="px-6 py-3">Source</th>
                                <th class="px-6 py-3">Status</th>
                                <th class="px-6 py-3">Billing</th>
                                <th class="px-6 py-3 text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody id="bookings-table-body" class="divide-y divide-slate-200">
                            <!-- Populated via JS -->
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Guest Roster -->
            <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                <div class="px-6 py-4 border-b border-slate-200 bg-slate-50">
                    <h3 class="font-bold text-midnightBlue text-sm">Registered Guest Directory</h3>
                </div>
                <div class="overflow-x-auto">
                    <table class="w-full text-left text-sm text-slate-700">
                        <thead class="bg-slate-100 text-xs uppercase text-slateGray font-semibold tracking-wider">
                            <tr>
                                <th class="px-6 py-3">Name</th>
                                <th class="px-6 py-3">Contact Email</th>
                                <th class="px-6 py-3">Phone</th>
                                <th class="px-6 py-3">ID Document</th>
                                <th class="px-6 py-3">Preferences</th>
                            </tr>
                        </thead>
                        <tbody id="guests-table-body" class="divide-y divide-slate-200">
                            <!-- Populated via JS -->
                        </tbody>
                    </table>
                </div>
            </div>
        </section>


        <!-- ============================================================== -->
        <!-- 4. HOUSEKEEPING CONSOLE                                         -->
        <!-- ============================================================== -->
        <section id="role-housekeeping" class="hidden max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-8">
            <div class="flex items-center justify-between border-b border-slate-200 pb-4">
                <div>
                    <h2 class="text-2xl sm:text-3xl font-bold text-midnightBlue">Housekeeping Operations</h2>
                    <p class="text-sm text-slateGray">Live room cleaning status tracking and turnover management.</p>
                </div>
                <button onclick="loadHousekeepingData()" class="bg-midnightBlue text-white px-4 py-2 rounded-lg text-xs font-semibold hover:bg-opacity-90 transition">
                    Refresh Status
                </button>
            </div>

            <!-- Stats -->
            <div class="grid grid-cols-1 sm:grid-cols-4 gap-4">
                <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
                    <span class="text-xs font-semibold text-slateGray uppercase">Needs Cleaning (Dirty)</span>
                    <div id="stat-dirty" class="text-3xl font-extrabold text-rose-600 mt-1">0</div>
                </div>
                <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
                    <span class="text-xs font-semibold text-slateGray uppercase">In Progress</span>
                    <div id="stat-progress" class="text-3xl font-extrabold text-amber-600 mt-1">0</div>
                </div>
                <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
                    <span class="text-xs font-semibold text-slateGray uppercase">Clean & Ready</span>
                    <div id="stat-clean" class="text-3xl font-extrabold text-tropicalGreen mt-1">0</div>
                </div>
                <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
                    <span class="text-xs font-semibold text-slateGray uppercase">Under Maintenance</span>
                    <div id="stat-maint" class="text-3xl font-extrabold text-slate-600 mt-1">0</div>
                </div>
            </div>

            <!-- Floor Cleaning Cards -->
            <div class="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                <h3 class="font-bold text-midnightBlue mb-4 text-sm uppercase tracking-wider">Room Cleaning & Turnover Roster</h3>
                <div id="housekeeping-grid" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    <!-- Populated via JS -->
                </div>
            </div>
        </section>


        <!-- ============================================================== -->
        <!-- 5. ACCOUNTING CONSOLE                                           -->
        <!-- ============================================================== -->
        <section id="role-accounting" class="hidden max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-8">
            <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
                <div>
                    <h2 class="text-2xl sm:text-3xl font-bold text-midnightBlue">Financial Ledger & Accounting</h2>
                    <p class="text-sm text-slateGray">Track hotel revenue, room settlements, incidentals, and operational expenses.</p>
                </div>
                <button onclick="openExpenseModal()" class="bg-tropicalGreen text-white px-4 py-2.5 rounded-lg font-bold text-xs sm:text-sm shadow hover:bg-opacity-90 transition flex items-center gap-2">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>
                    Record Hotel Expense
                </button>
            </div>

            <!-- Metric Cards -->
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-6">
                <div class="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                    <span class="text-xs font-bold text-slateGray uppercase tracking-wider">Total Revenue Received</span>
                    <div id="acc-income" class="text-3xl font-extrabold text-tropicalGreen mt-2">₱0.00</div>
                    <span class="text-xs text-slate-400 mt-1 block">Deposits & Final settlements</span>
                </div>
                <div class="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                    <span class="text-xs font-bold text-slateGray uppercase tracking-wider">Total Operational Expenses</span>
                    <div id="acc-expense" class="text-3xl font-extrabold text-rose-600 mt-2">₱0.00</div>
                    <span class="text-xs text-slate-400 mt-1 block">Supplies, utilities & maintenance</span>
                </div>
                <div class="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                    <span class="text-xs font-bold text-slateGray uppercase tracking-wider">Net Hotel Balance</span>
                    <div id="acc-net" class="text-3xl font-extrabold text-midnightBlue mt-2">₱0.00</div>
                    <span class="text-xs text-slate-400 mt-1 block">Operating surplus</span>
                </div>
            </div>

            <!-- Ledger Tables -->
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <!-- Payments -->
                <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                    <div class="px-6 py-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
                        <h3 class="font-bold text-midnightBlue text-sm">Recent Payments Collected</h3>
                        <span class="text-xs text-tropicalGreen font-semibold">Incoming</span>
                    </div>
                    <div class="overflow-x-auto max-h-96">
                        <table class="w-full text-left text-sm text-slate-700">
                            <thead class="bg-slate-100 text-xs text-slateGray uppercase font-semibold sticky top-0">
                                <tr>
                                    <th class="px-4 py-2.5">Date / Ref</th>
                                    <th class="px-4 py-2.5">Guest / Code</th>
                                    <th class="px-4 py-2.5">Method</th>
                                    <th class="px-4 py-2.5 text-right">Amount</th>
                                </tr>
                            </thead>
                            <tbody id="payments-table-body" class="divide-y divide-slate-200">
                                <!-- Populated via JS -->
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Expenses -->
                <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                    <div class="px-6 py-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
                        <h3 class="font-bold text-midnightBlue text-sm">Operational Expenditures</h3>
                        <span class="text-xs text-rose-600 font-semibold">Outgoing</span>
                    </div>
                    <div class="overflow-x-auto max-h-96">
                        <table class="w-full text-left text-sm text-slate-700">
                            <thead class="bg-slate-100 text-xs text-slateGray uppercase font-semibold sticky top-0">
                                <tr>
                                    <th class="px-4 py-2.5">Date / Category</th>
                                    <th class="px-4 py-2.5">Description</th>
                                    <th class="px-4 py-2.5">By</th>
                                    <th class="px-4 py-2.5 text-right">Amount</th>
                                </tr>
                            </thead>
                            <tbody id="expenses-table-body" class="divide-y divide-slate-200">
                                <!-- Populated via JS -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </section>

    </main>


    <!-- ============================================================== -->
    <!-- MODALS SECTION                                                 -->
    <!-- ============================================================== -->

    <!-- MODAL 1: ADMIN EDIT ROOM MODAL (Price, Details, Include Image) -->
    <div id="admin-edit-room-modal" class="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 hidden flex items-center justify-center p-4">
        <div class="bg-white rounded-2xl max-w-2xl w-full max-h-[92vh] overflow-y-auto p-6 sm:p-8 shadow-2xl border border-slate-200 custom-scrollbar">
            <div class="flex items-center justify-between border-b border-slate-200 pb-4 mb-6">
                <div>
                    <div class="flex items-center gap-2">
                        <span class="bg-purple-100 text-purple-800 text-[10px] uppercase tracking-wider font-extrabold px-2 py-0.5 rounded">Admin Control</span>
                        <span id="modal-edit-room-badge" class="text-xs font-bold text-antiqueGold">Room 101</span>
                    </div>
                    <h3 class="text-xl font-extrabold text-midnightBlue mt-0.5">Edit Room Details, Price & Image</h3>
                </div>
                <button onclick="closeModal('admin-edit-room-modal')" class="text-slate-400 hover:text-slate-600 text-2xl leading-none">&times;</button>
            </div>

            <form id="admin-edit-room-form" onsubmit="submitAdminRoomEdit(event)" class="space-y-5 text-sm">
                <input type="hidden" id="edit-room-id" />

                <!-- Room Identity & Price -->
                <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                        <label class="block text-xs font-bold text-slateGray uppercase mb-1">Room Number *</label>
                        <input type="text" id="edit-room-number" required class="w-full px-3.5 py-2.5 border rounded-lg focus:ring-2 focus:ring-antiqueGold focus:outline-none font-bold" />
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-slateGray uppercase mb-1">Room Category *</label>
                        <select id="edit-room-type" required class="w-full px-3.5 py-2.5 border rounded-lg focus:ring-2 focus:ring-antiqueGold focus:outline-none font-medium">
                            <option value="Standard Villa">Standard Villa</option>
                            <option value="Deluxe Haven">Deluxe Haven</option>
                            <option value="Executive Suite">Executive Suite</option>
                            <option value="Presidential Suite">Presidential Suite</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-antiqueGold uppercase mb-1 flex items-center gap-1">
                            <span>Nightly Rate (₱ PHP) *</span>
                        </label>
                        <div class="relative">
                            <span class="absolute left-3 top-2.5 text-slate-400 font-bold">₱</span>
                            <input type="number" id="edit-room-price" required step="50" min="100" class="w-full pl-8 pr-3 py-2.5 border rounded-lg font-bold text-midnightBlue focus:ring-2 focus:ring-antiqueGold focus:outline-none text-base" />
                        </div>
                    </div>
                </div>

                <!-- Capacity, Floor, Statuses -->
                <div class="grid grid-cols-2 sm:grid-cols-4 gap-4">
                    <div>
                        <label class="block text-xs font-semibold text-slateGray mb-1">Guest Capacity</label>
                        <input type="number" id="edit-room-capacity" min="1" max="10" required class="w-full px-3 py-2 border rounded-lg" />
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slateGray mb-1">Floor Level</label>
                        <input type="number" id="edit-room-floor" min="1" max="10" required class="w-full px-3 py-2 border rounded-lg" />
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slateGray mb-1">Room Status</label>
                        <select id="edit-room-status" class="w-full px-3 py-2 border rounded-lg font-medium">
                            <option value="Available">Available</option>
                            <option value="Booked">Booked</option>
                            <option value="Occupied">Occupied</option>
                            <option value="Maintenance">Maintenance</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slateGray mb-1">Cleaning Status</label>
                        <select id="edit-room-cleaning" class="w-full px-3 py-2 border rounded-lg font-medium">
                            <option value="Clean">Clean</option>
                            <option value="Dirty">Dirty</option>
                            <option value="In Progress">In Progress</option>
                            <option value="Inspected">Inspected</option>
                        </select>
                    </div>
                </div>

                <!-- Description / Details -->
                <div>
                    <label class="block text-xs font-bold text-slateGray uppercase mb-1">Room Description & Details *</label>
                    <textarea id="edit-room-description" rows="3" required placeholder="Describe the ambiance, view, architectural elements, bedding..." class="w-full px-3.5 py-2.5 border rounded-lg focus:ring-2 focus:ring-antiqueGold focus:outline-none leading-relaxed text-xs sm:text-sm"></textarea>
                </div>

                <!-- Amenities -->
                <div>
                    <label class="block text-xs font-bold text-slateGray uppercase mb-1">Room Amenities (comma separated)</label>
                    <input type="text" id="edit-room-amenities" placeholder="e.g. King Bed, Free Wi-Fi, Balcony, Smart TV, Mini Bar, Private Plunge Pool" class="w-full px-3.5 py-2.5 border rounded-lg focus:ring-2 focus:ring-antiqueGold focus:outline-none text-xs sm:text-sm" />
                </div>

                <!-- Room Image Section: URL + File Upload + Presets -->
                <div class="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
                    <label class="block text-xs font-bold text-midnightBlue uppercase tracking-wider">Room Image & Visual Asset</label>
                    
                    <div>
                        <label class="block text-[11px] font-semibold text-slate-500 mb-1">Image URL:</label>
                        <input type="url" id="edit-room-image-url" oninput="updateImagePreview(this.value)" placeholder="https://images.unsplash.com/photo-..." class="w-full px-3 py-2 border rounded-lg text-xs focus:ring-2 focus:ring-antiqueGold focus:outline-none font-mono" />
                    </div>

                    <!-- Quick Luxury Presets Picker -->
                    <div>
                        <span class="block text-[11px] font-semibold text-slate-500 mb-1.5">Quick Select Luxury Presets:</span>
                        <div class="flex flex-wrap gap-2 text-xs">
                            <button type="button" onclick="selectPresetImage('https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=800&q=80')" class="px-2.5 py-1 bg-white hover:bg-slate-200 border rounded text-slate-700 font-medium">Standard Villa</button>
                            <button type="button" onclick="selectPresetImage('https://images.unsplash.com/photo-1566665797739-1674de7a421a?auto=format&fit=crop&w=800&q=80')" class="px-2.5 py-1 bg-white hover:bg-slate-200 border rounded text-slate-700 font-medium">Deluxe Oceanview</button>
                            <button type="button" onclick="selectPresetImage('https://images.unsplash.com/photo-1618773928121-c32242e63f39?auto=format&fit=crop&w=800&q=80')" class="px-2.5 py-1 bg-white hover:bg-slate-200 border rounded text-slate-700 font-medium">Executive Pool Suite</button>
                            <button type="button" onclick="selectPresetImage('https://images.unsplash.com/photo-1582719508461-905c673771fd?auto=format&fit=crop&w=800&q=80')" class="px-2.5 py-1 bg-white hover:bg-slate-200 border rounded text-slate-700 font-medium">Presidential Suite</button>
                        </div>
                    </div>

                    <!-- File Upload Option -->
                    <div class="pt-2 border-t border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        <div class="flex-1">
                            <label class="block text-[11px] font-semibold text-slate-500 mb-1">Or Upload Image File from Computer:</label>
                            <input type="file" id="edit-room-image-file" accept="image/*" class="text-xs text-slate-600 file:mr-3 file:py-1 file:px-3 file:rounded-md file:border-0 file:text-xs file:font-semibold file:bg-midnightBlue file:text-white hover:file:bg-slate-800" />
                        </div>
                        <button type="button" onclick="uploadAdminRoomFile()" class="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-semibold self-start sm:self-end">
                            Upload File
                        </button>
                    </div>

                    <!-- Live Image Preview Box -->
                    <div class="pt-2">
                        <span class="block text-[11px] font-semibold text-slate-500 mb-1">Live Visual Preview:</span>
                        <div class="h-44 w-full rounded-xl overflow-hidden bg-slate-200 border border-slate-300 relative">
                            <img id="edit-room-image-preview" src="" alt="Room preview" class="w-full h-full object-cover">
                            <div id="edit-room-no-image-placeholder" class="hidden absolute inset-0 flex items-center justify-center text-xs text-slate-400">
                                No image specified
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Action Buttons -->
                <div class="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
                    <button type="button" onclick="closeModal('admin-edit-room-modal')" class="px-4 py-2.5 text-slate-600 hover:text-slate-800 font-medium text-xs sm:text-sm">
                        Cancel
                    </button>
                    <button type="submit" class="px-6 py-2.5 bg-gradient-to-r from-purple-700 to-indigo-800 hover:from-purple-800 hover:to-indigo-900 text-white font-bold rounded-xl shadow-lg transition flex items-center gap-2">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
                        Save Room Changes
                    </button>
                </div>
            </form>
        </div>
    </div>


    <!-- MODAL 2: SIGN IN MODAL -->
    <div id="login-modal" class="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 hidden flex items-center justify-center p-4">
        <div class="bg-white rounded-2xl max-w-md w-full p-6 sm:p-8 shadow-2xl border border-slate-200">
            <div class="flex items-center justify-between border-b border-slate-200 pb-3 mb-5">
                <div>
                    <h3 class="text-xl font-bold text-midnightBlue">Sign In to Hiraya</h3>
                    <p class="text-xs text-slateGray mt-0.5">Access role-authorized hotel consoles</p>
                </div>
                <button onclick="closeModal('login-modal')" class="text-slate-400 hover:text-slate-600 text-2xl leading-none">&times;</button>
            </div>

            <form id="login-form" onsubmit="submitLogin(event)" class="space-y-4 text-sm">
                <div>
                    <label class="block text-xs font-semibold text-slateGray mb-1">Email Address *</label>
                    <input type="email" id="login-email" required placeholder="admin@hiraya.com" class="w-full px-3.5 py-2.5 border rounded-lg focus:ring-2 focus:ring-antiqueGold focus:outline-none" />
                </div>
                <div>
                    <label class="block text-xs font-semibold text-slateGray mb-1">Password *</label>
                    <input type="password" id="login-password" required placeholder="••••••••" class="w-full px-3.5 py-2.5 border rounded-lg focus:ring-2 focus:ring-antiqueGold focus:outline-none" />
                </div>

                <button type="submit" class="w-full py-2.5 bg-midnightBlue hover:bg-slate-800 text-white font-bold rounded-lg shadow transition">
                    Sign In
                </button>
            </form>

            <!-- Role Credentials Cheatsheet for User Testing -->
            <div class="mt-4 p-3 bg-slate-50 border border-slate-200 rounded-lg text-[11px] text-slate-600 space-y-1">
                <span class="font-bold text-midnightBlue block">Quick Credentials: (Password: hiraya123)</span>
                <div>&bull; Admin: <code class="text-purple-700 font-bold">admin@hiraya.com</code></div>
                <div>&bull; Front Desk: <code class="text-emerald-700 font-bold">fd@hiraya.com</code></div>
                <div>&bull; Housekeeping: <code class="text-amber-700 font-bold">hk@hiraya.com</code></div>
                <div>&bull; Accounting: <code class="text-sky-700 font-bold">AC@hiraya.com</code></div>
            </div>

            <div class="mt-4 pt-3 border-t border-slate-100 text-center text-xs text-slateGray">
                Don't have an account? 
                <button onclick="closeModal('login-modal'); openModal('register-modal');" class="text-antiqueGold font-bold hover:underline">
                    Register Here
                </button>
            </div>
        </div>
    </div>


    <!-- MODAL 3: REGISTER MODAL (Strictly Guest / User Role) -->
    <div id="register-modal" class="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 hidden flex items-center justify-center p-4">
        <div class="bg-white rounded-2xl max-w-md w-full p-6 sm:p-8 shadow-2xl border border-slate-200">
            <div class="flex items-center justify-between border-b border-slate-200 pb-3 mb-5">
                <div>
                    <h3 class="text-xl font-bold text-midnightBlue">Create Guest Account</h3>
                    <p class="text-xs text-slateGray mt-0.5">Register as a guest to book your luxury stay</p>
                </div>
                <button onclick="closeModal('register-modal')" class="text-slate-400 hover:text-slate-600 text-2xl leading-none">&times;</button>
            </div>

            <form id="register-form" onsubmit="submitRegister(event)" class="space-y-3.5 text-sm">
                <div>
                    <label class="block text-xs font-semibold text-slateGray mb-1">Full Name *</label>
                    <input type="text" id="reg-name" required placeholder="e.g. Maria Santos" class="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-antiqueGold focus:outline-none" />
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slateGray mb-1">Email Address *</label>
                    <input type="email" id="reg-email" required placeholder="maria@hiraya.com" class="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-antiqueGold focus:outline-none" />
                </div>

                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block text-xs font-semibold text-slateGray mb-1">Password *</label>
                        <input type="password" id="reg-password" required minlength="6" placeholder="Min 6 chars" class="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-antiqueGold focus:outline-none" />
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slateGray mb-1">Phone Number</label>
                        <input type="tel" id="reg-phone" placeholder="+63 9XX" class="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-antiqueGold focus:outline-none" />
                    </div>
                </div>

                <button type="submit" class="w-full py-2.5 bg-antiqueGold hover:bg-amber-400 text-midnightBlue font-bold rounded-lg shadow transition mt-2">
                    Create Account
                </button>
            </form>

            <div class="mt-4 pt-3 border-t border-slate-100 text-center text-xs text-slateGray">
                Already registered? 
                <button onclick="closeModal('register-modal'); openModal('login-modal');" class="text-midnightBlue font-bold hover:underline">
                    Sign In
                </button>
            </div>
        </div>
    </div>


    <!-- MODAL 4: ONLINE BOOKING MODAL (Full Payment or Deposit Options) -->
    <div id="booking-modal" class="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 hidden flex items-center justify-center p-4">
        <div class="bg-white rounded-2xl max-w-xl w-full max-h-[90vh] overflow-y-auto p-6 sm:p-8 shadow-2xl border border-slate-200 custom-scrollbar">
            <div class="flex items-center justify-between border-b border-slate-200 pb-4 mb-6">
                <div>
                    <h3 class="text-xl font-bold text-midnightBlue">Complete Your Reservation</h3>
                    <p id="modal-room-title" class="text-xs text-antiqueGold font-semibold uppercase tracking-wider mt-0.5"></p>
                </div>
                <button onclick="closeModal('booking-modal')" class="text-slate-400 hover:text-slate-600 text-2xl leading-none">&times;</button>
            </div>

            <form id="online-booking-form" onsubmit="submitOnlineBooking(event)" class="space-y-4 text-sm">
                <input type="hidden" id="modal-room-id" />
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-xs font-semibold text-slateGray mb-1">Check-in *</label>
                        <input type="date" id="modal-check-in" required onchange="onModalDatesChange()" class="w-full px-3 py-2 border rounded-md font-semibold text-slate-800" />
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slateGray mb-1">Check-out *</label>
                        <input type="date" id="modal-check-out" required onchange="onModalDatesChange()" class="w-full px-3 py-2 border rounded-md font-semibold text-slate-800" />
                    </div>
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slateGray mb-1">Full Name *</label>
                    <input type="text" id="modal-full-name" required placeholder="e.g. Maria Santos" class="w-full px-3 py-2 border rounded-md" />
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-xs font-semibold text-slateGray mb-1">Email Address</label>
                        <input type="email" id="modal-email" placeholder="maria@example.com" class="w-full px-3 py-2 border rounded-md" />
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slateGray mb-1">Phone Number *</label>
                        <input type="tel" id="modal-phone" required placeholder="+63 9XX XXX XXXX" class="w-full px-3 py-2 border rounded-md" />
                    </div>
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slateGray mb-1">Stay Preferences / Dietary Requests</label>
                    <input type="text" id="modal-preferences" placeholder="e.g. High floor, extra pillows, vegan breakfast" class="w-full px-3 py-2 border rounded-md" />
                </div>

                <!-- Payment Option Selector: Full Payment vs Deposit -->
                <div>
                    <label class="block text-xs font-bold text-slateGray mb-2 uppercase tracking-wider">Choose Payment Option *</label>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <label id="pay-opt-deposit-card" class="relative flex flex-col p-3 rounded-xl border-2 border-antiqueGold bg-amber-50/60 cursor-pointer transition">
                            <div class="flex items-center justify-between mb-1">
                                <span class="text-xs font-bold text-midnightBlue flex items-center gap-2">
                                    <input type="radio" name="modal_payment_option" value="Deposit" checked onchange="onPaymentOptionChange()" class="text-antiqueGold focus:ring-antiqueGold" />
                                    Pay 30% Deposit
                                </span>
                                <span class="text-[10px] bg-amber-200 text-amber-900 font-bold px-2 py-0.5 rounded">Lock Room</span>
                            </div>
                            <p class="text-[11px] text-slate-500 pl-5">Pay deposit now to secure reservation. Settle the 70% balance at the Front Desk upon arrival.</p>
                        </label>
                        <label id="pay-opt-full-card" class="relative flex flex-col p-3 rounded-xl border-2 border-slate-200 hover:border-antiqueGold/60 cursor-pointer transition">
                            <div class="flex items-center justify-between mb-1">
                                <span class="text-xs font-bold text-midnightBlue flex items-center gap-2">
                                    <input type="radio" name="modal_payment_option" value="Full Payment" onchange="onPaymentOptionChange()" class="text-antiqueGold focus:ring-antiqueGold" />
                                    Full Payment (100%)
                                </span>
                                <span class="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded">Express Check-In</span>
                            </div>
                            <p class="text-[11px] text-slate-500 pl-5">Pay total stay now. ₱0.00 balance due when presenting your receipt at Front Desk.</p>
                        </label>
                    </div>
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slateGray mb-1">Payment Method</label>
                    <select id="modal-payment-method" class="w-full px-3 py-2 border rounded-md font-medium text-slate-800 bg-white">
                        <option value="Online / GCash">Online / GCash</option>
                        <option value="Credit Card">Credit Card</option>
                        <option value="Bank Transfer">Bank Transfer</option>
                    </select>
                </div>

                <!-- Financial Calculation Summary Box -->
                <div class="bg-warmIvory p-4 rounded-xl border border-antiqueGold/40 space-y-2 text-xs text-slate-700">
                    <div class="flex justify-between items-center">
                        <span>Total Stay (<span id="modal-nights">1</span> Night/s):</span>
                        <span id="modal-total-display" class="font-extrabold text-midnightBlue text-sm">₱0.00</span>
                    </div>
                    <div class="flex justify-between items-center text-tropicalGreen font-bold border-t border-slate-200 pt-2 text-sm">
                        <span id="modal-pay-label">Amount to Pay Now (30% Deposit):</span>
                        <span id="modal-deposit-display" class="text-base text-tropicalGreen">₱0.00</span>
                    </div>
                    <div id="modal-balance-row" class="flex justify-between items-center text-slate-500 pt-0.5 text-[11px]">
                        <span>Remaining Balance (Due at Front Desk):</span>
                        <span id="modal-balance-display" class="font-bold text-amber-700">₱0.00</span>
                    </div>
                </div>

                <div class="flex items-center justify-end gap-3 pt-3">
                    <button type="button" onclick="closeModal('booking-modal')" class="px-4 py-2 text-slate-600 hover:text-slate-800 font-medium text-xs">Cancel</button>
                    <button type="submit" id="modal-submit-btn" class="px-6 py-2.5 bg-antiqueGold hover:bg-amber-400 active:scale-95 text-midnightBlue font-extrabold rounded-xl shadow-md transition flex items-center gap-2 text-xs sm:text-sm">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                        <span id="modal-submit-label">Confirm & Pay Deposit</span>
                    </button>
                </div>
            </form>
        </div>
    </div>


    <!-- MODAL: OFFICIAL BOOKING CONFIRMATION & DOWNLOADABLE RECEIPT -->
    <div id="receipt-modal" class="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 hidden flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
        <div class="bg-white rounded-3xl max-w-2xl w-full max-h-[92vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden">
            
            <!-- Modal Top Bar (Non-Printable) -->
            <div class="no-print bg-slate-900 text-white px-6 py-3 flex items-center justify-between border-b border-slate-800">
                <div class="flex items-center gap-2">
                    <span class="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
                    <span class="text-xs font-bold uppercase tracking-wider text-antiqueGold">Official Guest Folio & Receipt</span>
                </div>
                <div class="flex items-center gap-2">
                    <button onclick="printReceipt()" class="px-3 py-1.5 bg-antiqueGold text-midnightBlue hover:bg-amber-400 rounded-lg text-xs font-bold transition flex items-center gap-1.5 shadow">
                        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"></path></svg>
                        Print / Download PDF
                    </button>
                    <button onclick="downloadReceiptHtml()" class="px-3 py-1.5 bg-slate-800 text-slate-200 hover:text-white rounded-lg text-xs font-semibold transition flex items-center gap-1.5 border border-slate-700">
                        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path></svg>
                        Save File
                    </button>
                    <button onclick="closeModal('receipt-modal')" class="text-slate-400 hover:text-white text-2xl leading-none px-2">&times;</button>
                </div>
            </div>

            <!-- Printable Receipt Content Area -->
            <div id="receipt-printable-content" class="p-6 sm:p-8 overflow-y-auto custom-scrollbar space-y-6 text-slate-800 bg-white">
                <!-- Resort Header -->
                <div class="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-200 pb-5 gap-4">
                    <div class="flex items-center space-x-3">
                        <div class="w-12 h-12 rounded-full bg-gradient-to-tr from-antiqueGold to-amber-200 flex items-center justify-center text-midnightBlue font-black text-2xl shadow">
                            H
                        </div>
                        <div>
                            <h1 class="text-2xl font-black tracking-widest text-midnightBlue font-serif">HIRAYA</h1>
                            <span class="text-[10px] uppercase tracking-widest text-slate-400 block -mt-1 font-sans">Resort & Residences &bull; Boracay Island</span>
                        </div>
                    </div>
                    <div class="text-left sm:text-right">
                        <span class="text-[10px] text-slate-400 uppercase tracking-widest block font-bold">Booking Confirmation</span>
                        <span id="rcpt-code" class="text-xl font-black text-antiqueGold font-mono tracking-wider">HRY-000000</span>
                        <span id="rcpt-date" class="text-xs text-slate-400 block mt-0.5">Issued: Oct 20, 2026</span>
                    </div>
                </div>

                <!-- Bill Status Banner -->
                <div id="rcpt-status-banner" class="rounded-2xl p-4 border flex items-start gap-3.5 bg-emerald-50 border-emerald-200 text-emerald-900">
                    <!-- Populated dynamically via JS -->
                </div>

                <!-- Guest & Stay Details Grid -->
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs bg-slate-50 p-4 rounded-2xl border border-slate-100">
                    <div class="space-y-1">
                        <span class="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Guest Information</span>
                        <div id="rcpt-guest-name" class="font-bold text-sm text-midnightBlue">Maria Santos</div>
                        <div id="rcpt-guest-contact" class="text-slate-600">maria@example.com &bull; +63 917 123 4567</div>
                        <div id="rcpt-special" class="text-[11px] text-slate-500 italic pt-1">Preferences: None</div>
                    </div>
                    <div class="space-y-1 sm:border-l sm:border-slate-200 sm:pl-4">
                        <span class="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Accommodation</span>
                        <div id="rcpt-room-title" class="font-bold text-sm text-midnightBlue">Room 101 — Standard Villa</div>
                        <div id="rcpt-dates" class="text-slate-600">Check-in: 2026-10-20 &rarr; Check-out: 2026-10-21</div>
                        <div id="rcpt-nights" class="text-slate-500 font-medium">Duration: 1 Night (Floor 1)</div>
                    </div>
                </div>

                <!-- Financial Breakdown Table -->
                <div class="rounded-xl border border-slate-200 overflow-hidden text-xs">
                    <div class="bg-slate-100 px-4 py-2 font-bold text-slate-700 flex justify-between uppercase tracking-wider text-[11px]">
                        <span>Description & Charges</span>
                        <span>Amount</span>
                    </div>
                    <div class="p-4 space-y-2">
                        <div class="flex justify-between">
                            <span id="rcpt-item-desc">Accommodation Charges (1 Night)</span>
                            <span id="rcpt-item-subtotal" class="font-semibold text-slate-800">₱0.00</span>
                        </div>
                        <div class="flex justify-between text-slate-500 text-[11px]">
                            <span>Taxes & Environmental Resort Fees</span>
                            <span>Included</span>
                        </div>
                        <div class="border-t border-slate-200 pt-2 flex justify-between font-bold text-sm text-midnightBlue">
                            <span>Total Accommodation Amount:</span>
                            <span id="rcpt-total-amount">₱0.00</span>
                        </div>
                    </div>
                </div>

                <!-- Payment Ledger -->
                <div class="rounded-xl border border-slate-200 overflow-hidden text-xs">
                    <div class="bg-slate-100 px-4 py-2 font-bold text-slate-700 flex justify-between uppercase tracking-wider text-[11px]">
                        <span>Payment Activity & Credits</span>
                        <span>Status</span>
                    </div>
                    <div class="p-4 space-y-2">
                        <div class="flex justify-between items-center">
                            <div>
                                <span id="rcpt-payment-type" class="font-bold text-slate-800 block">Payment</span>
                                <span id="rcpt-payment-meta" class="text-[11px] text-slate-400">Method: Online &bull; Ref: N/A</span>
                            </div>
                            <span id="rcpt-paid-amount" class="text-sm font-bold text-tropicalGreen">+₱0.00</span>
                        </div>
                        <div class="border-t border-dashed border-slate-200 pt-2.5 flex justify-between items-center text-sm font-black">
                            <span>Balance Due at Front Desk Check-in:</span>
                            <span id="rcpt-balance-amount" class="text-base text-amber-700">₱0.00</span>
                        </div>
                    </div>
                </div>

                <!-- Front Desk Arrival Instruction Note -->
                <div class="bg-amber-50 border border-amber-200 p-4 rounded-2xl text-[11px] text-slate-700 flex items-start gap-3">
                    <span class="text-xl">🛎️</span>
                    <div>
                        <strong class="text-amber-900 block font-bold text-xs mb-0.5">Front Desk Verification Protocol:</strong>
                        Please present this confirmation receipt (digital on phone or printed) to the Front Desk upon arrival.
                        Our concierge staff will verify your booking code, review bill payment status, settle any remaining balance, and issue your villa access keycard.
                    </div>
                </div>

                <div class="text-center text-[10px] text-slate-400 pt-2 border-t border-slate-100">
                    Hiraya Resort & Residences &bull; Station 1, White Beach, Boracay Island &bull; reservations@hirayahotel.ph &bull; +63 917 123 4567
                </div>
            </div>

            <!-- Modal Bottom Bar (Non-Printable) -->
            <div class="no-print bg-slate-50 px-6 py-3.5 border-t border-slate-200 flex items-center justify-between">
                <span class="text-xs text-slate-500">Instant verification at Front Desk</span>
                <div class="flex items-center gap-2">
                    <button onclick="closeModal('receipt-modal')" class="px-5 py-2 bg-midnightBlue text-white font-bold rounded-xl text-xs hover:bg-slate-800 transition">
                        Done / Close
                    </button>
                </div>
            </div>
        </div>
    </div>


    <!-- MODAL: ADMIN CREATE STAFF ACCOUNT -->
    <div id="staff-modal" class="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 hidden flex items-center justify-center p-4">
        <div class="bg-white rounded-2xl max-w-md w-full p-6 sm:p-8 shadow-2xl border border-slate-200">
            <div class="flex items-center justify-between border-b border-slate-200 pb-3 mb-5">
                <div>
                    <h3 class="text-xl font-bold text-midnightBlue">Create Staff Account</h3>
                    <p class="text-xs text-slateGray mt-0.5">Assign internal credentials for resort departments</p>
                </div>
                <button onclick="closeModal('staff-modal')" class="text-slate-400 hover:text-slate-600 text-2xl leading-none">&times;</button>
            </div>

            <form id="staff-form" onsubmit="submitCreateStaff(event)" class="space-y-3.5 text-sm">
                <div>
                    <label class="block text-xs font-semibold text-slateGray mb-1">Full Name *</label>
                    <input type="text" id="staff-name" required placeholder="e.g. Carlos Mendoza" class="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-antiqueGold focus:outline-none" />
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slateGray mb-1">Email Address *</label>
                    <input type="email" id="staff-email" required placeholder="carlos@hiraya.com" class="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-antiqueGold focus:outline-none" />
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slateGray mb-1">Password * (Min 6 characters)</label>
                    <input type="password" id="staff-password" required minlength="6" placeholder="Password" class="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-antiqueGold focus:outline-none" />
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slateGray mb-1">Staff Role *</label>
                    <select id="staff-role" class="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-antiqueGold focus:outline-none font-semibold">
                        <option value="Front Desk" selected>Front Desk Staff</option>
                        <option value="Housekeeping">Housekeeping Staff</option>
                        <option value="Accounting">Accounting Officer</option>
                        <option value="Admin">System Administrator</option>
                    </select>
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slateGray mb-1">Phone Number</label>
                    <input type="tel" id="staff-phone" placeholder="+63 9XX XXX XXXX" class="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-antiqueGold focus:outline-none" />
                </div>

                <div class="flex items-center justify-end gap-2 pt-2">
                    <button type="button" onclick="closeModal('staff-modal')" class="px-4 py-2 text-slate-600 hover:text-slate-800 text-xs">Cancel</button>
                    <button type="submit" class="px-5 py-2.5 bg-purple-700 hover:bg-purple-800 text-white font-bold rounded-lg shadow text-xs transition">
                        Create Staff Account
                    </button>
                </div>
            </form>
        </div>
    </div>


    <!-- MODAL: FRONT DESK SETTLE REMAINING BALANCE -->
    <div id="balance-settle-modal" class="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 hidden flex items-center justify-center p-4">
        <div class="bg-white rounded-2xl max-w-md w-full p-6 sm:p-8 shadow-2xl border border-slate-200">
            <div class="flex items-center justify-between border-b border-slate-200 pb-3 mb-5">
                <div>
                    <h3 class="text-xl font-bold text-midnightBlue">Settle Guest Balance</h3>
                    <p id="settle-booking-code" class="text-xs text-antiqueGold font-bold mt-0.5">Booking: HRY-000000</p>
                </div>
                <button onclick="closeModal('balance-settle-modal')" class="text-slate-400 hover:text-slate-600 text-2xl leading-none">&times;</button>
            </div>

            <form id="settle-balance-form" onsubmit="submitSettleBalance(event)" class="space-y-4 text-sm">
                <input type="hidden" id="settle-booking-id" />

                <div class="bg-amber-50 border border-amber-200 p-4 rounded-xl text-xs space-y-1.5 text-slate-700">
                    <div class="flex justify-between">
                        <span>Guest Name:</span>
                        <strong id="settle-guest-name" class="text-midnightBlue">Maria Santos</strong>
                    </div>
                    <div class="flex justify-between">
                        <span>Room:</span>
                        <strong id="settle-room-info" class="text-midnightBlue">Room 101</strong>
                    </div>
                    <div class="flex justify-between">
                        <span>Total Bill:</span>
                        <span id="settle-total-bill" class="font-semibold">₱0.00</span>
                    </div>
                    <div class="flex justify-between">
                        <span>Deposit Already Paid:</span>
                        <span id="settle-paid-so-far" class="text-tropicalGreen font-semibold">₱0.00</span>
                    </div>
                    <div class="border-t border-amber-200 pt-1.5 flex justify-between font-bold text-sm text-amber-900">
                        <span>Outstanding Balance Due:</span>
                        <span id="settle-balance-due" class="text-base text-rose-600">₱0.00</span>
                    </div>
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slateGray mb-1">Amount to Collect (₱) *</label>
                    <input type="number" step="0.01" id="settle-amount" required class="w-full px-3 py-2 border rounded-lg font-bold text-slate-800 text-base focus:ring-2 focus:ring-antiqueGold focus:outline-none" />
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slateGray mb-1">Payment Method *</label>
                    <select id="settle-payment-method" class="w-full px-3 py-2 border rounded-lg font-semibold text-slate-800 focus:ring-2 focus:ring-antiqueGold focus:outline-none">
                        <option value="Cash" selected>Cash (Front Desk Till)</option>
                        <option value="Credit Card">Credit Card Terminal</option>
                        <option value="Online / GCash">Online / GCash QR</option>
                        <option value="Bank Transfer">Bank Transfer</option>
                    </select>
                </div>

                <div class="flex items-center justify-end gap-2 pt-2">
                    <button type="button" onclick="closeModal('balance-settle-modal')" class="px-4 py-2 text-slate-600 hover:text-slate-800 text-xs font-medium">Cancel</button>
                    <button type="submit" class="px-5 py-2.5 bg-tropicalGreen hover:bg-emerald-700 text-white font-bold rounded-lg shadow text-xs transition flex items-center gap-1.5">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
                        Collect & Mark Fully Paid
                    </button>
                </div>
            </form>
        </div>
    </div>


    <!-- MODAL 5: WALK-IN CLIENT WORKFLOW MODAL -->
    <div id="walkin-modal" class="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 hidden flex items-center justify-center p-4">
        <div class="bg-white rounded-2xl max-w-xl w-full max-h-[90vh] overflow-y-auto p-6 sm:p-8 shadow-2xl border border-slate-200 custom-scrollbar">
            <div class="flex items-center justify-between border-b border-slate-200 pb-4 mb-6">
                <div>
                    <h3 class="text-xl font-bold text-midnightBlue">Walk-In Client Workflow</h3>
                    <p class="text-xs text-slateGray mt-0.5">Front desk client registration & immediate check-in</p>
                </div>
                <button onclick="closeModal('walkin-modal')" class="text-slate-400 hover:text-slate-600 text-2xl leading-none">&times;</button>
            </div>

            <form id="walkin-form" onsubmit="submitWalkInBooking(event)" class="space-y-4 text-sm">
                <div>
                    <label class="block text-xs font-semibold text-slateGray mb-1">Select Available Room *</label>
                    <select id="walkin-room-id" required class="w-full px-3 py-2 border rounded-md">
                        <!-- Populated with currently available rooms -->
                    </select>
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-xs font-semibold text-slateGray mb-1">Check-in</label>
                        <input type="date" id="walkin-check-in" required class="w-full px-3 py-2 border rounded-md" />
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slateGray mb-1">Check-out</label>
                        <input type="date" id="walkin-check-out" required class="w-full px-3 py-2 border rounded-md" />
                    </div>
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slateGray mb-1">Guest Full Name *</label>
                    <input type="text" id="walkin-name" required placeholder="Guest Name" class="w-full px-3 py-2 border rounded-md" />
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-xs font-semibold text-slateGray mb-1">Phone Number *</label>
                        <input type="tel" id="walkin-phone" required placeholder="+63 9XX XXX XXXX" class="w-full px-3 py-2 border rounded-md" />
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slateGray mb-1">ID Number / Type</label>
                        <input type="text" id="walkin-id" placeholder="Passport or Driver License" class="w-full px-3 py-2 border rounded-md" />
                    </div>
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slateGray mb-1">Guest Preferences / Requests</label>
                    <input type="text" id="walkin-preferences" placeholder="e.g. Extra key card, quiet corner" class="w-full px-3 py-2 border rounded-md" />
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-xs font-semibold text-slateGray mb-1">Payment Method</label>
                        <select id="walkin-payment-method" class="w-full px-3 py-2 border rounded-md">
                            <option>Cash</option>
                            <option>Credit Card</option>
                            <option>Online / GCash</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slateGray mb-1">Payment Received (₱)</label>
                        <input type="number" id="walkin-payment-amount" step="0.01" placeholder="Leave empty for full price" class="w-full px-3 py-2 border rounded-md" />
                    </div>
                </div>

                <div class="p-3 bg-slate-50 border border-slate-200 rounded text-xs text-slateGray">
                    &bull; System will record the booking and change the room status directly to <strong>“Occupied”</strong> upon submission.
                </div>

                <div class="flex items-center justify-end gap-3 pt-3">
                    <button type="button" onclick="closeModal('walkin-modal')" class="px-4 py-2 text-slate-600 hover:text-slate-800">Cancel</button>
                    <button type="submit" class="px-6 py-2.5 bg-midnightBlue text-white font-bold rounded-lg shadow hover:bg-opacity-95 transition">
                        Register & Check-In Guest
                    </button>
                </div>
            </form>
        </div>
    </div>


    <!-- MODAL 6: CHECKOUT FOLIO SETTLEMENT MODAL -->
    <div id="checkout-modal" class="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 hidden flex items-center justify-center p-4">
        <div class="bg-white rounded-2xl max-w-md w-full p-6 sm:p-8 shadow-2xl border border-slate-200">
            <div class="flex items-center justify-between border-b border-slate-200 pb-3 mb-4">
                <h3 class="text-lg font-bold text-midnightBlue">Finalize Checkout & Settlement</h3>
                <button onclick="closeModal('checkout-modal')" class="text-slate-400 hover:text-slate-600 text-2xl leading-none">&times;</button>
            </div>

            <form id="checkout-form" onsubmit="submitCheckout(event)" class="space-y-4 text-sm">
                <input type="hidden" id="checkout-booking-id" />
                <div class="p-3 bg-warmIvory rounded-lg border border-slate-200 text-xs space-y-1">
                    <div class="flex justify-between">
                        <span class="text-slateGray">Guest Name:</span>
                        <strong id="checkout-guest-name" class="text-midnightBlue"></strong>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-slateGray">Room Number:</span>
                        <strong id="checkout-room-number" class="text-midnightBlue"></strong>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-slateGray">Total Room Charge:</span>
                        <span id="checkout-room-total">₱0.00</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-slateGray">Already Paid:</span>
                        <span id="checkout-already-paid" class="text-tropicalGreen font-semibold">₱0.00</span>
                    </div>
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slateGray mb-1">Extra Charges / Mini-bar / Incidentals (₱)</label>
                    <input type="number" id="checkout-extra" value="0.00" step="0.01" oninput="updateCheckoutBalance()" class="w-full px-3 py-2 border rounded-md" />
                </div>

                <div class="flex justify-between text-base font-bold text-midnightBlue p-3 bg-slate-100 rounded-lg">
                    <span>Remaining Balance to Settle:</span>
                    <span id="checkout-balance" class="text-rose-600">₱0.00</span>
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slateGray mb-1">Settlement Payment Method</label>
                    <select id="checkout-payment-method" class="w-full px-3 py-2 border rounded-md">
                        <option>Cash</option>
                        <option>Credit Card</option>
                        <option>Online / GCash</option>
                    </select>
                </div>

                <p class="text-xs text-slate-500 italic">
                    * Finalizing checkout will close the folio and automatically notify Housekeeping that this room needs cleaning.
                </p>

                <div class="flex items-center justify-end gap-3 pt-3">
                    <button type="button" onclick="closeModal('checkout-modal')" class="px-4 py-2 text-slate-600 hover:text-slate-800">Cancel</button>
                    <button type="submit" class="px-6 py-2.5 bg-rose-600 text-white font-bold rounded-lg shadow hover:bg-rose-700 transition">
                        Complete Checkout
                    </button>
                </div>
            </form>
        </div>
    </div>


    <!-- MODAL 7: RECORD HOTEL EXPENSE MODAL -->
    <div id="expense-modal" class="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 hidden flex items-center justify-center p-4">
        <div class="bg-white rounded-2xl max-w-md w-full p-6 sm:p-8 shadow-2xl border border-slate-200">
            <div class="flex items-center justify-between border-b border-slate-200 pb-3 mb-4">
                <h3 class="text-lg font-bold text-midnightBlue">Record Hotel Operational Expense</h3>
                <button onclick="closeModal('expense-modal')" class="text-slate-400 hover:text-slate-600 text-2xl leading-none">&times;</button>
            </div>

            <form id="expense-form" onsubmit="submitExpense(event)" class="space-y-4 text-sm">
                <div>
                    <label class="block text-xs font-semibold text-slateGray mb-1">Expense Category</label>
                    <select id="expense-category" class="w-full px-3 py-2 border rounded-md">
                        <option>Housekeeping Supplies</option>
                        <option>Utilities</option>
                        <option>Maintenance</option>
                        <option>Staff Payroll</option>
                        <option>Food & Beverage</option>
                        <option>Other</option>
                    </select>
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slateGray mb-1">Description *</label>
                    <input type="text" id="expense-desc" required placeholder="e.g. Bed linen restock, pool treatment" class="w-full px-3 py-2 border rounded-md" />
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slateGray mb-1">Amount (₱) *</label>
                    <input type="number" id="expense-amount" required step="0.01" placeholder="0.00" class="w-full px-3 py-2 border rounded-md" />
                </div>

                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block text-xs font-semibold text-slateGray mb-1">Date</label>
                        <input type="date" id="expense-date" class="w-full px-3 py-2 border rounded-md" />
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slateGray mb-1">Recorded By</label>
                        <input type="text" id="expense-recorded-by" value="Accountant" class="w-full px-3 py-2 border rounded-md" />
                    </div>
                </div>

                <div class="flex items-center justify-end gap-3 pt-3">
                    <button type="button" onclick="closeModal('expense-modal')" class="px-4 py-2 text-slate-600 hover:text-slate-800">Cancel</button>
                    <button type="submit" class="px-6 py-2.5 bg-tropicalGreen text-white font-bold rounded-lg shadow hover:bg-opacity-95 transition">
                        Save Expense
                    </button>
                </div>
            </form>
        </div>
    </div>


    <!-- MODAL 8: GUEST RESERVATION LOOKUP / FIND BOOKING -->
    <div id="find-booking-modal" class="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 hidden flex items-center justify-center p-4">
        <div class="bg-white rounded-2xl max-w-md w-full p-6 sm:p-8 shadow-2xl border border-slate-200">
            <div class="flex items-center justify-between border-b border-slate-200 pb-3 mb-5">
                <div>
                    <h3 class="text-xl font-bold text-midnightBlue">Find Your Reservation</h3>
                    <p class="text-xs text-slateGray mt-0.5">Lookup your booking voucher, balance & confirmation</p>
                </div>
                <button onclick="closeModal('find-booking-modal')" class="text-slate-400 hover:text-slate-600 text-2xl leading-none">&times;</button>
            </div>

            <form onsubmit="submitFindBooking(event)" class="space-y-4 text-sm">
                <div>
                    <label class="block text-xs font-semibold text-slateGray mb-1">Booking Reference Code or Phone Number *</label>
                    <input type="text" id="find-booking-input" required placeholder="e.g. HRY-B05829 or 0917..." class="w-full px-3 py-2.5 border rounded-xl font-semibold text-slate-800 focus:ring-2 focus:ring-antiqueGold focus:outline-none" />
                </div>
                <div class="p-3 bg-warmIvory rounded-xl border border-amber-200/70 text-xs text-slate-600 space-y-1">
                    <p>&bull; <strong>Booking Reference:</strong> Check your reservation code (format: <code class="font-bold text-slate-800">HRY-XXXXXX</code>).</p>
                    <p>&bull; <strong>Instant Folio:</strong> Retrieve your digital voucher, verified payment breakdown, and print your check-in slip.</p>
                </div>
                <div class="flex items-center justify-end gap-2 pt-2">
                    <button type="button" onclick="closeModal('find-booking-modal')" class="px-4 py-2 text-slate-600 hover:text-slate-800 text-xs font-medium">Cancel</button>
                    <button type="submit" class="px-5 py-2.5 bg-midnightBlue hover:bg-slate-800 text-white font-bold rounded-xl shadow text-xs transition flex items-center gap-1.5">
                        <svg class="w-4 h-4 text-antiqueGold" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                        Lookup Voucher
                    </button>
                </div>
            </form>
        </div>
    </div>


    <!-- Footer -->
    <footer class="bg-midnightBlue text-slate-300 mt-auto border-t border-slate-800">
        <div class="max-w-7xl mx-auto px-6 py-10 flex flex-col md:flex-row items-center justify-between text-xs sm:text-sm gap-4">
            <div class="flex items-center space-x-3">
                <span class="text-antiqueGold font-bold tracking-wider uppercase font-serif text-lg">HIRAYA</span>
                <span class="border-l border-slate-700 pl-3 text-slate-400">Minimalist Luxury Hotel Management System &bull; RBAC Protected</span>
            </div>
            <div class="text-slate-400 text-center md:text-right">
                &copy; 2026 Hiraya Hotel & Residences. All rights reserved.
            </div>
        </div>
    </footer>


    <!-- ============================================================== -->
    <!-- JAVASCRIPT APPLICATION CORE                                    -->
    <!-- ============================================================== -->
    <script>
        // Dynamic Base URL Resolution: Works seamlessly across localhost, localhost:8080, and /hiraya_hrs/
        const currentPath = window.location.pathname;
        const basePrefix = currentPath.includes('/hiraya_hrs') ? '/hiraya_hrs' : '';
        const BASE_URL = window.location.origin + basePrefix;
        const _origFetch = window.fetch;
        window.fetch = function(resource, init) {
            if (typeof resource === 'string' && resource.startsWith('/api/')) {
                resource = BASE_URL + resource;
            }
            return _origFetch(resource, init);
        };

        // Application State
        let currentUser = null; // { id, name, email, role, phone }
        let allRooms = [];
        let availableRoomsList = [];
        let selectedRoomForModal = null;
        let currentCheckoutBooking = null;
        let currentReceiptData = null;
        let currentActiveSection = 'home';
        let adminUsersList = [];
        let allFrontDeskBookings = [];

        // Initialize Dates with Minimum Validation
        const today = new Date();
        const tomorrow = new Date(today);
        tomorrow.setDate(tomorrow.getDate() + 1);

        const formatDate = (d) => d.toISOString().split('T')[0];
        const todayStr = formatDate(today);
        const tomorrowStr = formatDate(tomorrow);

        const searchInEl = document.getElementById('search-check-in');
        const searchOutEl = document.getElementById('search-check-out');
        if (searchInEl) {
            searchInEl.min = todayStr;
            searchInEl.value = todayStr;
        }
        if (searchOutEl) {
            searchOutEl.min = tomorrowStr;
            searchOutEl.value = tomorrowStr;
        }

        const modalInEl = document.getElementById('modal-check-in');
        const modalOutEl = document.getElementById('modal-check-out');
        if (modalInEl) {
            modalInEl.min = todayStr;
            modalInEl.value = todayStr;
        }
        if (modalOutEl) {
            modalOutEl.min = tomorrowStr;
            modalOutEl.value = tomorrowStr;
        }

        document.getElementById('walkin-check-in').value = todayStr;
        document.getElementById('walkin-check-out').value = tomorrowStr;
        document.getElementById('expense-date').value = todayStr;

        function onSearchCheckInChange() {
            const checkIn = document.getElementById('search-check-in').value;
            const checkOutInput = document.getElementById('search-check-out');
            if (!checkIn) return;

            const nextDay = new Date(checkIn);
            nextDay.setDate(nextDay.getDate() + 1);
            const nextDayStr = formatDate(nextDay);

            checkOutInput.min = nextDayStr;
            if (!checkOutInput.value || checkOutInput.value <= checkIn) {
                checkOutInput.value = nextDayStr;
            }
        }

        function onSearchCheckOutChange() {
            const checkIn = document.getElementById('search-check-in').value;
            const checkOut = document.getElementById('search-check-out').value;
            if (checkIn && checkOut && checkOut <= checkIn) {
                alert('Check-out date must be after check-in date.');
                onSearchCheckInChange();
            }
        }

        function onModalDatesChange() {
            const checkIn = document.getElementById('modal-check-in').value;
            const checkOutInput = document.getElementById('modal-check-out');
            if (checkIn) {
                const nextDay = new Date(checkIn);
                nextDay.setDate(nextDay.getDate() + 1);
                const nextDayStr = formatDate(nextDay);
                checkOutInput.min = nextDayStr;
                if (!checkOutInput.value || checkOutInput.value <= checkIn) {
                    checkOutInput.value = nextDayStr;
                }
            }
            calculateModalTotal();
        }

        function handleSearchClick() {
            loadAvailableRooms(true);
        }

        // UI Notification Toast
        function showToast(msg) {
            const toast = document.getElementById('toast');
            document.getElementById('toast-msg').innerText = msg;
            toast.classList.remove('translate-y-20', 'opacity-0');
            setTimeout(() => {
                toast.classList.add('translate-y-20', 'opacity-0');
            }, 3500);
        }

        function openModal(id) {
            document.getElementById(id).classList.remove('hidden');
        }

        function closeModal(id) {
            document.getElementById(id).classList.add('hidden');
        }

        // ==========================================
        // NAVIGATION & SECTION SWITCHING
        // ==========================================

        function goToHome() {
            showSection('home');
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }

        function scrollToSection(sectionId) {
            showSection('home');
            const el = document.getElementById(sectionId);
            if (el) {
                el.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        }

        // Redirects to Booking search bar and highlights check-in date
        function scrollToBooking() {
            showSection('home');
            const bookingEl = document.getElementById('booking-section');
            if (bookingEl) {
                bookingEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
                const checkInInput = document.getElementById('search-check-in');
                if (checkInInput) {
                    setTimeout(() => {
                        checkInInput.focus();
                        checkInInput.classList.add('ring-4', 'ring-antiqueGold');
                        setTimeout(() => {
                            checkInInput.classList.remove('ring-4', 'ring-antiqueGold');
                        }, 1800);
                    }, 400);
                }
            }
        }

        // Primary section controller: displays home or staff/admin console
        function showSection(sectionName) {
            const sections = {
                home: document.getElementById('section-home'),
                admin: document.getElementById('role-admin'),
                frontdesk: document.getElementById('role-frontdesk'),
                housekeeping: document.getElementById('role-housekeeping'),
                accounting: document.getElementById('role-accounting')
            };

            const userRole = currentUser ? currentUser.role : 'Guest';

            // Guard non-home sections
            if (sectionName !== 'home') {
                if (!currentUser) {
                    showToast(`Please sign in with staff credentials to access ${sectionName}.`);
                    openModal('login-modal');
                    return;
                }

                if (userRole !== 'Admin') {
                    if (sectionName === 'admin') {
                        alert('Access Denied: Only Admin can access the Room Management Portal.');
                        return;
                    }
                    if (sectionName === 'frontdesk' && userRole !== 'Front Desk') {
                        alert(`Access Denied: Your current role is "${userRole}". Front Desk or Admin required.`);
                        return;
                    }
                    if (sectionName === 'housekeeping' && userRole !== 'Housekeeping') {
                        alert(`Access Denied: Your current role is "${userRole}". Housekeeping or Admin required.`);
                        return;
                    }
                    if (sectionName === 'accounting' && userRole !== 'Accounting') {
                        alert(`Access Denied: Your current role is "${userRole}". Accounting or Admin required.`);
                        return;
                    }
                }
            }

            // Hide all sections, show target
            Object.keys(sections).forEach(k => {
                if (sections[k]) {
                    if (k === sectionName) {
                        sections[k].classList.remove('hidden');
                    } else {
                        sections[k].classList.add('hidden');
                    }
                }
            });

            currentActiveSection = sectionName;

            // Load section-specific data
            if (sectionName === 'home') {
                loadAvailableRooms();
            } else if (sectionName === 'admin') {
                loadAdminRooms();
                loadAdminUsers();
                document.getElementById('staff-active-label').innerText = 'Admin Room & Staff Management';
            } else if (sectionName === 'frontdesk') {
                loadFrontDeskData();
                document.getElementById('staff-active-label').innerText = 'Front Desk Console';
            } else if (sectionName === 'housekeeping') {
                loadHousekeepingData();
                document.getElementById('staff-active-label').innerText = 'Housekeeping Operations';
            } else if (sectionName === 'accounting') {
                loadAccountingData();
                document.getElementById('staff-active-label').innerText = 'Accounting Ledger';
            }

            // Scroll to top of section
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }


        // ==========================================
        // AUTHENTICATION & RBAC LOGIC
        // ==========================================

        async function checkAuthSession() {
            try {
                const res = await fetch('/api/auth/me');
                const json = await res.json();
                if (json.authenticated && json.user) {
                    setUserSession(json.user);
                } else {
                    clearUserSession();
                }
            } catch (err) {
                console.error(err);
                clearUserSession();
            }
        }

        function setUserSession(user) {
            currentUser = user;
            document.getElementById('auth-guest-view').classList.add('hidden');
            document.getElementById('auth-user-view').classList.remove('hidden');
            document.getElementById('user-display-name').innerText = user.name;
            document.getElementById('user-display-role').innerText = user.role;
            document.getElementById('rbac-status-note').innerHTML = `Logged in as: <strong class="text-white">${user.name}</strong> (${user.role})`;

            // Configure role badge styling
            const badge = document.getElementById('user-display-role');
            if (user.role === 'Front Desk') badge.className = 'text-[10px] uppercase tracking-wider font-extrabold px-2 py-0.5 rounded bg-tropicalGreen text-white';
            else if (user.role === 'Housekeeping') badge.className = 'text-[10px] uppercase tracking-wider font-extrabold px-2 py-0.5 rounded bg-amber-500 text-midnightBlue';
            else if (user.role === 'Accounting') badge.className = 'text-[10px] uppercase tracking-wider font-extrabold px-2 py-0.5 rounded bg-antiqueGold text-midnightBlue';
            else if (user.role === 'Admin') badge.className = 'text-[10px] uppercase tracking-wider font-extrabold px-2.5 py-0.5 rounded bg-purple-700 text-white shadow-sm';
            else badge.className = 'text-[10px] uppercase tracking-wider font-extrabold px-2 py-0.5 rounded bg-slate-600 text-white';

            // Show or configure the Staff Toolbar
            configureStaffControls(user.role);

            // Auto-navigate staff to their primary console
            if (user.role === 'Admin') {
                showSection('admin');
            } else if (user.role === 'Front Desk') {
                showSection('frontdesk');
            } else if (user.role === 'Housekeeping') {
                showSection('housekeeping');
            } else if (user.role === 'Accounting') {
                showSection('accounting');
            } else {
                showSection('home');
            }
        }

        function clearUserSession() {
            currentUser = null;
            document.getElementById('auth-guest-view').classList.remove('hidden');
            document.getElementById('auth-user-view').classList.add('hidden');
            document.getElementById('rbac-status-note').innerText = 'Browsing as Public Visitor';
            document.getElementById('staff-controls-bar').classList.add('hidden');
            showSection('home');
        }

        function configureStaffControls(role) {
            const bar = document.getElementById('staff-controls-bar');
            const btnAdmin = document.getElementById('btn-portal-admin');
            const btnFD = document.getElementById('btn-portal-frontdesk');
            const btnHK = document.getElementById('btn-portal-housekeeping');
            const btnAcc = document.getElementById('btn-portal-accounting');

            if (role === 'Guest' || !role) {
                bar.classList.add('hidden');
                return;
            }

            bar.classList.remove('hidden');

            if (role === 'Admin') {
                btnAdmin.classList.remove('hidden');
                btnFD.classList.remove('hidden');
                btnHK.classList.remove('hidden');
                btnAcc.classList.remove('hidden');
            } else if (role === 'Front Desk') {
                btnAdmin.classList.add('hidden');
                btnFD.classList.remove('hidden');
                btnHK.classList.add('hidden');
                btnAcc.classList.add('hidden');
            } else if (role === 'Housekeeping') {
                btnAdmin.classList.add('hidden');
                btnFD.classList.add('hidden');
                btnHK.classList.remove('hidden');
                btnAcc.classList.add('hidden');
            } else if (role === 'Accounting') {
                btnAdmin.classList.add('hidden');
                btnFD.classList.add('hidden');
                btnHK.classList.add('hidden');
                btnAcc.classList.remove('hidden');
            }
        }

        async function submitLogin(e) {
            e.preventDefault();
            const email = document.getElementById('login-email').value;
            const password = document.getElementById('login-password').value;

            try {
                const res = await fetch('/api/auth/login', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({email, password})
                });
                const json = await res.json();
                if (json.status === 'success') {
                    closeModal('login-modal');
                    showToast(json.message);
                    setUserSession(json.user);
                } else {
                    alert(json.message || 'Login failed');
                }
            } catch (err) {
                console.error(err);
                showToast('Login error');
            }
        }

        async function submitRegister(e) {
            e.preventDefault();
            const payload = {
                name: document.getElementById('reg-name').value,
                email: document.getElementById('reg-email').value,
                password: document.getElementById('reg-password').value,
                role: document.getElementById('reg-role').value,
                phone: document.getElementById('reg-phone').value
            };

            try {
                const res = await fetch('/api/auth/register', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify(payload)
                });
                const json = await res.json();
                if (json.status === 'success') {
                    closeModal('register-modal');
                    showToast(json.message);
                    setUserSession(json.user);
                } else {
                    alert(json.message || 'Registration failed');
                }
            } catch (err) {
                console.error(err);
                showToast('Registration error');
            }
        }

        // 1-Click Quick Demo Login (Uses hiraya123)
        async function quickLogin(email) {
            try {
                const res = await fetch('/api/auth/login', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({email, password: 'hiraya123'})
                });
                const json = await res.json();
                if (json.status === 'success') {
                    showToast(`Logged in as ${json.user.role}: ${json.user.name}`);
                    setUserSession(json.user);
                } else {
                    alert(json.message || 'Quick login failed');
                }
            } catch (err) {
                console.error(err);
                showToast('Login error');
            }
        }

        async function logoutUser() {
            try {
                await fetch('/api/auth/logout', {method: 'POST'});
                showToast('Logged out successfully');
                clearUserSession();
            } catch (err) {
                console.error(err);
                clearUserSession();
            }
        }

        function getAuthHeaders() {
            const headers = {'Content-Type': 'application/json'};
            if (currentUser && currentUser.role) {
                headers['X-User-Role'] = currentUser.role;
            }
            return headers;
        }


        // ==========================================
        // 1. PUBLIC ROOMS SEARCH & DISPLAY
        // ==========================================

        async function loadAvailableRooms() {
            const checkIn = document.getElementById('search-check-in').value;
            const checkOut = document.getElementById('search-check-out').value;
            const capacity = document.getElementById('search-capacity').value;

            try {
                const res = await fetch(`/api/rooms/available?check_in=${checkIn}&check_out=${checkOut}&capacity=${capacity}`);
                const json = await res.json();
                const container = document.getElementById('rooms-grid');
                container.innerHTML = '';

                if (!json.data || json.data.length === 0) {
                    container.innerHTML = `
                        <div class="col-span-full bg-white p-12 rounded-2xl text-center border border-slate-200">
                            <div class="text-4xl mb-3">🏖️</div>
                            <h3 class="text-lg font-bold text-midnightBlue">No Villas Available for Selected Dates</h3>
                            <p class="text-slateGray text-sm mt-1">Please try alternate dates or adjust guest capacity to view open accommodations.</p>
                            <button onclick="document.getElementById('search-capacity').value='1'; loadAvailableRooms();" class="mt-4 px-4 py-2 bg-midnightBlue text-white text-xs font-bold rounded-lg">
                                Reset Filters
                            </button>
                        </div>
                    `;
                    document.getElementById('room-count-badge').innerText = '0 Available';
                    return;
                }

                document.getElementById('room-count-badge').innerText = `${json.data.length} Available`;

                json.data.forEach(room => {
                    const card = document.createElement('div');
                    card.className = "bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 border border-slate-200/90 flex flex-col group";

                    const imageUrl = room.image_url || 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=800&q=80';

                    card.innerHTML = `
                        <!-- Room Image Banner -->
                        <div class="h-56 relative overflow-hidden bg-slate-900">
                            <img src="${imageUrl}" alt="${room.room_type}" class="w-full h-full object-cover group-hover:scale-105 transition duration-700 ease-out">
                            <div class="absolute inset-0 bg-gradient-to-t from-midnightBlue/90 via-midnightBlue/20 to-black/30"></div>
                            
                            <!-- Badges -->
                            <div class="absolute top-3 left-3 flex items-center gap-2">
                                <span class="bg-antiqueGold text-midnightBlue text-xs font-black px-2.5 py-1 rounded shadow-md tracking-wider">Room ${room.room_number}</span>
                                <span class="text-xs bg-slate-900/80 backdrop-blur-sm text-slate-200 font-medium px-2.5 py-1 rounded border border-white/10">Floor ${room.floor}</span>
                            </div>

                            <div class="absolute bottom-3 left-4 right-4 flex items-end justify-between text-white">
                                <div>
                                    <span class="text-xs font-extrabold text-antiqueGold uppercase tracking-wider block font-sans">${room.room_type}</span>
                                    <span class="text-xs text-slate-300 flex items-center gap-1 mt-0.5 font-light">
                                        <svg class="w-3.5 h-3.5 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path></svg>
                                        Capacity: ${room.capacity} Guests
                                    </span>
                                </div>
                                <div class="text-right">
                                    <span class="text-[10px] text-slate-300 uppercase block tracking-wider">Per Night</span>
                                    <span class="text-xl font-extrabold text-warmIvory">₱${parseFloat(room.price).toLocaleString()}</span>
                                </div>
                            </div>
                        </div>

                        <!-- Card Body -->
                        <div class="p-6 flex-1 flex flex-col justify-between space-y-4">
                            <div>
                                <p class="text-xs text-slateGray line-clamp-3 mb-4 leading-relaxed">${room.description || 'Spacious sanctuary featuring bespoke island architectural touches and serene luxury amenities.'}</p>
                                <div class="text-xs text-slate-600 bg-warmIvory/80 p-3 rounded-xl border border-slate-200/80">
                                    <strong class="text-midnightBlue font-bold block mb-1">Key Amenities:</strong>
                                    <span class="line-clamp-2">${room.amenities || 'High-speed Wi-Fi, Balcony, Smart TV, Air Conditioning'}</span>
                                </div>
                            </div>

                            <div class="flex items-center justify-between pt-4 border-t border-slate-100">
                                <div>
                                    <span class="text-2xl font-black text-midnightBlue">₱${parseFloat(room.price).toLocaleString()}</span>
                                    <span class="text-xs text-slate-400 block -mt-1">/ night + taxes</span>
                                </div>
                                <button onclick='openBookingModal(${JSON.stringify(room)})' class="px-5 py-2.5 bg-antiqueGold hover:bg-amber-400 text-midnightBlue font-extrabold text-xs uppercase tracking-wider rounded-xl shadow-md hover:shadow-lg transition flex items-center gap-1.5">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                                    Book Villa
                                </button>
                            </div>
                        </div>
                    `;
                    container.appendChild(card);
                });
            } catch (err) {
                console.error(err);
                showToast('Error loading rooms');
            }
        }

        function openBookingModal(room) {
            selectedRoomForModal = room;
            document.getElementById('modal-room-id').value = room.id;
            document.getElementById('modal-room-title').innerText = `${room.room_type} — Room ${room.room_number} (₱${parseFloat(room.price).toLocaleString()} / night)`;
            document.getElementById('modal-check-in').value = document.getElementById('search-check-in').value;
            document.getElementById('modal-check-out').value = document.getElementById('search-check-out').value;
            
            // Reset payment option to Deposit default
            const depRadio = document.querySelector('input[name="modal_payment_option"][value="Deposit"]');
            if (depRadio) depRadio.checked = true;
            onPaymentOptionChange();

            if (currentUser) {
                document.getElementById('modal-full-name').value = currentUser.name || '';
                document.getElementById('modal-email').value = currentUser.email || '';
                document.getElementById('modal-phone').value = currentUser.phone || '';
            }

            calculateModalTotal();
            openModal('booking-modal');
        }

        function onPaymentOptionChange() {
            const isFull = document.querySelector('input[name="modal_payment_option"]:checked')?.value === 'Full Payment';
            const depCard = document.getElementById('pay-opt-deposit-card');
            const fullCard = document.getElementById('pay-opt-full-card');
            const payLabel = document.getElementById('modal-pay-label');
            const submitLabel = document.getElementById('modal-submit-label');

            if (isFull) {
                if (depCard) {
                    depCard.classList.remove('border-antiqueGold', 'bg-amber-50/60');
                    depCard.classList.add('border-slate-200');
                }
                if (fullCard) {
                    fullCard.classList.add('border-antiqueGold', 'bg-emerald-50/60');
                    fullCard.classList.remove('border-slate-200');
                }
                if (payLabel) payLabel.innerText = 'Amount to Pay Now (Full Accommodation):';
                if (submitLabel) submitLabel.innerText = 'Confirm & Pay in Full';
            } else {
                if (depCard) {
                    depCard.classList.add('border-antiqueGold', 'bg-amber-50/60');
                    depCard.classList.remove('border-slate-200');
                }
                if (fullCard) {
                    fullCard.classList.remove('border-antiqueGold', 'bg-emerald-50/60');
                    fullCard.classList.add('border-slate-200');
                }
                if (payLabel) payLabel.innerText = 'Amount to Pay Now (30% Deposit):';
                if (submitLabel) submitLabel.innerText = 'Confirm & Pay Deposit';
            }
            calculateModalTotal();
        }

        function calculateModalTotal() {
            if (!selectedRoomForModal) return;
            const checkInVal = document.getElementById('modal-check-in').value;
            const checkOutVal = document.getElementById('modal-check-out').value;
            if (!checkInVal || !checkOutVal) return;

            const checkIn = new Date(checkInVal);
            const checkOut = new Date(checkOutVal);

            let diffDays = Math.ceil((checkOut - checkIn) / (1000 * 60 * 60 * 24));
            if (diffDays <= 0) diffDays = 1;

            const pricePerNight = parseFloat(selectedRoomForModal.price);
            const total = diffDays * pricePerNight;
            const isFull = document.querySelector('input[name="modal_payment_option"]:checked')?.value === 'Full Payment';
            
            const deposit = isFull ? total : Math.round(total * 0.30 * 100) / 100;
            const balance = Math.max(0, total - deposit);

            document.getElementById('modal-nights').innerText = diffDays;
            document.getElementById('modal-total-display').innerText = `₱${total.toLocaleString(undefined, {minimumFractionDigits: 2})}`;
            document.getElementById('modal-deposit-display').innerText = `₱${deposit.toLocaleString(undefined, {minimumFractionDigits: 2})}`;
            
            const balDisplay = document.getElementById('modal-balance-display');
            if (balDisplay) {
                balDisplay.innerText = isFull ? '₱0.00 (Express Check-In Ready)' : `₱${balance.toLocaleString(undefined, {minimumFractionDigits: 2})}`;
                balDisplay.className = isFull ? 'font-bold text-emerald-700' : 'font-bold text-amber-700';
            }
        }

        async function submitOnlineBooking(e) {
            e.preventDefault();
            const paymentOption = document.querySelector('input[name="modal_payment_option"]:checked')?.value || 'Deposit';
            const payload = {
                room_id: document.getElementById('modal-room-id').value,
                check_in: document.getElementById('modal-check-in').value,
                check_out: document.getElementById('modal-check-out').value,
                full_name: document.getElementById('modal-full-name').value.trim(),
                email: document.getElementById('modal-email').value.trim(),
                phone: document.getElementById('modal-phone').value.trim(),
                preferences: document.getElementById('modal-preferences').value.trim(),
                payment_method: document.getElementById('modal-payment-method').value,
                payment_type: paymentOption
            };

            try {
                showToast('Securing your villa reservation...');
                const res = await fetch('/api/bookings/online', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify(payload)
                });
                const json = await res.json();
                if (json.status === 'success') {
                    closeModal('booking-modal');
                    showToast(`Reservation confirmed! Code: ${json.booking.booking_code}`);
                    loadAvailableRooms();
                    // Open official receipt folio modal immediately
                    openReceiptModal(json.booking);
                } else {
                    alert(json.message || 'Booking failed');
                }
            } catch (err) {
                console.error(err);
                showToast('Booking failed');
            }
        }

        function openFindBookingModal() {
            document.getElementById('find-booking-input').value = '';
            openModal('find-booking-modal');
        }

        async function submitFindBooking(e) {
            e.preventDefault();
            const input = document.getElementById('find-booking-input').value.trim();
            if (!input) return;

            try {
                showToast('Locating your reservation folio...');
                const res = await fetch(`/api/bookings/${encodeURIComponent(input)}`);
                const json = await res.json();
                if (json.status === 'success' && json.data) {
                    closeModal('find-booking-modal');
                    openReceiptModal(json.data);
                } else {
                    alert(json.message || 'Reservation not found. Please double-check your booking reference or phone number.');
                }
            } catch (err) {
                console.error(err);
                showToast('Error locating reservation');
            }
        }

        function openReceiptModal(data) {
            currentReceiptData = data;
            const code = data.booking_code || 'HRY-000000';
            const total = parseFloat(data.total_amount || 0);
            const paid = parseFloat(data.paid_amount || data.deposit_amount || 0);
            const balance = Math.max(0, parseFloat(data.balance_due !== undefined ? data.balance_due : (total - paid)));
            const nights = data.nights || 1;
            const isFullyPaid = balance <= 0 || data.payment_type === 'Full Payment' || data.is_fully_paid;

            document.getElementById('rcpt-code').innerText = code;
            document.getElementById('rcpt-date').innerText = 'Issued: ' + (data.created_at ? data.created_at.substring(0, 10) : todayStr);

            // Status banner
            const banner = document.getElementById('rcpt-status-banner');
            if (isFullyPaid) {
                banner.className = 'rounded-2xl p-4 border flex items-start gap-3 bg-emerald-50 border-emerald-300 text-emerald-900';
                banner.innerHTML = `
                    <div class="w-8 h-8 rounded-full bg-emerald-200 text-emerald-800 flex items-center justify-center font-black text-sm flex-shrink-0">✓</div>
                    <div>
                        <strong class="font-extrabold text-xs block text-emerald-900 uppercase tracking-wider">Folio Fully Paid & Guaranteed</strong>
                        <p class="text-[11px] text-emerald-800 mt-0.5">100% accommodation charge received. Express check-in verified — ₱0.00 balance due upon keycard retrieval.</p>
                    </div>
                `;
            } else {
                banner.className = 'rounded-2xl p-4 border flex items-start gap-3 bg-amber-50 border-amber-300 text-amber-900';
                banner.innerHTML = `
                    <div class="w-8 h-8 rounded-full bg-amber-200 text-amber-900 flex items-center justify-center font-black text-sm flex-shrink-0">⏳</div>
                    <div>
                        <strong class="font-extrabold text-xs block text-amber-900 uppercase tracking-wider">30% Reservation Deposit Paid — Balance Due at Check-In</strong>
                        <p class="text-[11px] text-amber-800 mt-0.5">Your villa reservation is guaranteed. Remaining balance of <strong class="text-rose-700">₱${balance.toLocaleString(undefined, {minimumFractionDigits: 2})}</strong> will be settled at Front Desk check-in.</p>
                    </div>
                `;
            }

            // Guest info
            document.getElementById('rcpt-guest-name').innerText = data.guest_name || data.full_name || 'Valued Guest';
            const email = data.email || 'guest@hirayahotel.ph';
            const phone = data.phone || 'N/A';
            document.getElementById('rcpt-guest-contact').innerText = `${email} • ${phone}`;
            document.getElementById('rcpt-special').innerText = 'Preferences: ' + (data.special_requests || data.preferences || 'Standard luxury stay');

            // Room info
            const roomNum = data.room_number || (data.room ? data.room.room_number : '101');
            const roomType = data.room_type || (data.room ? data.room.room_type : 'Standard Villa');
            const floor = data.floor || 1;
            document.getElementById('rcpt-room-title').innerText = `Room ${roomNum} — ${roomType}`;
            document.getElementById('rcpt-dates').innerText = `Check-in: ${data.check_in} → Check-out: ${data.check_out}`;
            document.getElementById('rcpt-nights').innerText = `Duration: ${nights} Night/s (Floor ${floor})`;

            // Charges
            document.getElementById('rcpt-item-desc').innerText = `Accommodation (${roomType} × ${nights} Night/s)`;
            document.getElementById('rcpt-item-subtotal').innerText = `₱${total.toLocaleString(undefined, {minimumFractionDigits: 2})}`;
            document.getElementById('rcpt-total-amount').innerText = `₱${total.toLocaleString(undefined, {minimumFractionDigits: 2})}`;

            // Payments
            const payType = data.payment_type || (isFullyPaid ? 'Full Payment' : 'Deposit');
            const payMethod = data.payment_method || 'Online / GCash';
            const refNo = data.reference_no || 'REF-' + code;
            document.getElementById('rcpt-payment-type').innerText = `${payType} Received`;
            document.getElementById('rcpt-payment-meta').innerText = `Method: ${payMethod} • Ref: ${refNo}`;
            document.getElementById('rcpt-paid-amount').innerText = `+₱${paid.toLocaleString(undefined, {minimumFractionDigits: 2})}`;
            document.getElementById('rcpt-balance-amount').innerText = `₱${balance.toLocaleString(undefined, {minimumFractionDigits: 2})}`;
            document.getElementById('rcpt-balance-amount').className = isFullyPaid ? 'text-base text-emerald-600 font-black' : 'text-base text-amber-700 font-black';

            openModal('receipt-modal');
        }

        async function openReceiptModalFromBooking(idOrCode) {
            try {
                showToast('Loading booking folio...');
                const res = await fetch(`/api/bookings/${idOrCode}`, {headers: getAuthHeaders()});
                const json = await res.json();
                if (json.status === 'success' && json.data) {
                    openReceiptModal(json.data);
                } else {
                    alert(json.message || 'Folio not found');
                }
            } catch (err) {
                console.error(err);
                showToast('Failed to load receipt folio');
            }
        }

        function printReceipt() {
            window.print();
        }

        function downloadReceiptHtml() {
            if (!currentReceiptData) {
                showToast('No receipt data to export');
                return;
            }
            const printContent = document.getElementById('receipt-printable-content').innerHTML;
            const fullHtml = `<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Hiraya Official Receipt - ${currentReceiptData.booking_code || 'Voucher'}</title>
    <script src="https://cdn.tailwindcss.com"><\/script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background: #f8fafc; padding: 24px; color: #1e293b; }
        .receipt-card { max-width: 720px; margin: 0 auto; background: white; border-radius: 20px; box-shadow: 0 10px 25px -5px rgba(0,0,0,0.1); padding: 32px; border: 1px solid #e2e8f0; }
        @media print { body { background: white; padding: 0; } .receipt-card { box-shadow: none; border: none; padding: 0; } }
    </style>
</head>
<body>
    <div class="receipt-card">
        ${printContent}
    </div>
</body>
</html>`;

            const blob = new Blob([fullHtml], { type: 'text/html;charset=utf-8' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `Hiraya-Receipt-${currentReceiptData.booking_code || 'folio'}.html`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            showToast('Receipt downloaded successfully!');
        }


        // ==========================================
        // 2. ADMIN: EDIT ROOM PRICE, DETAILS, IMAGE
        // ==========================================

        async function loadAdminRooms() {
            try {
                const res = await fetch('/api/rooms', {headers: getAuthHeaders()});
                const json = await res.json();
                allRooms = json.data || [];

                let availableCount = 0;
                let occupiedCount = 0;
                let totalPrice = 0;

                const tbody = document.getElementById('admin-rooms-table-body');
                tbody.innerHTML = '';

                allRooms.forEach(room => {
                    const price = parseFloat(room.price);
                    totalPrice += price;
                    if (room.status === 'Available') availableCount++;
                    if (room.status === 'Booked' || room.status === 'Occupied') occupiedCount++;

                    const tr = document.createElement('tr');
                    tr.className = "hover:bg-slate-50 transition";

                    const statusBadge = {
                        'Available': 'bg-emerald-100 text-emerald-800 border-emerald-200',
                        'Booked': 'bg-amber-100 text-amber-800 border-amber-200',
                        'Occupied': 'bg-rose-100 text-rose-800 border-rose-200',
                        'Maintenance': 'bg-slate-200 text-slate-700 border-slate-300'
                    }[room.status] || 'bg-slate-100';

                    const cleanBadge = {
                        'Clean': 'text-emerald-700 bg-emerald-50',
                        'Dirty': 'text-rose-700 bg-rose-50',
                        'In Progress': 'text-amber-700 bg-amber-50',
                        'Inspected': 'text-blue-700 bg-blue-50'
                    }[room.cleaning_status] || 'text-slate-600 bg-slate-50';

                    const imageUrl = room.image_url || 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=800&q=80';

                    tr.innerHTML = `
                        <td class="px-6 py-4">
                            <div class="flex items-center gap-3">
                                <img src="${imageUrl}" alt="Room ${room.room_number}" class="w-14 h-12 rounded-lg object-cover shadow-sm border border-slate-200 flex-shrink-0">
                                <div>
                                    <div class="font-extrabold text-midnightBlue text-base">Room ${room.room_number}</div>
                                    <div class="text-xs text-slate-400">Floor ${room.floor}</div>
                                </div>
                            </div>
                        </td>
                        <td class="px-6 py-4 font-semibold text-slate-800">
                            ${room.room_type}
                        </td>
                        <td class="px-6 py-4 font-extrabold text-midnightBlue text-base">
                            ₱${price.toLocaleString(undefined, {minimumFractionDigits: 2})}
                        </td>
                        <td class="px-6 py-4 text-xs text-slate-600">
                            ${room.capacity} Guests &bull; Floor ${room.floor}
                        </td>
                        <td class="px-6 py-4">
                            <span class="px-2.5 py-1 rounded text-xs font-bold border ${statusBadge}">${room.status}</span>
                        </td>
                        <td class="px-6 py-4">
                            <span class="px-2 py-0.5 rounded text-xs font-semibold ${cleanBadge}">${room.cleaning_status}</span>
                        </td>
                        <td class="px-6 py-4 text-right">
                            <button onclick='openEditRoomModal(${JSON.stringify(room)})' class="px-3.5 py-1.5 bg-midnightBlue hover:bg-purple-900 text-white font-bold rounded-lg text-xs shadow-sm transition flex items-center gap-1.5 ml-auto">
                                <svg class="w-3.5 h-3.5 text-antiqueGold" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path></svg>
                                Edit Room
                            </button>
                        </td>
                    `;
                    tbody.appendChild(tr);
                });

                // Update Stats
                document.getElementById('admin-stat-total').innerText = allRooms.length;
                document.getElementById('admin-stat-available').innerText = availableCount;
                document.getElementById('admin-stat-occupied').innerText = occupiedCount;
                const avg = allRooms.length > 0 ? (totalPrice / allRooms.length) : 0;
                document.getElementById('admin-stat-avg-price').innerText = `₱${Math.round(avg).toLocaleString()}`;

            } catch (err) {
                console.error(err);
                showToast('Failed to load room inventory');
            }
        }

        function openEditRoomModal(room) {
            document.getElementById('edit-room-id').value = room.id;
            document.getElementById('modal-edit-room-badge').innerText = `Room ${room.room_number} — ${room.room_type}`;
            document.getElementById('edit-room-number').value = room.room_number;
            document.getElementById('edit-room-type').value = room.room_type;
            document.getElementById('edit-room-price').value = parseFloat(room.price);
            document.getElementById('edit-room-capacity').value = room.capacity;
            document.getElementById('edit-room-floor').value = room.floor;
            document.getElementById('edit-room-status').value = room.status;
            document.getElementById('edit-room-cleaning').value = room.cleaning_status;
            document.getElementById('edit-room-description').value = room.description || '';
            document.getElementById('edit-room-amenities').value = room.amenities || '';
            document.getElementById('edit-room-image-url').value = room.image_url || '';
            
            updateImagePreview(room.image_url || '');
            openModal('admin-edit-room-modal');
        }

        function updateImagePreview(url) {
            const preview = document.getElementById('edit-room-image-preview');
            const placeholder = document.getElementById('edit-room-no-image-placeholder');
            if (url && url.trim() !== '') {
                preview.src = url;
                preview.classList.remove('hidden');
                placeholder.classList.add('hidden');
            } else {
                preview.classList.add('hidden');
                placeholder.classList.remove('hidden');
            }
        }

        function selectPresetImage(url) {
            document.getElementById('edit-room-image-url').value = url;
            updateImagePreview(url);
        }

        async function uploadAdminRoomFile() {
            const fileInput = document.getElementById('edit-room-image-file');
            const roomId = document.getElementById('edit-room-id').value;

            if (!fileInput.files || fileInput.files.length === 0) {
                alert('Please select an image file first.');
                return;
            }

            const formData = new FormData();
            formData.append('image', fileInput.files[0]);

            try {
                showToast('Uploading room image...');
                const res = await fetch(`/api/rooms/${roomId}/upload-image`, {
                    method: 'POST',
                    headers: {'X-User-Role': currentUser ? currentUser.role : 'Admin'},
                    body: formData
                });
                const json = await res.json();
                if (json.status === 'success') {
                    document.getElementById('edit-room-image-url').value = json.image_url;
                    updateImagePreview(json.image_url);
                    showToast('Image uploaded successfully!');
                } else {
                    alert(json.message || 'Upload failed');
                }
            } catch (err) {
                console.error(err);
                showToast('Image upload failed');
            }
        }

        async function submitAdminRoomEdit(e) {
            e.preventDefault();
            const id = document.getElementById('edit-room-id').value;
            const payload = {
                room_number: document.getElementById('edit-room-number').value,
                room_type: document.getElementById('edit-room-type').value,
                price: parseFloat(document.getElementById('edit-room-price').value),
                capacity: parseInt(document.getElementById('edit-room-capacity').value),
                floor: parseInt(document.getElementById('edit-room-floor').value),
                status: document.getElementById('edit-room-status').value,
                cleaning_status: document.getElementById('edit-room-cleaning').value,
                description: document.getElementById('edit-room-description').value,
                amenities: document.getElementById('edit-room-amenities').value,
                image_url: document.getElementById('edit-room-image-url').value
            };

            try {
                const res = await fetch(`/api/rooms/${id}`, {
                    method: 'POST',
                    headers: getAuthHeaders(),
                    body: JSON.stringify(payload)
                });
                const json = await res.json();

                if (res.status === 403) {
                    alert(json.message || 'Access Denied: Admin required.');
                    return;
                }

                if (json.status === 'success') {
                    closeModal('admin-edit-room-modal');
                    showToast(`Room ${payload.room_number} updated: ₱${payload.price.toLocaleString()} & details saved!`);
                    
                    // Refresh both admin inventory and public room grid
                    loadAdminRooms();
                    loadAvailableRooms();
                    if (typeof loadFrontDeskData === 'function') {
                        loadFrontDeskData();
                    }
                } else {
                    alert(json.message || 'Failed to update room');
                }
            } catch (err) {
                console.error(err);
                showToast('Error updating room');
            }
        }


        // ==========================================
        // 2B. ADMIN: STAFF ACCOUNT MANAGEMENT
        // ==========================================

        async function loadAdminUsers() {
            try {
                const res = await fetch('/api/admin/users', {headers: getAuthHeaders()});
                const json = await res.json();
                adminUsersList = json.data || [];

                const tbody = document.getElementById('admin-users-table-body');
                if (!tbody) return;
                tbody.innerHTML = '';

                if (adminUsersList.length === 0) {
                    tbody.innerHTML = `<tr><td colspan="6" class="px-6 py-6 text-center text-slate-400">No staff accounts found.</td></tr>`;
                    return;
                }

                const roleStyles = {
                    'Admin': 'bg-purple-100 text-purple-800 border-purple-200',
                    'Front Desk': 'bg-emerald-100 text-emerald-800 border-emerald-200',
                    'Housekeeping': 'bg-amber-100 text-amber-800 border-amber-200',
                    'Accounting': 'bg-sky-100 text-sky-800 border-sky-200',
                    'Guest': 'bg-slate-100 text-slate-700 border-slate-200'
                };

                adminUsersList.forEach(u => {
                    const tr = document.createElement('tr');
                    tr.className = "hover:bg-slate-50 transition";
                    const isSelf = currentUser && currentUser.id == u.id;
                    const dateStr = u.created_at ? u.created_at.substring(0, 10) : 'N/A';

                    tr.innerHTML = `
                        <td class="px-6 py-3.5">
                            <div class="font-bold text-midnightBlue">${u.name} ${isSelf ? '<span class="text-[10px] text-purple-700 bg-purple-50 px-1.5 py-0.5 rounded font-bold ml-1">(You)</span>' : ''}</div>
                        </td>
                        <td class="px-6 py-3.5 text-slate-600 font-mono text-xs">${u.email}</td>
                        <td class="px-6 py-3.5">
                            <span class="px-2.5 py-0.5 rounded text-xs font-bold border ${roleStyles[u.role] || 'bg-slate-100 text-slate-700'}">${u.role}</span>
                        </td>
                        <td class="px-6 py-3.5 text-xs text-slate-600">${u.phone || 'N/A'}</td>
                        <td class="px-6 py-3.5 text-xs text-slate-500">${dateStr}</td>
                        <td class="px-6 py-3.5 text-right">
                            ${isSelf ? '<span class="text-xs text-slate-400 italic">Active Session</span>' : `
                                <button onclick="deleteStaffUser(${u.id}, '${u.name}')" class="px-2.5 py-1 text-rose-600 hover:text-white hover:bg-rose-600 border border-rose-300 rounded-lg text-xs font-semibold transition">
                                    Delete
                                </button>
                            `}
                        </td>
                    `;
                    tbody.appendChild(tr);
                });
            } catch (err) {
                console.error(err);
                showToast('Failed to load user accounts');
            }
        }

        function openStaffModal() {
            document.getElementById('staff-form').reset();
            openModal('staff-modal');
        }

        async function submitCreateStaff(e) {
            e.preventDefault();
            const payload = {
                name: document.getElementById('staff-name').value.trim(),
                email: document.getElementById('staff-email').value.trim(),
                password: document.getElementById('staff-password').value,
                role: document.getElementById('staff-role').value,
                phone: document.getElementById('staff-phone').value.trim()
            };

            try {
                showToast('Creating staff account...');
                const res = await fetch('/api/admin/users', {
                    method: 'POST',
                    headers: getAuthHeaders(),
                    body: JSON.stringify(payload)
                });
                const json = await res.json();

                if (json.status === 'success') {
                    closeModal('staff-modal');
                    showToast(json.message);
                    loadAdminUsers();
                } else {
                    alert(json.message || 'Failed to create staff account');
                }
            } catch (err) {
                console.error(err);
                showToast('Failed to create staff');
            }
        }

        async function deleteStaffUser(id, name) {
            if (!confirm(`Are you sure you want to remove staff account "${name}"?`)) return;
            try {
                showToast('Removing staff account...');
                const res = await fetch(`/api/admin/users/${id}/delete`, {
                    method: 'POST',
                    headers: getAuthHeaders()
                });
                const json = await res.json();
                if (json.status === 'success') {
                    showToast(json.message);
                    loadAdminUsers();
                } else {
                    alert(json.message || 'Failed to delete account');
                }
            } catch (err) {
                console.error(err);
                showToast('Delete error');
            }
        }


        // ==========================================
        // 3. FRONT DESK CONSOLE
        // ==========================================

        async function loadFrontDeskData() {
            try {
                // Rooms matrix
                const roomsRes = await fetch('/api/rooms', {headers: getAuthHeaders()});
                const roomsJson = await roomsRes.json();
                allRooms = roomsJson.data || [];

                const matrixContainer = document.getElementById('frontdesk-rooms-matrix');
                matrixContainer.innerHTML = '';

                const statusColors = {
                    'Available': 'bg-emerald-100 text-emerald-800 border-emerald-300',
                    'Booked': 'bg-amber-100 text-amber-800 border-amber-300',
                    'Occupied': 'bg-rose-100 text-rose-800 border-rose-300',
                    'Maintenance': 'bg-slate-200 text-slate-700 border-slate-300'
                };

                allRooms.forEach(room => {
                    const card = document.createElement('div');
                    card.className = `p-3 rounded-xl border text-center transition shadow-sm ${statusColors[room.status] || 'bg-white'}`;
                    card.innerHTML = `
                        <div class="text-base font-extrabold">${room.room_number}</div>
                        <div class="text-[10px] font-bold uppercase tracking-tight">${room.status}</div>
                        <div class="text-[9px] text-slate-500 mt-0.5">${room.cleaning_status}</div>
                    `;
                    matrixContainer.appendChild(card);
                });

                // Bookings roster
                const bookingsRes = await fetch('/api/bookings', {headers: getAuthHeaders()});
                const bookingsJson = await bookingsRes.json();
                allFrontDeskBookings = bookingsJson.data || [];
                const bookingsTable = document.getElementById('bookings-table-body');
                bookingsTable.innerHTML = '';

                allFrontDeskBookings.forEach(b => {
                    const tr = document.createElement('tr');
                    tr.className = "hover:bg-slate-50 transition";
                    const total = parseFloat(b.total_amount || 0);
                    const paid = parseFloat(b.paid_amount || 0);
                    const balance = Math.max(0, total - paid);

                    let actionBtns = '<div class="flex items-center justify-end gap-1.5 flex-wrap">';
                    if (b.status === 'Booked') {
                        if (balance > 0) {
                            actionBtns += `<button onclick="openSettleBalanceModal(${b.id})" class="px-2.5 py-1 bg-amber-600 hover:bg-amber-700 text-white rounded text-[11px] font-bold shadow-sm transition" title="Collect remaining balance">Settle Bal</button>`;
                        }
                        actionBtns += `<button onclick="checkInBooking(${b.id})" class="px-2.5 py-1 bg-tropicalGreen hover:bg-emerald-700 text-white rounded text-[11px] font-bold shadow-sm transition">Check-In</button>`;
                    } else if (b.status === 'Checked-In') {
                        actionBtns += `<button onclick='openCheckoutModal(${JSON.stringify(b)})' class="px-2.5 py-1 bg-rose-600 hover:bg-rose-700 text-white rounded text-[11px] font-bold shadow-sm transition">Check-Out</button>`;
                    }
                    actionBtns += `<button onclick="openReceiptModalFromBooking(${b.id})" class="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-midnightBlue border border-slate-300 rounded text-[11px] font-semibold transition" title="Print/View Folio">Folio</button>`;
                    actionBtns += '</div>';

                    const badgeColor = {
                        'Booked': 'bg-amber-100 text-amber-800',
                        'Checked-In': 'bg-rose-100 text-rose-800',
                        'Checked-Out': 'bg-slate-100 text-slate-600',
                        'Cancelled': 'bg-red-100 text-red-600'
                    }[b.status] || 'bg-slate-100';

                    tr.innerHTML = `
                        <td class="px-6 py-4 font-bold text-midnightBlue">${b.booking_code}</td>
                        <td class="px-6 py-4">
                            <div class="font-semibold text-slate-800">${b.full_name}</div>
                            <div class="text-xs text-slate-400">${b.phone}</div>
                        </td>
                        <td class="px-6 py-4 font-medium text-slate-700">${b.room_number} (${b.room_type})</td>
                        <td class="px-6 py-4 text-xs text-slate-600">${b.check_in} to ${b.check_out}</td>
                        <td class="px-6 py-4 text-xs text-slate-500">${b.booking_source}</td>
                        <td class="px-6 py-4">
                            <span class="px-2 py-0.5 text-xs font-semibold rounded ${badgeColor}">${b.status}</span>
                        </td>
                        <td class="px-6 py-4 text-xs">
                            <div>Total: <strong>₱${total.toLocaleString(undefined, {minimumFractionDigits: 2})}</strong></div>
                            <div class="text-tropicalGreen font-semibold">Paid: ₱${paid.toLocaleString(undefined, {minimumFractionDigits: 2})}</div>
                            ${balance > 0 ? `<div class="text-rose-600 font-bold">Due: ₱${balance.toLocaleString(undefined, {minimumFractionDigits: 2})}</div>` : '<div class="text-emerald-600 font-semibold text-[10px]">Fully Settled</div>'}
                        </td>
                        <td class="px-6 py-4 text-right">${actionBtns}</td>
                    `;
                    bookingsTable.appendChild(tr);
                });

                // Guests roster
                const guestsRes = await fetch('/api/guests', {headers: getAuthHeaders()});
                const guestsJson = await guestsRes.json();
                const guestsTable = document.getElementById('guests-table-body');
                guestsTable.innerHTML = '';

                (guestsJson.data || []).forEach(g => {
                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                        <td class="px-6 py-3 font-semibold text-slate-800">${g.full_name}</td>
                        <td class="px-6 py-3 text-slate-600">${g.email}</td>
                        <td class="px-6 py-3 text-slate-600">${g.phone}</td>
                        <td class="px-6 py-3 text-slate-500 text-xs">${g.id_type || 'Passport'}: ${g.id_number || 'N/A'}</td>
                        <td class="px-6 py-3 text-xs text-slate-500">${g.preferences || 'Standard stay'}</td>
                    `;
                    guestsTable.appendChild(tr);
                });
            } catch (err) {
                console.error(err);
                showToast('Failed to load Front Desk data');
            }
        }

        async function verifyGuestBooking() {
            const input = document.getElementById('frontdesk-search-input');
            const query = input.value.trim();
            const resultBox = document.getElementById('frontdesk-verification-result');

            if (!query) {
                alert('Please enter a booking code, guest name, or phone number to verify.');
                input.focus();
                return;
            }

            try {
                resultBox.classList.remove('hidden');
                resultBox.innerHTML = `
                    <div class="flex items-center justify-center py-6 text-slate-300 gap-2">
                        <svg class="animate-spin h-5 w-5 text-antiqueGold" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path></svg>
                        <span>Searching reservation ledger for "${query}"...</span>
                    </div>
                `;

                const res = await fetch(`/api/bookings/${encodeURIComponent(query)}`, {headers: getAuthHeaders()});
                const json = await res.json();

                if (json.status !== 'success' || !json.data) {
                    resultBox.innerHTML = `
                        <div class="p-4 rounded-lg bg-rose-950/60 border border-rose-800 text-rose-200 flex items-start gap-3">
                            <span class="text-xl">⚠️</span>
                            <div>
                                <strong class="font-bold text-sm block">Reservation Not Found</strong>
                                <p class="text-xs text-rose-300 mt-0.5">${json.message || 'No reservation matched "' + query + '". Please verify the booking code with the guest.'}</p>
                            </div>
                        </div>
                    `;
                    return;
                }

                const b = json.data;
                const total = parseFloat(b.total_amount || 0);
                const paid = parseFloat(b.paid_amount || 0);
                const balance = Math.max(0, parseFloat(b.balance_due !== undefined ? b.balance_due : (total - paid)));
                const isFullyPaid = balance <= 0;

                const statusColor = {
                    'Booked': 'bg-amber-400 text-slate-900',
                    'Checked-In': 'bg-rose-500 text-white',
                    'Checked-Out': 'bg-slate-600 text-slate-200',
                    'Cancelled': 'bg-red-600 text-white'
                }[b.status] || 'bg-slate-500 text-white';

                let actionButtons = '';
                if (b.status === 'Booked') {
                    if (!isFullyPaid) {
                        actionButtons += `
                            <button onclick="openSettleBalanceModal(${b.id})" class="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg text-xs transition flex items-center gap-1.5 shadow">
                                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
                                Settle Balance (₱${balance.toLocaleString(undefined, {minimumFractionDigits: 2})})
                            </button>
                        `;
                    }
                    actionButtons += `
                        <button onclick="checkInBooking(${b.id})" class="px-4 py-2 bg-tropicalGreen hover:bg-emerald-700 text-white font-bold rounded-lg text-xs transition flex items-center gap-1.5 shadow">
                            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
                            Complete Check-In
                        </button>
                    `;
                } else if (b.status === 'Checked-In') {
                    actionButtons += `
                        <button onclick='openCheckoutModal(${JSON.stringify(b)})' class="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-lg text-xs transition flex items-center gap-1.5 shadow">
                            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path></svg>
                            Process Check-Out
                        </button>
                    `;
                }

                actionButtons += `
                    <button onclick='openReceiptModal(${JSON.stringify(b)})' class="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-slate-200 font-bold rounded-lg text-xs transition flex items-center gap-1.5 border border-slate-600">
                        <svg class="w-3.5 h-3.5 text-antiqueGold" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
                        View Official Receipt Folio
                    </button>
                `;

                resultBox.innerHTML = `
                    <div class="space-y-4">
                        <div class="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-700 gap-2">
                            <div class="flex items-center gap-3">
                                <span class="text-base font-black text-antiqueGold font-mono tracking-wider">${b.booking_code}</span>
                                <span class="px-2 py-0.5 rounded text-[11px] font-extrabold uppercase ${statusColor}">${b.status}</span>
                                <span class="text-slate-400 text-xs">Source: ${b.booking_source || 'Website'}</span>
                            </div>
                            <div class="text-xs text-slate-300">
                                Check-in: <strong class="text-white">${b.check_in}</strong> &rarr; Check-out: <strong class="text-white">${b.check_out}</strong>
                            </div>
                        </div>

                        <div class="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                            <div class="bg-slate-900/80 p-3 rounded-lg border border-slate-700">
                                <span class="text-[10px] text-slate-400 uppercase tracking-wider block font-bold">Guest Particulars</span>
                                <div class="font-extrabold text-sm text-white mt-0.5">${b.full_name}</div>
                                <div class="text-slate-400 text-[11px]">${b.phone} &bull; ${b.email || 'No email'}</div>
                                <div class="text-slate-400 text-[11px] mt-1 italic">${b.special_requests || 'Standard stay'}</div>
                            </div>

                            <div class="bg-slate-900/80 p-3 rounded-lg border border-slate-700">
                                <span class="text-[10px] text-slate-400 uppercase tracking-wider block font-bold">Room Assigned</span>
                                <div class="font-extrabold text-sm text-antiqueGold mt-0.5">Room ${b.room_number}</div>
                                <div class="text-slate-300 text-[11px] font-medium">${b.room_type} &bull; Floor ${b.floor || 1}</div>
                                <div class="text-slate-400 text-[11px] mt-1">${b.nights || 1} Night/s @ ₱${parseFloat(b.room_price || 0).toLocaleString()}</div>
                            </div>

                            <div class="bg-slate-900/80 p-3 rounded-lg border ${isFullyPaid ? 'border-emerald-700/60' : 'border-amber-700/60'}">
                                <span class="text-[10px] text-slate-400 uppercase tracking-wider block font-bold">Billing Verification</span>
                                <div class="flex justify-between text-[11px] text-slate-300 mt-0.5">
                                    <span>Total Amount:</span>
                                    <strong class="text-white">₱${total.toLocaleString(undefined, {minimumFractionDigits: 2})}</strong>
                                </div>
                                <div class="flex justify-between text-[11px] text-emerald-400">
                                    <span>Paid So Far:</span>
                                    <strong>+₱${paid.toLocaleString(undefined, {minimumFractionDigits: 2})}</strong>
                                </div>
                                <div class="flex justify-between text-xs font-bold pt-1 border-t border-slate-700 mt-1">
                                    <span class="${isFullyPaid ? 'text-emerald-300' : 'text-amber-300'}">Balance Due:</span>
                                    <span class="${isFullyPaid ? 'text-emerald-300' : 'text-rose-400 font-extrabold'}">₱${balance.toLocaleString(undefined, {minimumFractionDigits: 2})}</span>
                                </div>
                            </div>
                        </div>

                        <div class="flex flex-wrap items-center justify-end gap-2 pt-2 border-t border-slate-700/80">
                            ${actionButtons}
                        </div>
                    </div>
                `;
            } catch (err) {
                console.error(err);
                resultBox.innerHTML = `
                    <div class="p-3 bg-red-900/50 border border-red-700 text-red-200 rounded-lg text-xs">
                        An error occurred while verifying reservation. Please check network connection.
                    </div>
                `;
            }
        }

        async function openSettleBalanceModal(bookingOrId) {
            let booking = null;
            if (typeof bookingOrId === 'object' && bookingOrId !== null) {
                booking = bookingOrId;
            } else {
                const found = (allFrontDeskBookings || []).find(b => b.id == bookingOrId);
                if (found) {
                    booking = found;
                } else {
                    const res = await fetch(`/api/bookings/${bookingOrId}`, {headers: getAuthHeaders()});
                    const json = await res.json();
                    if (json.status === 'success') booking = json.data;
                }
            }

            if (!booking) {
                alert('Could not find booking data.');
                return;
            }

            const total = parseFloat(booking.total_amount || 0);
            const paid = parseFloat(booking.paid_amount || 0);
            const balance = Math.max(0, total - paid);

            document.getElementById('settle-booking-id').value = booking.id;
            document.getElementById('settle-booking-code').innerText = `Booking: ${booking.booking_code}`;
            document.getElementById('settle-guest-name').innerText = booking.full_name || booking.guest_name;
            document.getElementById('settle-room-info').innerText = `Room ${booking.room_number} (${booking.room_type})`;
            document.getElementById('settle-total-bill').innerText = `₱${total.toLocaleString(undefined, {minimumFractionDigits: 2})}`;
            document.getElementById('settle-paid-so-far').innerText = `₱${paid.toLocaleString(undefined, {minimumFractionDigits: 2})}`;
            document.getElementById('settle-balance-due').innerText = `₱${balance.toLocaleString(undefined, {minimumFractionDigits: 2})}`;
            document.getElementById('settle-amount').value = balance.toFixed(2);
            document.getElementById('settle-amount').max = balance.toFixed(2);

            openModal('balance-settle-modal');
        }

        async function submitSettleBalance(e) {
            e.preventDefault();
            const bookingId = document.getElementById('settle-booking-id').value;
            const amount = parseFloat(document.getElementById('settle-amount').value) || 0;
            const paymentMethod = document.getElementById('settle-payment-method').value;

            if (amount <= 0) {
                alert('Please enter a valid payment amount.');
                return;
            }

            try {
                showToast('Recording balance payment...');
                const res = await fetch(`/api/bookings/${bookingId}/settle-balance`, {
                    method: 'POST',
                    headers: getAuthHeaders(),
                    body: JSON.stringify({ amount: amount, payment_method: paymentMethod })
                });
                const json = await res.json();

                if (json.status === 'success') {
                    closeModal('balance-settle-modal');
                    showToast(json.message);
                    loadFrontDeskData();

                    // If verification search was active, re-verify
                    const searchInput = document.getElementById('frontdesk-search-input');
                    if (searchInput && searchInput.value.trim()) {
                        verifyGuestBooking();
                    }

                    // Open updated receipt folio
                    openReceiptModalFromBooking(bookingId);
                } else {
                    alert(json.message || 'Settlement failed');
                }
            } catch (err) {
                console.error(err);
                showToast('Error processing settlement');
            }
        }

        async function checkInBooking(id) {
            const found = (allFrontDeskBookings || []).find(b => b.id == id);
            if (found) {
                const total = parseFloat(found.total_amount || 0);
                const paid = parseFloat(found.paid_amount || 0);
                const balance = total - paid;
                if (balance > 0) {
                    if (!confirm(`Note: Guest has an unsettled balance of ₱${balance.toLocaleString()}. Confirm check-in and issue room keycard?`)) {
                        return;
                    }
                } else {
                    if (!confirm('Confirm check-in for this guest? Room status will update to "Occupied".')) return;
                }
            } else {
                if (!confirm('Confirm check-in for this guest? Room status will update to "Occupied".')) return;
            }

            try {
                showToast('Checking in guest...');
                const res = await fetch(`/api/bookings/${id}/check-in`, {
                    method: 'POST',
                    headers: getAuthHeaders()
                });
                const json = await res.json();
                if (json.status === 'success') {
                    showToast(json.message);
                    loadFrontDeskData();
                    const searchInput = document.getElementById('frontdesk-search-input');
                    if (searchInput && searchInput.value.trim()) {
                        verifyGuestBooking();
                    }
                } else {
                    alert(json.message);
                }
            } catch (err) {
                console.error(err);
                showToast('Check-in error');
            }
        }

        function openWalkInModal() {
            const select = document.getElementById('walkin-room-id');
            select.innerHTML = '';

            const available = allRooms.filter(r => r.status === 'Available');
            if (available.length === 0) {
                alert('No rooms are currently available for walk-in clients.');
                return;
            }

            available.forEach(r => {
                const opt = document.createElement('option');
                opt.value = r.id;
                opt.text = `Room ${r.room_number} (${r.room_type}) — ₱${parseFloat(r.price).toLocaleString()} / night`;
                select.appendChild(opt);
            });

            openModal('walkin-modal');
        }

        async function submitWalkInBooking(e) {
            e.preventDefault();
            const payload = {
                room_id: document.getElementById('walkin-room-id').value,
                check_in: document.getElementById('walkin-check-in').value,
                check_out: document.getElementById('walkin-check-out').value,
                full_name: document.getElementById('walkin-name').value.trim(),
                phone: document.getElementById('walkin-phone').value.trim(),
                id_number: document.getElementById('walkin-id').value.trim(),
                preferences: document.getElementById('walkin-preferences').value.trim(),
                payment_method: document.getElementById('walkin-payment-method').value,
                payment_amount: document.getElementById('walkin-payment-amount').value || null
            };

            try {
                showToast('Registering walk-in client...');
                const res = await fetch('/api/bookings/walk-in', {
                    method: 'POST',
                    headers: getAuthHeaders(),
                    body: JSON.stringify(payload)
                });
                const json = await res.json();
                if (json.status === 'success') {
                    closeModal('walkin-modal');
                    showToast(json.message);
                    loadFrontDeskData();
                    if (json.data && json.data.booking_id) {
                        openReceiptModal(json.data);
                    }
                } else {
                    alert(json.message);
                }
            } catch (err) {
                console.error(err);
                showToast('Walk-in booking error');
            }
        }

        function openCheckoutModal(booking) {
            currentCheckoutBooking = booking;
            document.getElementById('checkout-booking-id').value = booking.id;
            document.getElementById('checkout-guest-name').innerText = booking.full_name;
            document.getElementById('checkout-room-number').innerText = `Room ${booking.room_number} (${booking.room_type})`;
            document.getElementById('checkout-room-total').innerText = `₱${parseFloat(booking.total_amount).toLocaleString()}`;
            document.getElementById('checkout-already-paid').innerText = `₱${parseFloat(booking.paid_amount).toLocaleString()}`;
            document.getElementById('checkout-extra').value = '0.00';
            updateCheckoutBalance();
            openModal('checkout-modal');
        }

        function updateCheckoutBalance() {
            if (!currentCheckoutBooking) return;
            const total = parseFloat(currentCheckoutBooking.total_amount);
            const paid = parseFloat(currentCheckoutBooking.paid_amount);
            const extra = parseFloat(document.getElementById('checkout-extra').value) || 0;
            const balance = Math.max(0, (total + extra) - paid);
            document.getElementById('checkout-balance').innerText = `₱${balance.toLocaleString(undefined, {minimumFractionDigits: 2})}`;
        }

        async function submitCheckout(e) {
            e.preventDefault();
            const id = document.getElementById('checkout-booking-id').value;
            const payload = {
                extra_charges: parseFloat(document.getElementById('checkout-extra').value) || 0,
                payment_method: document.getElementById('checkout-payment-method').value
            };

            try {
                showToast('Finalizing checkout & folio...');
                const res = await fetch(`/api/bookings/${id}/check-out`, {
                    method: 'POST',
                    headers: getAuthHeaders(),
                    body: JSON.stringify(payload)
                });
                const json = await res.json();
                if (json.status === 'success') {
                    closeModal('checkout-modal');
                    showToast(json.message);
                    loadFrontDeskData();
                    // Open finalized receipt / folio
                    openReceiptModalFromBooking(id);
                } else {
                    alert(json.message);
                }
            } catch (err) {
                console.error(err);
                showToast('Checkout failed');
            }
        }


        // ==========================================
        // 4. HOUSEKEEPING OPERATIONS
        // ==========================================

        async function loadHousekeepingData() {
            try {
                const res = await fetch('/api/housekeeping', {headers: getAuthHeaders()});
                const json = await res.json();
                const container = document.getElementById('housekeeping-grid');
                container.innerHTML = '';

                let dirtyCount = 0;
                let progressCount = 0;
                let cleanCount = 0;
                let maintCount = 0;

                (json.data || []).forEach(r => {
                    if (r.cleaning_status === 'Dirty') dirtyCount++;
                    if (r.cleaning_status === 'In Progress') progressCount++;
                    if (r.cleaning_status === 'Clean') cleanCount++;
                    if (r.status === 'Maintenance') maintCount++;

                    const card = document.createElement('div');
                    card.className = "bg-slate-50 border border-slate-200 rounded-xl p-4 flex flex-col justify-between";

                    const badgeColor = {
                        'Dirty': 'bg-rose-100 text-rose-800 border-rose-200',
                        'In Progress': 'bg-amber-100 text-amber-800 border-amber-200',
                        'Clean': 'bg-emerald-100 text-emerald-800 border-emerald-200',
                        'Inspected': 'bg-blue-100 text-blue-800 border-blue-200'
                    }[r.cleaning_status] || 'bg-slate-100';

                    card.innerHTML = `
                        <div>
                            <div class="flex items-center justify-between mb-2">
                                <span class="text-lg font-bold text-midnightBlue">Room ${r.room_number}</span>
                                <span class="text-xs px-2 py-0.5 rounded font-semibold border ${badgeColor}">${r.cleaning_status}</span>
                            </div>
                            <div class="text-xs text-slate-500 mb-1">${r.room_type} &bull; Floor ${r.floor}</div>
                            <div class="text-xs font-semibold text-slate-700">Occupancy: ${r.status}</div>
                        </div>
                        <div class="mt-4 pt-3 border-t border-slate-200 grid grid-cols-3 gap-1.5">
                            <button onclick="updateCleaningStatus(${r.id}, 'In Progress')" class="py-1.5 bg-amber-500 hover:bg-amber-600 text-white rounded text-[11px] font-bold transition">
                                In Progress
                            </button>
                            <button onclick="updateCleaningStatus(${r.id}, 'Clean')" class="py-1.5 bg-tropicalGreen hover:bg-emerald-700 text-white rounded text-[11px] font-bold transition">
                                Clean
                            </button>
                            <button onclick="updateCleaningStatus(${r.id}, 'Inspected')" class="py-1.5 bg-sky-600 hover:bg-sky-700 text-white rounded text-[11px] font-bold transition">
                                Inspected
                            </button>
                        </div>
                    `;
                    container.appendChild(card);
                });

                document.getElementById('stat-dirty').innerText = dirtyCount;
                document.getElementById('stat-progress').innerText = progressCount;
                document.getElementById('stat-clean').innerText = cleanCount;
                document.getElementById('stat-maint').innerText = maintCount;
            } catch (err) {
                console.error(err);
                showToast('Failed to load housekeeping');
            }
        }

        async function updateCleaningStatus(roomId, status) {
            try {
                const res = await fetch('/api/housekeeping/update', {
                    method: 'POST',
                    headers: getAuthHeaders(),
                    body: JSON.stringify({room_id: roomId, cleaning_status: status})
                });
                const json = await res.json();
                if (res.status === 403) {
                    alert(json.message);
                    return;
                }
                showToast(json.message);
                loadHousekeepingData();
            } catch (err) {
                console.error(err);
                showToast('Failed to update status');
            }
        }


        // ==========================================
        // 5. ACCOUNTING & EXPENSES
        // ==========================================

        async function loadAccountingData() {
            try {
                const res = await fetch('/api/accounting', {headers: getAuthHeaders()});
                const json = await res.json();

                if (res.status === 403) {
                    alert(json.message);
                    return;
                }

                const m = json.metrics || {};
                document.getElementById('acc-income').innerText = `₱${parseFloat(m.total_income || 0).toLocaleString(undefined, {minimumFractionDigits: 2})}`;
                document.getElementById('acc-expense').innerText = `₱${parseFloat(m.total_expense || 0).toLocaleString(undefined, {minimumFractionDigits: 2})}`;
                document.getElementById('acc-net').innerText = `₱${parseFloat(m.net_income || 0).toLocaleString(undefined, {minimumFractionDigits: 2})}`;

                // Payments
                const pTable = document.getElementById('payments-table-body');
                pTable.innerHTML = '';
                (json.payments || []).forEach(p => {
                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                        <td class="px-4 py-2.5 text-xs text-slate-500">${p.created_at ? p.created_at.substring(0, 10) : ''}</td>
                        <td class="px-4 py-2.5 font-medium text-slate-800">${p.full_name || 'Guest'} (${p.booking_code || 'N/A'})</td>
                        <td class="px-4 py-2.5 text-xs text-slate-600">${p.payment_method} &bull; ${p.payment_type}</td>
                        <td class="px-4 py-2.5 text-right font-bold text-tropicalGreen">+₱${parseFloat(p.amount).toLocaleString()}</td>
                    `;
                    pTable.appendChild(tr);
                });

                // Expenses
                const eTable = document.getElementById('expenses-table-body');
                eTable.innerHTML = '';
                (json.expenses || []).forEach(e => {
                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                        <td class="px-4 py-2.5 text-xs text-slate-500">${e.expense_date} &bull; <span class="font-semibold text-slate-700">${e.category}</span></td>
                        <td class="px-4 py-2.5 text-xs text-slate-800">${e.description}</td>
                        <td class="px-4 py-2.5 text-xs text-slate-500">${e.recorded_by}</td>
                        <td class="px-4 py-2.5 text-right font-bold text-rose-600">-₱${parseFloat(e.amount).toLocaleString()}</td>
                    `;
                    eTable.appendChild(tr);
                });
            } catch (err) {
                console.error(err);
                showToast('Failed to load accounting');
            }
        }

        function openExpenseModal() {
            openModal('expense-modal');
        }

        async function submitExpense(e) {
            e.preventDefault();
            const payload = {
                category: document.getElementById('expense-category').value,
                description: document.getElementById('expense-desc').value,
                amount: parseFloat(document.getElementById('expense-amount').value),
                expense_date: document.getElementById('expense-date').value,
                recorded_by: document.getElementById('expense-recorded-by').value
            };

            try {
                const res = await fetch('/api/expenses', {
                    method: 'POST',
                    headers: getAuthHeaders(),
                    body: JSON.stringify(payload)
                });
                const json = await res.json();
                if (res.status === 403) {
                    alert(json.message);
                    return;
                }
                if (json.status === 'success') {
                    closeModal('expense-modal');
                    showToast(json.message);
                    loadAccountingData();
                } else {
                    alert(json.message);
                }
            } catch (err) {
                console.error(err);
                showToast('Failed to save expense');
            }
        }

        // On Page Load: Check authentication and load initial available rooms
        checkAuthSession();
        loadAvailableRooms();
    </script>
</body>
</html>
