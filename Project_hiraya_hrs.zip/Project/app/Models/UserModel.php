<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table = 'users';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'name',
        'email',
        'password',
        'role',
        'phone'
    ];
    protected $useTimestamps = true;

    // Check credentials
    public function authenticate(string $email, string $password)
    {
        $user = $this->where('email', strtolower(trim($email)))->first();
        if ($user && password_verify($password, $user['password'])) {
            unset($user['password']);
            return $user;
        }
        return false;
    }
}
