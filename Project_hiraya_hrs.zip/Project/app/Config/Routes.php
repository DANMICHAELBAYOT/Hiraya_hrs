<?php

use CodeIgniter\Router\RouteCollection;

/** @var RouteCollection $routes */
$routes->get('/', 'Home::index');

// API Routes
$routes->group('api', static function ($routes) {
    // Auth & RBAC
    $routes->get('auth/me', 'AuthController::me');
    $routes->post('auth/login', 'AuthController::login');
    $routes->post('auth/register', 'AuthController::register');
    $routes->post('auth/logout', 'AuthController::logout');

    // Rooms
    $routes->get('rooms', 'ApiController::getRooms');
    $routes->get('rooms/available', 'ApiController::searchAvailableRooms');
    $routes->post('rooms/update', 'ApiController::updateRoom');
    $routes->post('rooms/(:num)', 'ApiController::updateRoom/$1');
    $routes->post('rooms/(:num)/upload-image', 'ApiController::uploadRoomImage/$1');

    // Admin Staff & User Management
    $routes->get('admin/users', 'ApiController::getUsers');
    $routes->post('admin/users', 'ApiController::createStaffUser');
    $routes->post('admin/users/(:num)/delete', 'ApiController::deleteUser/$1');

    // Bookings & Workflows
    $routes->get('bookings', 'ApiController::getBookings');
    $routes->get('bookings/(:segment)', 'ApiController::getBookingDetail/$1');
    $routes->post('bookings/online', 'ApiController::onlineBooking');
    $routes->post('bookings/walk-in', 'ApiController::walkInBooking');
    $routes->post('bookings/(:num)/check-in', 'ApiController::checkIn/$1');
    $routes->post('bookings/(:num)/check-out', 'ApiController::checkOut/$1');
    $routes->post('bookings/(:num)/settle-balance', 'ApiController::settleBalance/$1');

    // Guests
    $routes->get('guests', 'ApiController::getGuests');

    // Housekeeping
    $routes->get('housekeeping', 'ApiController::getHousekeeping');
    $routes->post('housekeeping/update', 'ApiController::updateHousekeeping');

    // Accounting
    $routes->get('accounting', 'ApiController::getAccounting');
    $routes->post('expenses', 'ApiController::addExpense');
});
