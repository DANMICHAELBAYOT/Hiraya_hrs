<?php

namespace App\Controllers;

use App\Models\RoomModel;
use App\Models\GuestModel;
use App\Models\BookingModel;
use App\Models\PaymentModel;
use App\Models\ExpenseModel;
use App\Models\UserModel;
use CodeIgniter\API\ResponseTrait;

class ApiController extends BaseController
{
    use ResponseTrait;

    protected $roomModel;
    protected $guestModel;
    protected $bookingModel;
    protected $paymentModel;
    protected $expenseModel;
    protected $userModel;

    public function __construct()
    {
        $this->roomModel = new RoomModel();
        $this->guestModel = new GuestModel();
        $this->bookingModel = new BookingModel();
        $this->paymentModel = new PaymentModel();
        $this->expenseModel = new ExpenseModel();
        $this->userModel = new UserModel();
    }

    protected function checkRole(array $allowedRoles): bool
    {
        $session = session();
        $user = $session->get('user');
        $roleHeader = $this->request->getHeaderLine('X-User-Role');
        $currentRole = $user['role'] ?? ($roleHeader ?: null);

        if (!$currentRole) {
            return false;
        }

        if ($currentRole === 'Admin' || in_array($currentRole, $allowedRoles)) {
            return true;
        }

        return false;
    }

    protected function getRequestData(): array
    {
        $json = null;
        try {
            $json = $this->request->getJSON(true);
        } catch (\Throwable $e) {
            $raw = (string)$this->request->getBody();
            if ($raw) {
                $decoded = json_decode($raw, true);
                if (is_array($decoded)) {
                    $json = $decoded;
                }
            }
        }
        return is_array($json) ? $json : ($this->request->getPost() ?: []);
    }

    // 1. Rooms
    public function getRooms()
    {
        $rooms = $this->roomModel->orderBy('room_number', 'ASC')->findAll();
        return $this->response->setJSON(['status' => 'success', 'data' => $rooms]);
    }

    public function searchAvailableRooms()
    {
        $checkIn = $this->request->getGet('check_in') ?: date('Y-m-d');
        $checkOut = $this->request->getGet('check_out');
        $capacity = (int)($this->request->getGet('capacity') ?: 1);

        // Ensure valid check_in and check_out
        if (!$checkOut || strtotime($checkOut) <= strtotime($checkIn)) {
            $checkOut = date('Y-m-d', strtotime($checkIn . ' +1 day'));
        }

        $db = \Config\Database::connect();
        // Rooms that already have active overlapping bookings
        $bookedRooms = $db->table('bookings')
            ->select('room_id')
            ->whereIn('status', ['Booked', 'Checked-In'])
            ->groupStart()
                ->where('check_in <', $checkOut)
                ->where('check_out >', $checkIn)
            ->groupEnd()
            ->get()
            ->getResultArray();

        $excludedIds = array_unique(array_filter(array_column($bookedRooms, 'room_id')));

        $query = $this->roomModel
            ->where('status !=', 'Maintenance')
            ->where('capacity >=', $capacity);

        if (!empty($excludedIds)) {
            $query->whereNotIn('id', $excludedIds);
        }

        $rooms = $query->orderBy('room_number', 'ASC')->findAll();

        return $this->response->setJSON([
            'status' => 'success',
            'check_in' => $checkIn,
            'check_out' => $checkOut,
            'capacity' => $capacity,
            'data' => $rooms
        ]);
    }

    public function updateRoom($id = null)
    {
        if (!$this->checkRole(['Admin'])) {
            return $this->response->setStatusCode(403)->setJSON([
                'status' => 'error',
                'message' => 'Access Denied: Only Admin can edit room details and pricing.'
            ]);
        }

        $json = $this->getRequestData();

        $roomId = $id ?: ($json['id'] ?? null);
        if (!$roomId) {
            return $this->response->setStatusCode(400)->setJSON([
                'status' => 'error',
                'message' => 'Room ID is required.'
            ]);
        }

        $room = $this->roomModel->find($roomId);
        if (!$room) {
            return $this->response->setStatusCode(404)->setJSON([
                'status' => 'error',
                'message' => 'Room not found.'
            ]);
        }

        $allowedKeys = [
            'room_number', 'room_type', 'status', 'cleaning_status',
            'price', 'capacity', 'floor', 'amenities', 'description', 'image_url'
        ];

        $updateData = [];
        foreach ($allowedKeys as $key) {
            if (array_key_exists($key, $json)) {
                if ($key === 'price') {
                    $updateData['price'] = (float)$json['price'];
                } elseif ($key === 'capacity' || $key === 'floor') {
                    $updateData[$key] = (int)$json[$key];
                } else {
                    $updateData[$key] = trim((string)$json[$key]);
                }
            }
        }

        if (empty($updateData)) {
            return $this->response->setStatusCode(400)->setJSON([
                'status' => 'error',
                'message' => 'No valid fields provided for update.'
            ]);
        }

        $this->roomModel->update($roomId, $updateData);
        $updatedRoom = $this->roomModel->find($roomId);

        return $this->response->setJSON([
            'status' => 'success',
            'message' => "Room {$updatedRoom['room_number']} updated successfully.",
            'data' => $updatedRoom
        ]);
    }

    public function uploadRoomImage($id = null)
    {
        if (!$this->checkRole(['Admin'])) {
            return $this->response->setStatusCode(403)->setJSON([
                'status' => 'error',
                'message' => 'Access Denied: Only Admin can upload room images.'
            ]);
        }

        $file = $this->request->getFile('image');
        if (!$file || !$file->isValid()) {
            return $this->response->setStatusCode(400)->setJSON([
                'status' => 'error',
                'message' => 'No valid image file uploaded.'
            ]);
        }

        $uploadPath = FCPATH . 'uploads/rooms/';
        if (!is_dir($uploadPath)) {
            mkdir($uploadPath, 0777, true);
        }

        $newName = $file->getRandomName();
        $file->move($uploadPath, $newName);

        $relativeUrl = base_url('uploads/rooms/' . $newName);

        if ($id) {
            $this->roomModel->update($id, ['image_url' => $relativeUrl]);
        }

        return $this->response->setJSON([
            'status' => 'success',
            'message' => 'Image uploaded successfully.',
            'image_url' => $relativeUrl
        ]);
    }

    // 2. Bookings
    public function getBookings()
    {
        $bookings = $this->bookingModel->getDetailedBookings();
        return $this->response->setJSON(['status' => 'success', 'data' => $bookings]);
    }

    // Online Booking Workflow (Deposit or Full Payment)
    public function onlineBooking()
    {
        $json = $this->getRequestData();

        $roomId = $json['room_id'] ?? null;
        $checkIn = $json['check_in'] ?? null;
        $checkOut = $json['check_out'] ?? null;
        $fullName = trim($json['full_name'] ?? '');
        $email = trim($json['email'] ?? '');
        $phone = trim($json['phone'] ?? '');
        $preferences = $json['preferences'] ?? '';
        $specialRequests = $json['special_requests'] ?? '';
        $paymentMethod = $json['payment_method'] ?? 'Online / GCash';
        $paymentType = $json['payment_type'] ?? 'Deposit'; // 'Deposit' or 'Full Payment'

        if (!$roomId || !$checkIn || !$checkOut || !$fullName || !$phone) {
            return $this->response->setStatusCode(400)->setJSON([
                'status' => 'error',
                'message' => 'Please provide room, dates, guest name, and phone.'
            ]);
        }

        $room = $this->roomModel->find($roomId);
        if (!$room) {
            return $this->response->setStatusCode(404)->setJSON(['status' => 'error', 'message' => 'Room not found.']);
        }

        // Calculate nights and price
        $nights = max(1, (int)((strtotime($checkOut) - strtotime($checkIn)) / 86400));
        $totalAmount = $nights * (float)$room['price'];

        // Full Payment or 30% Deposit option
        if ($paymentType === 'Full Payment') {
            $depositAmount = $totalAmount;
            $paidAmount = $totalAmount;
            $paymentTypeRecorded = 'Full Payment';
            $paymentNotes = '100% online full accommodation payment';
        } else {
            $depositAmount = round($totalAmount * 0.30, 2);
            $paidAmount = $depositAmount;
            $paymentTypeRecorded = 'Deposit';
            $paymentNotes = '30% online booking reservation deposit';
        }

        $balanceDue = max(0, $totalAmount - $paidAmount);

        // Find or create Guest
        $guest = $this->guestModel->where('phone', $phone)->orWhere('email', $email)->first();
        if ($guest) {
            $guestId = $guest['id'];
            if ($preferences) {
                $this->guestModel->update($guestId, ['preferences' => $preferences]);
            }
        } else {
            $guestId = $this->guestModel->insert([
                'full_name' => $fullName,
                'email' => $email ?: 'guest@hirayahotel.ph',
                'phone' => $phone,
                'preferences' => $preferences
            ]);
        }

        $bookingCode = 'HRY-' . strtoupper(substr(uniqid(), -6));
        $referenceNo = ($paymentTypeRecorded === 'Full Payment' ? 'FULL-' : 'DEP-') . strtoupper(substr(md5(microtime()), 0, 8));

        // Create Booking
        $bookingId = $this->bookingModel->insert([
            'booking_code' => $bookingCode,
            'room_id' => $roomId,
            'guest_id' => $guestId,
            'check_in' => $checkIn,
            'check_out' => $checkOut,
            'booking_source' => 'Website',
            'status' => 'Booked',
            'total_amount' => $totalAmount,
            'deposit_amount' => $depositAmount,
            'paid_amount' => $paidAmount,
            'special_requests' => $specialRequests
        ]);

        // Change Room status to "Booked"
        $this->roomModel->update($roomId, ['status' => 'Booked']);

        // Record Payment
        $this->paymentModel->insert([
            'booking_id' => $bookingId,
            'amount' => $paidAmount,
            'payment_type' => $paymentTypeRecorded,
            'payment_method' => $paymentMethod,
            'reference_no' => $referenceNo,
            'status' => 'Completed',
            'notes' => $paymentNotes
        ]);

        $bookingData = [
            'booking_id' => $bookingId,
            'booking_code' => $bookingCode,
            'room_id' => $roomId,
            'room_number' => $room['room_number'],
            'room_type' => $room['room_type'],
            'floor' => $room['floor'],
            'price_per_night' => (float)$room['price'],
            'check_in' => $checkIn,
            'check_out' => $checkOut,
            'nights' => $nights,
            'guest_name' => $fullName,
            'email' => $email,
            'phone' => $phone,
            'payment_type' => $paymentTypeRecorded,
            'payment_method' => $paymentMethod,
            'reference_no' => $referenceNo,
            'total_amount' => $totalAmount,
            'deposit_amount' => $depositAmount,
            'paid_amount' => $paidAmount,
            'balance_due' => $balanceDue,
            'status' => 'Booked',
            'special_requests' => $specialRequests,
            'created_at' => date('Y-m-d H:i:s')
        ];

        return $this->response->setJSON([
            'status' => 'success',
            'message' => 'Online booking confirmed successfully!',
            'booking' => $bookingData,
            'data' => $bookingData,
            'room' => [
                'room_number' => $room['room_number'],
                'room_type' => $room['room_type']
            ]
        ]);
    }

    // Walk-In Client Workflow
    public function walkInBooking()
    {
        if (!$this->checkRole(['Front Desk'])) {
            return $this->response->setStatusCode(403)->setJSON([
                'status' => 'error',
                'message' => 'Access Denied: Only Front Desk staff or Admin can perform walk-in registrations.'
            ]);
        }

        $json = $this->getRequestData();

        $roomId = $json['room_id'] ?? null;
        $checkIn = $json['check_in'] ?? date('Y-m-d');
        $checkOut = $json['check_out'] ?? date('Y-m-d', strtotime('+1 day'));
        $fullName = trim($json['full_name'] ?? '');
        $phone = trim($json['phone'] ?? '');
        $email = trim($json['email'] ?? '');
        $idNumber = trim($json['id_number'] ?? '');
        $preferences = $json['preferences'] ?? '';
        $paymentMethod = $json['payment_method'] ?? 'Cash';
        $paymentAmount = (float)($json['payment_amount'] ?? 0);

        if (!$roomId || !$fullName || !$phone) {
            return $this->response->setStatusCode(400)->setJSON([
                'status' => 'error',
                'message' => 'Room, Guest Name, and Phone are required for walk-in.'
            ]);
        }

        $room = $this->roomModel->find($roomId);
        if (!$room || $room['status'] === 'Occupied' || $room['status'] === 'Maintenance') {
            return $this->response->setStatusCode(400)->setJSON([
                'status' => 'error',
                'message' => 'Selected room is currently not available for walk-in.'
            ]);
        }

        $nights = max(1, (int)((strtotime($checkOut) - strtotime($checkIn)) / 86400));
        $totalAmount = $nights * (float)$room['price'];
        if ($paymentAmount <= 0) {
            $paymentAmount = $totalAmount; // default full settlement for walk-in
        }

        // Create or get guest
        $guest = $this->guestModel->where('phone', $phone)->first();
        if ($guest) {
            $guestId = $guest['id'];
        } else {
            $guestId = $this->guestModel->insert([
                'full_name' => $fullName,
                'email' => $email ?: 'walkin@hirayahotel.ph',
                'phone' => $phone,
                'id_number' => $idNumber,
                'preferences' => $preferences
            ]);
        }

        $bookingCode = 'WLK-' . strtoupper(substr(uniqid(), -6));

        // Create booking with status Checked-In
        $bookingId = $this->bookingModel->insert([
            'booking_code' => $bookingCode,
            'room_id' => $roomId,
            'guest_id' => $guestId,
            'check_in' => $checkIn,
            'check_out' => $checkOut,
            'actual_check_in' => date('Y-m-d H:i:s'),
            'booking_source' => 'Walk-In',
            'status' => 'Checked-In',
            'total_amount' => $totalAmount,
            'deposit_amount' => $paymentAmount,
            'paid_amount' => $paymentAmount,
            'special_requests' => 'Walk-In client registered at front desk.'
        ]);

        // Change Room status directly to "Occupied"
        $this->roomModel->update($roomId, ['status' => 'Occupied']);

        $refNo = 'WLK-' . strtoupper(substr(md5(microtime()), 0, 8));
        $paymentTypeRecorded = ($paymentAmount >= $totalAmount) ? 'Full Payment' : 'Deposit';

        // Record payment
        $this->paymentModel->insert([
            'booking_id' => $bookingId,
            'amount' => $paymentAmount,
            'payment_type' => $paymentTypeRecorded,
            'payment_method' => $paymentMethod,
            'reference_no' => $refNo,
            'status' => 'Completed',
            'notes' => 'Walk-in payment processed at front desk.'
        ]);

        $bookingData = [
            'booking_id' => $bookingId,
            'id' => $bookingId,
            'booking_code' => $bookingCode,
            'room_id' => $roomId,
            'room_number' => $room['room_number'],
            'room_type' => $room['room_type'],
            'floor' => $room['floor'],
            'price_per_night' => (float)$room['price'],
            'check_in' => $checkIn,
            'check_out' => $checkOut,
            'nights' => $nights,
            'guest_name' => $fullName,
            'full_name' => $fullName,
            'email' => $email ?: 'walkin@hirayahotel.ph',
            'phone' => $phone,
            'payment_type' => $paymentTypeRecorded,
            'payment_method' => $paymentMethod,
            'reference_no' => $refNo,
            'total_amount' => $totalAmount,
            'deposit_amount' => $paymentAmount,
            'paid_amount' => $paymentAmount,
            'balance_due' => max(0, $totalAmount - $paymentAmount),
            'status' => 'Checked-In',
            'special_requests' => 'Walk-In client registered at front desk.',
            'created_at' => date('Y-m-d H:i:s')
        ];

        return $this->response->setJSON([
            'status' => 'success',
            'message' => 'Walk-in guest checked in immediately. Room is now Occupied.',
            'data' => $bookingData,
            'booking' => $bookingData
        ]);
    }

    // 3. Front Desk Check-in
    public function checkIn($id)
    {
        if (!$this->checkRole(['Front Desk'])) {
            return $this->response->setStatusCode(403)->setJSON([
                'status' => 'error',
                'message' => 'Access Denied: Only Front Desk staff or Admin can check in guests.'
            ]);
        }

        $booking = $this->bookingModel->find($id);
        if (!$booking) {
            return $this->response->setStatusCode(404)->setJSON(['status' => 'error', 'message' => 'Booking not found.']);
        }

        if ($booking['status'] === 'Checked-In') {
            return $this->response->setJSON(['status' => 'info', 'message' => 'Guest is already checked in.']);
        }

        // Update booking status
        $this->bookingModel->update($id, [
            'status' => 'Checked-In',
            'actual_check_in' => date('Y-m-d H:i:s')
        ]);

        // Update Room status to "Occupied"
        $this->roomModel->update($booking['room_id'], ['status' => 'Occupied']);

        return $this->response->setJSON([
            'status' => 'success',
            'message' => 'Guest successfully checked in. Room status changed to Occupied.'
        ]);
    }

    // 4. Front Desk Check-out
    public function checkOut($id)
    {
        if (!$this->checkRole(['Front Desk'])) {
            return $this->response->setStatusCode(403)->setJSON([
                'status' => 'error',
                'message' => 'Access Denied: Only Front Desk staff or Admin can process checkout.'
            ]);
        }

        $booking = $this->bookingModel->find($id);
        if (!$booking) {
            return $this->response->setStatusCode(404)->setJSON(['status' => 'error', 'message' => 'Booking not found.']);
        }

        $json = $this->getRequestData();
        $extraCharges = (float)($json['extra_charges'] ?? 0);
        $paymentMethod = $json['payment_method'] ?? 'Cash';

        $totalDue = (float)$booking['total_amount'] + $extraCharges;
        $balance = $totalDue - (float)$booking['paid_amount'];

        // If remaining balance, record payment
        if ($balance > 0) {
            $this->paymentModel->insert([
                'booking_id' => $id,
                'amount' => $balance,
                'payment_type' => ($extraCharges > 0) ? 'Incidental' : 'Full Payment',
                'payment_method' => $paymentMethod,
                'reference_no' => 'OUT-' . strtoupper(substr(md5(microtime()), 0, 8)),
                'status' => 'Completed',
                'notes' => 'Checkout final settlement' . ($extraCharges > 0 ? " (includes ₱$extraCharges extras)" : '')
            ]);
        }

        // Update booking
        $this->bookingModel->update($id, [
            'status' => 'Checked-Out',
            'total_amount' => $totalDue,
            'paid_amount' => $totalDue,
            'actual_check_out' => date('Y-m-d H:i:s')
        ]);

        // Workflow requirement: At checkout, payment is completed and housekeeping is notified (Room -> Available, Cleaning -> Dirty)
        $this->roomModel->update($booking['room_id'], [
            'status' => 'Available',
            'cleaning_status' => 'Dirty'
        ]);

        return $this->response->setJSON([
            'status' => 'success',
            'message' => 'Checkout completed. Final payment recorded and Housekeeping notified of dirty room.',
            'settled_amount' => $balance,
            'booking_id' => (int)$id
        ]);
    }

    // 5. Housekeeping
    public function getHousekeeping()
    {
        $rooms = $this->roomModel->select('id, room_number, room_type, status, cleaning_status, floor, updated_at')
            ->orderBy('floor', 'ASC')
            ->orderBy('room_number', 'ASC')
            ->findAll();

        return $this->response->setJSON(['status' => 'success', 'data' => $rooms]);
    }

    public function updateHousekeeping()
    {
        if (!$this->checkRole(['Housekeeping'])) {
            return $this->response->setStatusCode(403)->setJSON([
                'status' => 'error',
                'message' => 'Access Denied: Only Housekeeping staff or Admin can update room cleaning status.'
            ]);
        }

        $json = $this->getRequestData();
        $roomId = $json['room_id'] ?? null;
        $cleaningStatus = $json['cleaning_status'] ?? 'Clean';

        if (!$roomId || !in_array($cleaningStatus, ['Clean', 'Dirty', 'In Progress', 'Inspected'])) {
            return $this->response->setStatusCode(400)->setJSON([
                'status' => 'error',
                'message' => 'Valid room_id and cleaning_status are required.'
            ]);
        }

        $this->roomModel->update($roomId, [
            'cleaning_status' => $cleaningStatus
        ]);

        return $this->response->setJSON([
            'status' => 'success',
            'message' => "Room cleaning status updated to {$cleaningStatus}."
        ]);
    }

    // 6. Guest Records
    public function getGuests()
    {
        $guests = $this->guestModel->orderBy('id', 'DESC')->findAll();
        return $this->response->setJSON(['status' => 'success', 'data' => $guests]);
    }

    // 7. Accounting
    public function getAccounting()
    {
        if (!$this->checkRole(['Accounting'])) {
            return $this->response->setStatusCode(403)->setJSON([
                'status' => 'error',
                'message' => 'Access Denied: Only Accounting staff or Admin can access financial records.'
            ]);
        }

        $db = \Config\Database::connect();

        // Income from completed payments
        $totalIncomeRow = $db->table('payments')
            ->selectSum('amount', 'total_income')
            ->where('status', 'Completed')
            ->get()->getRow();
        $totalIncome = (float)($totalIncomeRow->total_income ?? 0);

        // Expenses
        $totalExpenseRow = $db->table('expenses')
            ->selectSum('amount', 'total_expense')
            ->get()->getRow();
        $totalExpense = (float)($totalExpenseRow->total_expense ?? 0);

        $netIncome = $totalIncome - $totalExpense;

        // Recent Payments
        $payments = $db->table('payments')
            ->select('payments.*, bookings.booking_code, guests.full_name')
            ->join('bookings', 'bookings.id = payments.booking_id', 'left')
            ->join('guests', 'guests.id = bookings.guest_id', 'left')
            ->orderBy('payments.id', 'DESC')
            ->limit(20)
            ->get()->getResult();

        // Recent Expenses
        $expenses = $this->expenseModel->orderBy('expense_date', 'DESC')->limit(20)->findAll();

        return $this->response->setJSON([
            'status' => 'success',
            'metrics' => [
                'total_income' => $totalIncome,
                'total_expense' => $totalExpense,
                'net_income' => $netIncome
            ],
            'payments' => $payments,
            'expenses' => $expenses
        ]);
    }

    public function addExpense()
    {
        if (!$this->checkRole(['Accounting'])) {
            return $this->response->setStatusCode(403)->setJSON([
                'status' => 'error',
                'message' => 'Access Denied: Only Accounting staff or Admin can record expenses.'
            ]);
        }

        $json = $this->getRequestData();
        $category = $json['category'] ?? 'Other';
        $description = trim($json['description'] ?? '');
        $amount = (float)($json['amount'] ?? 0);
        $expenseDate = $json['expense_date'] ?? date('Y-m-d');
        $recordedBy = $json['recorded_by'] ?? 'Staff';

        if (!$description || $amount <= 0) {
            return $this->response->setStatusCode(400)->setJSON([
                'status' => 'error',
                'message' => 'Description and valid amount are required.'
            ]);
        }

        $this->expenseModel->insert([
            'category' => $category,
            'description' => $description,
            'amount' => $amount,
            'expense_date' => $expenseDate,
            'recorded_by' => $recordedBy
        ]);

        return $this->response->setJSON([
            'status' => 'success',
            'message' => 'Expense recorded successfully.'
        ]);
    }

    // 8. Booking Detail & Receipt Lookup
    public function getBookingDetail($idOrCode)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('bookings')
            ->select('bookings.*, rooms.room_number, rooms.room_type, rooms.floor, rooms.price as room_price, guests.full_name, guests.email, guests.phone, guests.id_type, guests.id_number, guests.preferences')
            ->join('rooms', 'rooms.id = bookings.room_id', 'left')
            ->join('guests', 'guests.id = bookings.guest_id', 'left');

        $term = trim(urldecode((string)$idOrCode));
        $builder->groupStart()
            ->where('bookings.booking_code', $term)
            ->orLike('guests.phone', $term)
            ->orLike('guests.full_name', $term);

        if (is_numeric($term) && (int)$term < 1000000) {
            $builder->orWhere('bookings.id', (int)$term);
        }
        $builder->groupEnd();

        $booking = $builder->orderBy('bookings.id', 'DESC')->get()->getRowArray();
        if (!$booking) {
            return $this->response->setStatusCode(404)->setJSON([
                'status' => 'error',
                'message' => 'No booking matched your search query.'
            ]);
        }

        // Fetch payments
        $payments = $this->paymentModel->where('booking_id', $booking['id'])->orderBy('id', 'ASC')->findAll();
        $booking['payments'] = $payments;
        $booking['balance_due'] = max(0, (float)$booking['total_amount'] - (float)$booking['paid_amount']);
        $booking['is_fully_paid'] = $booking['balance_due'] <= 0;
        $booking['guest_name'] = $booking['full_name'];

        $nights = max(1, (int)((strtotime($booking['check_out']) - strtotime($booking['check_in'])) / 86400));
        $booking['nights'] = $nights;

        if (!empty($payments)) {
            $lastPayment = end($payments);
            $booking['payment_type'] = $lastPayment['payment_type'] ?? 'Deposit';
            $booking['payment_method'] = $lastPayment['payment_method'] ?? 'Online / GCash';
            $booking['reference_no'] = $lastPayment['reference_no'] ?? 'N/A';
        } else {
            $booking['payment_type'] = 'Deposit';
            $booking['payment_method'] = 'Online';
            $booking['reference_no'] = 'N/A';
        }

        return $this->response->setJSON([
            'status' => 'success',
            'data' => $booking,
            'booking' => $booking
        ]);
    }

    // 9. Front Desk Settle Balance
    public function settleBalance($id)
    {
        if (!$this->checkRole(['Front Desk'])) {
            return $this->response->setStatusCode(403)->setJSON([
                'status' => 'error',
                'message' => 'Access Denied: Only Front Desk staff or Admin can settle booking balances.'
            ]);
        }

        $booking = $this->bookingModel->find($id);
        if (!$booking) {
            return $this->response->setStatusCode(404)->setJSON(['status' => 'error', 'message' => 'Booking not found.']);
        }

        $total = (float)$booking['total_amount'];
        $paid = (float)$booking['paid_amount'];
        $balance = $total - $paid;

        if ($balance <= 0) {
            return $this->response->setJSON([
                'status' => 'info',
                'message' => 'This booking is already fully paid.'
            ]);
        }

        $json = $this->getRequestData();
        $paymentMethod = $json['payment_method'] ?? 'Cash';
        $amount = (float)($json['amount'] ?? $balance);
        if ($amount <= 0 || $amount > $balance) {
            $amount = $balance;
        }

        $newPaidAmount = $paid + $amount;
        $newBalance = max(0, $total - $newPaidAmount);

        $refNo = 'BAL-' . strtoupper(substr(md5(microtime()), 0, 8));
        $this->paymentModel->insert([
            'booking_id' => $id,
            'amount' => $amount,
            'payment_type' => ($newBalance <= 0) ? 'Full Payment' : 'Deposit',
            'payment_method' => $paymentMethod,
            'reference_no' => $refNo,
            'status' => 'Completed',
            'notes' => 'Front desk balance settlement upon guest arrival'
        ]);

        $this->bookingModel->update($id, [
            'paid_amount' => $newPaidAmount
        ]);

        return $this->response->setJSON([
            'status' => 'success',
            'message' => "Payment of ₱" . number_format($amount, 2) . " recorded. Balance settled: ₱" . number_format($newBalance, 2),
            'data' => [
                'booking_id' => $id,
                'paid_amount' => $newPaidAmount,
                'balance_due' => $newBalance,
                'is_fully_paid' => $newBalance <= 0
            ]
        ]);
    }

    // 10. Admin Staff & User Management
    public function getUsers()
    {
        if (!$this->checkRole(['Admin'])) {
            return $this->response->setStatusCode(403)->setJSON([
                'status' => 'error',
                'message' => 'Access Denied: Only Admin can view user accounts.'
            ]);
        }

        $users = $this->userModel->select('id, name, email, role, phone, created_at')
            ->orderBy('id', 'DESC')
            ->findAll();

        return $this->response->setJSON(['status' => 'success', 'data' => $users]);
    }

    public function createStaffUser()
    {
        if (!$this->checkRole(['Admin'])) {
            return $this->response->setStatusCode(403)->setJSON([
                'status' => 'error',
                'message' => 'Access Denied: Only Admin can create staff accounts.'
            ]);
        }

        $json = $this->getRequestData();
        $name = trim($json['name'] ?? '');
        $email = strtolower(trim($json['email'] ?? ''));
        $password = $json['password'] ?? '';
        $role = trim($json['role'] ?? 'Front Desk');
        $phone = trim($json['phone'] ?? '');

        if (!$name || !$email || !$password) {
            return $this->response->setStatusCode(400)->setJSON([
                'status' => 'error',
                'message' => 'Full Name, Email, and Password are required.'
            ]);
        }

        if (strlen($password) < 6) {
            return $this->response->setStatusCode(400)->setJSON([
                'status' => 'error',
                'message' => 'Password must be at least 6 characters long.'
            ]);
        }

        $allowedRoles = ['Front Desk', 'Housekeeping', 'Accounting', 'Admin', 'Guest'];
        if (!in_array($role, $allowedRoles)) {
            return $this->response->setStatusCode(400)->setJSON([
                'status' => 'error',
                'message' => 'Invalid role specified.'
            ]);
        }

        // Check duplicate email
        $existing = $this->userModel->where('email', $email)->first();
        if ($existing) {
            return $this->response->setStatusCode(409)->setJSON([
                'status' => 'error',
                'message' => 'An account with this email address already exists.'
            ]);
        }

        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
        $userId = $this->userModel->insert([
            'name' => $name,
            'email' => $email,
            'password' => $hashedPassword,
            'role' => $role,
            'phone' => $phone
        ]);

        return $this->response->setJSON([
            'status' => 'success',
            'message' => "Account for {$name} ({$role}) created successfully!",
            'data' => [
                'id' => $userId,
                'name' => $name,
                'email' => $email,
                'role' => $role,
                'phone' => $phone
            ]
        ]);
    }

    public function deleteUser($id)
    {
        if (!$this->checkRole(['Admin'])) {
            return $this->response->setStatusCode(403)->setJSON([
                'status' => 'error',
                'message' => 'Access Denied: Only Admin can delete accounts.'
            ]);
        }

        $session = session();
        $currentUser = $session->get('user');
        if ($currentUser && (int)$currentUser['id'] === (int)$id) {
            return $this->response->setStatusCode(400)->setJSON([
                'status' => 'error',
                'message' => 'You cannot delete your own active administrator account.'
            ]);
        }

        $this->userModel->delete($id);
        return $this->response->setJSON([
            'status' => 'success',
            'message' => 'Account deleted successfully.'
        ]);
    }
}
