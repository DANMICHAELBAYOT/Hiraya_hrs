<?php

namespace App\Models;

use CodeIgniter\Model;

class BookingModel extends Model
{
    protected $table = 'bookings';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'booking_code',
        'room_id',
        'guest_id',
        'check_in',
        'check_out',
        'actual_check_in',
        'actual_check_out',
        'booking_source',
        'status',
        'total_amount',
        'deposit_amount',
        'paid_amount',
        'special_requests'
    ];
    protected $useTimestamps = true;

    public function getDetailedBookings($limit = 50)
    {
        return $this->select('bookings.*, rooms.room_number, rooms.room_type, guests.full_name, guests.email, guests.phone')
            ->join('rooms', 'rooms.id = bookings.room_id')
            ->join('guests', 'guests.id = bookings.guest_id')
            ->orderBy('bookings.id', 'DESC')
            ->limit($limit)
            ->findAll();
    }
}
