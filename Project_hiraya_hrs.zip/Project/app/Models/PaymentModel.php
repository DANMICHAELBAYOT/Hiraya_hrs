<?php

namespace App\Models;

use CodeIgniter\Model;

class PaymentModel extends Model
{
    protected $table = 'payments';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'booking_id',
        'amount',
        'payment_type',
        'payment_method',
        'reference_no',
        'status',
        'notes'
    ];
    protected $useTimestamps = false;
}
