DROP DATABASE IF EXISTS hotel;
CREATE DATABASE hotel CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE hotel;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('Guest', 'Front Desk', 'Housekeeping', 'Accounting', 'Admin') NOT NULL DEFAULT 'Guest',
    phone VARCHAR(30) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Rooms table
CREATE TABLE IF NOT EXISTS rooms (
    id INT AUTO_INCREMENT PRIMARY KEY,
    room_number VARCHAR(10) NOT NULL UNIQUE,
    room_type ENUM('Standard Villa', 'Deluxe Haven', 'Executive Suite', 'Presidential Suite') NOT NULL,
    status ENUM('Available', 'Booked', 'Occupied', 'Maintenance') NOT NULL DEFAULT 'Available',
    cleaning_status ENUM('Clean', 'Dirty', 'In Progress', 'Inspected') NOT NULL DEFAULT 'Clean',
    price DECIMAL(10,2) NOT NULL,
    capacity INT NOT NULL DEFAULT 2,
    floor INT NOT NULL DEFAULT 1,
    amenities TEXT,
    description TEXT,
    image_url VARCHAR(500) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Guests table
CREATE TABLE IF NOT EXISTS guests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(120) NOT NULL,
    email VARCHAR(150) NOT NULL,
    phone VARCHAR(30) NOT NULL,
    id_type VARCHAR(50) DEFAULT 'Passport',
    id_number VARCHAR(50),
    preferences TEXT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Bookings table
CREATE TABLE IF NOT EXISTS bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    booking_code VARCHAR(30) NOT NULL UNIQUE,
    room_id INT NOT NULL,
    guest_id INT NOT NULL,
    check_in DATE NOT NULL,
    check_out DATE NOT NULL,
    actual_check_in TIMESTAMP NULL DEFAULT NULL,
    actual_check_out TIMESTAMP NULL DEFAULT NULL,
    booking_source ENUM('Website', 'Walk-In', 'Phone', 'Travel Site') NOT NULL DEFAULT 'Website',
    status ENUM('Booked', 'Checked-In', 'Checked-Out', 'Cancelled') NOT NULL DEFAULT 'Booked',
    total_amount DECIMAL(10,2) NOT NULL,
    deposit_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    paid_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    special_requests TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE RESTRICT,
    FOREIGN KEY (guest_id) REFERENCES guests(id) ON DELETE RESTRICT
);

-- Payments table
CREATE TABLE IF NOT EXISTS payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    payment_type ENUM('Deposit', 'Full Payment', 'Incidental', 'Refund') NOT NULL DEFAULT 'Deposit',
    payment_method ENUM('Cash', 'Credit Card', 'Online / GCash', 'Bank Transfer') NOT NULL DEFAULT 'Online / GCash',
    reference_no VARCHAR(100),
    status ENUM('Completed', 'Pending', 'Refunded') NOT NULL DEFAULT 'Completed',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE
);

-- Expenses table (for Accounting)
CREATE TABLE IF NOT EXISTS expenses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category ENUM('Utilities', 'Maintenance', 'Housekeeping Supplies', 'Staff Payroll', 'Food & Beverage', 'Other') NOT NULL,
    description VARCHAR(255) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    expense_date DATE NOT NULL,
    recorded_by VARCHAR(100) DEFAULT 'Accountant',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Seed Users (Password: hiraya123 -> $2y$10$wE97H8uJ5E8YlT5YyEhzQeYV.Q2a2s4JmN8k1Z3b6c7d8e9f0g1h2 or standard hash)
INSERT INTO users (name, email, password, role, phone) VALUES
('Front Desk Staff', 'fd@hiraya.com', '$2y$10$0z8q53rA.k2HhU9V7c6oEuF7jL9w4b3e2a1d0c9b8a7f6e5d4c3b2', 'Front Desk', '+63 917 100 0001'),
('Housekeeping Staff', 'hk@hiraya.com', '$2y$10$0z8q53rA.k2HhU9V7c6oEuF7jL9w4b3e2a1d0c9b8a7f6e5d4c3b2', 'Housekeeping', '+63 917 100 0002'),
('Accounting Officer', 'ac@hiraya.com', '$2y$10$0z8q53rA.k2HhU9V7c6oEuF7jL9w4b3e2a1d0c9b8a7f6e5d4c3b2', 'Accounting', '+63 917 100 0003'),
('System Admin', 'admin@hiraya.com', '$2y$10$0z8q53rA.k2HhU9V7c6oEuF7jL9w4b3e2a1d0c9b8a7f6e5d4c3b2', 'Admin', '+63 917 100 0004'),
('Juan Guest', 'guest@hiraya.com', '$2y$10$0z8q53rA.k2HhU9V7c6oEuF7jL9w4b3e2a1d0c9b8a7f6e5d4c3b2', 'Guest', '+63 917 100 0005'),
('Clara Desk', 'frontdesk@hiraya.ph', '$2y$10$0z8q53rA.k2HhU9V7c6oEuF7jL9w4b3e2a1d0c9b8a7f6e5d4c3b2', 'Front Desk', '+63 917 222 0001'),
('Pedro Clean', 'housekeeping@hiraya.ph', '$2y$10$0z8q53rA.k2HhU9V7c6oEuF7jL9w4b3e2a1d0c9b8a7f6e5d4c3b2', 'Housekeeping', '+63 917 222 0002'),
('Elena Finance', 'accounting@hiraya.ph', '$2y$10$0z8q53rA.k2HhU9V7c6oEuF7jL9w4b3e2a1d0c9b8a7f6e5d4c3b2', 'Accounting', '+63 917 222 0003'),
('Admin Hiraya', 'admin@hiraya.ph', '$2y$10$0z8q53rA.k2HhU9V7c6oEuF7jL9w4b3e2a1d0c9b8a7f6e5d4c3b2', 'Admin', '+63 917 222 0004');

-- Seed Rooms
INSERT INTO rooms (room_number, room_type, status, cleaning_status, price, capacity, floor, amenities, description, image_url) VALUES
('101', 'Standard Villa', 'Available', 'Clean', 3500.00, 2, 1, 'King Bed, Free Wi-Fi, Balcony, Smart TV, Air Conditioning', 'A peaceful sanctuary overlooking tropical flora with warm wooden accents and minimalist modern touches.', 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=800&q=80'),
('102', 'Standard Villa', 'Available', 'Clean', 3500.00, 2, 1, 'King Bed, Free Wi-Fi, Garden Access, Smart TV, Mini Bar', 'Private garden access featuring indigenous craftsmanship and tranquil ambiance.', 'https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=800&q=80'),
('201', 'Deluxe Haven', 'Booked', 'Clean', 5200.00, 3, 2, 'Queen Beds (2), Sea View Balcony, Bathtub, Espresso Machine', 'Elevated ocean vista with floor-to-ceiling windows and artisanal stone bath fixtures.', 'https://images.unsplash.com/photo-1566665797739-1674de7a421a?auto=format&fit=crop&w=800&q=80'),
('202', 'Deluxe Haven', 'Occupied', 'Clean', 5200.00, 3, 2, 'Queen Beds (2), Panoramic Terrace, Bathtub, Wine Chiller', 'Lavish room retreat with sunset terrace views and signature Hiraya amenities.', 'https://images.unsplash.com/photo-1578683010236-d716f9a3f461?auto=format&fit=crop&w=800&q=80'),
('301', 'Executive Suite', 'Available', 'Clean', 8500.00, 4, 3, 'Master King + Twin, Private Plunge Pool, Lounge, Butler Service', 'Sprawling suite featuring dedicated living quarters, open-air sun deck and plunge pool.', 'https://images.unsplash.com/photo-1618773928121-c32242e63f39?auto=format&fit=crop&w=800&q=80'),
('302', 'Presidential Suite', 'Available', 'Clean', 15000.00, 6, 4, '3 Bedrooms, Private Infinity Pool, Chef Kitchen, Spa Room', 'The crown jewel of Hiraya. Unsurpassed elegance, private infinity pool, and 360-degree views.', 'https://images.unsplash.com/photo-1582719508461-905c673771fd?auto=format&fit=crop&w=800&q=80'),
('103', 'Standard Villa', 'Maintenance', 'Dirty', 3500.00, 2, 1, 'King Bed, Rain Shower, Garden Terrace', 'Under scheduled routine HVAC maintenance.', 'https://images.unsplash.com/photo-1591088398332-8a7791972843?auto=format&fit=crop&w=800&q=80'),
('203', 'Deluxe Haven', 'Available', 'Dirty', 5200.00, 3, 2, 'Queen Bed, Balcony, Work Desk', 'Awaiting housekeeping turnover after morning checkout.', 'https://images.unsplash.com/photo-1613545325278-f24b0cae1224?auto=format&fit=crop&w=800&q=80');

-- Seed Guests
INSERT INTO guests (full_name, email, phone, id_type, id_number, preferences) VALUES
('Mateo Gomez', 'mateo.gomez@gmail.com', '+63 917 123 4567', 'Passport', 'P9842145A', 'Prefers high floor, non-smoking, extra pillows'),
('Sofia Valdez', 'sofia.valdez@outlook.com', '+63 928 987 6543', 'Driver License', 'D02-14-987654', 'Vegetarian breakfast, late check-out requested'),
('Juan Dela Cruz', 'juan.cruz@yahoo.com', '+63 905 555 4321', 'National ID', '7890-1234-5678', 'Prefers quiet garden villa');

-- Seed Bookings
INSERT INTO bookings (booking_code, room_id, guest_id, check_in, check_out, booking_source, status, total_amount, deposit_amount, paid_amount, special_requests) VALUES
('HRY-2026-001', 3, 1, '2026-10-20', '2026-10-23', 'Website', 'Booked', 15600.00, 5000.00, 5000.00, 'Anniversary setup with fresh jasmine floral decor.'),
('HRY-2026-002', 4, 2, '2026-10-18', '2026-10-21', 'Walk-In', 'Checked-In', 15600.00, 15600.00, 15600.00, 'Quiet room away from elevator.');

-- Seed Payments
INSERT INTO payments (booking_id, amount, payment_type, payment_method, reference_no, status, notes) VALUES
(1, 5000.00, 'Deposit', 'Online / GCash', 'GCASH-9823412', 'Completed', 'Online reservation 30% deposit received.'),
(2, 5000.00, 'Deposit', 'Credit Card', 'CC-AUTH-7721', 'Completed', 'Walk-in deposit on arrival.'),
(2, 10600.00, 'Full Payment', 'Cash', 'CASH-REC-1044', 'Completed', 'Settlement of balance for 3 nights stay.');

-- Seed Expenses
INSERT INTO expenses (category, description, amount, expense_date, recorded_by) VALUES
('Housekeeping Supplies', 'Organic Bamboo Linens and Luxury Toiletries Restock', 12450.00, '2026-10-15', 'Operations'),
('Utilities', 'Solar Grid Supplement & Water Utility Oct 2026', 28500.00, '2026-10-16', 'Accountant'),
('Maintenance', 'Pool Pump Filter Replacement Suite 301', 6500.00, '2026-10-17', 'Facility Engr');
