<?php

namespace App\Models;

use CodeIgniter\Model;

class ExpenseModel extends Model
{
    protected $table = 'expenses';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'category',
        'description',
        'amount',
        'expense_date',
        'recorded_by'
    ];
    protected $useTimestamps = false;
}
