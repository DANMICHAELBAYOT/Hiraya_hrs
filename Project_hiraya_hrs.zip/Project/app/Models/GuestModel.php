<?php

namespace App\Models;

use CodeIgniter\Model;

class GuestModel extends Model
{
    protected $table = 'guests';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'full_name',
        'email',
        'phone',
        'id_type',
        'id_number',
        'preferences',
        'notes'
    ];
    protected $useTimestamps = true;
}
