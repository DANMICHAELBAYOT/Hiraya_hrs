<?php

namespace App\Models;

use CodeIgniter\Model;

class RoomModel extends Model
{
    protected $table = 'rooms';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'room_number',
        'room_type',
        'status',
        'cleaning_status',
        'price',
        'capacity',
        'floor',
        'amenities',
        'description',
        'image_url'
    ];
    protected $useTimestamps = true;
}
